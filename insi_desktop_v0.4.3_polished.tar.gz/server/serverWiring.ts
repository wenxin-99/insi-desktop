/**
 * serverWiring.ts — Insi Desktop 服务端集成代码
 *
 * 将以下代码片段粘贴到主 Express app 的对应位置。
 * 文件位置: /www/wwwroot/ai_platform/server/index.ts 或 app.ts
 *
 * ⚠️ 这不是一个可以直接运行的文件，而是集成指南。
 */

// ═══════════════════════════════════════════
// 1. 导入（添加到文件顶部 import 区域）
// ═══════════════════════════════════════════

/*
import { desktopUpdaterRouter } from './_core/desktopSession/updaterRoutes';
import { desktopRoutesV2 } from './_core/desktopSession/routesV2';
import { initDispatchNamespace } from './_core/desktopSession/dispatch';
*/

// ═══════════════════════════════════════════
// 2. Express 路由注册（添加到 app.use() 区域）
// ═══════════════════════════════════════════

/*
// Desktop 控制 API v2（14 个端点：回放/安全/规划/权限等）
app.use('/api/desktop', desktopRoutesV2);

// Desktop 自动更新端点（Tauri updater 轮询）
app.use('/api/desktop', desktopUpdaterRouter);
*/

// ═══════════════════════════════════════════
// 3. Socket.IO Dispatch 命名空间（添加到 io 初始化之后）
// ═══════════════════════════════════════════

/*
// 手机远程控制 QR 配对命名空间
initDispatchNamespace(io);
*/

// ═══════════════════════════════════════════
// 4. Health API（如果还没有的话，网络诊断需要）
// ═══════════════════════════════════════════

/*
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    version: process.env.npm_package_version || '1.0.0',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});
*/

// ═══════════════════════════════════════════
// 5. deciderLoop 集成 TaskEventEmitter（修改 chatHandler.ts）
// ═══════════════════════════════════════════

/*
// 在 chatHandler.ts 的 handleDesktopChat() 函数中，
// 找到调用 deciderLoop / runEnhancedLoop 的位置，添加:

import { TaskEventEmitter } from './taskEventEmitter';

// 创建事件发射器
const taskEmitter = new TaskEventEmitter(desktopSocket);

// 在开始决策循环前:
taskEmitter.start(userMessage, 0);

// 传入 deciderLoop 选项:
await runDeciderLoop({
  ...existingOptions,
  onStepStart: (index, tool, thought) => {
    taskEmitter.step(index, tool, thought, 'running');
  },
  onStepDone: (index, tool, thought) => {
    taskEmitter.stepDone(index, tool, thought);
  },
  onStepFailed: (index, tool, thought, error) => {
    taskEmitter.stepFailed(index, tool, thought, error);
  },
  onScreenshot: (base64, width, height) => {
    taskEmitter.screenshot(base64, width, height);
  },
});

// 循环结束后:
taskEmitter.complete(success ? 'completed' : 'failed');
*/

// ═══════════════════════════════════════════
// 6. 权限级别 API（新增端点，对应客户端设置面板）
// ═══════════════════════════════════════════

/*
// 添加到 routesV2.ts 或单独路由文件

// 获取用户的桌面控制权限级别
router.get('/permission-level', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  // 从数据库读取用户设置，默认 standard
  const level = await getUserDesktopPermissionLevel(userId) || 'standard';
  res.json({ level });
});

// 设置权限级别
router.put('/permission-level', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  const { level } = req.body;
  if (!['standard', 'cautious', 'restricted'].includes(level)) {
    return res.status(400).json({ error: '无效的权限级别' });
  }
  await setUserDesktopPermissionLevel(userId, level);

  // 通知已连接的桌面客户端更新权限级别
  const desktopSocket = getDesktopSocketByUserId(userId);
  if (desktopSocket) {
    desktopSocket.emit('server_message', {
      type: 'config',
      payload: { permissionLevel: level },
    });
  }

  res.json({ success: true, level });
});
*/

export {};
