/**
 * taskEventEmitter.ts — 桌面控制任务事件发射器
 *
 * 在 deciderLoop 中调用，将任务进度实时推送到桌面客户端的预览面板。
 *
 * 使用方式 (在 deciderLoop.ts / chatHandler.ts 中):
 *
 *   import { TaskEventEmitter } from './taskEventEmitter';
 *
 *   const emitter = new TaskEventEmitter(socket);
 *   emitter.start('帮我打开浏览器搜索天气', 5);
 *   emitter.step(0, 'desktop.click', '点击 Chrome 图标', 'running');
 *   emitter.screenshot(base64Thumb, 640, 360);
 *   emitter.stepDone(0); // mark success
 *   emitter.complete('completed');
 */

interface DesktopSocket {
  emit(event: string, data: any): void;
}

export class TaskEventEmitter {
  private socket: DesktopSocket;
  private taskActive = false;
  private totalSteps = 0;

  constructor(socket: DesktopSocket) {
    this.socket = socket;
  }

  /**
   * 任务开始
   * @param goal 任务目标描述（自然语言）
   * @param estimatedSteps 预估步骤数（可选，0=未知）
   */
  start(goal: string, estimatedSteps = 0): void {
    this.taskActive = true;
    this.totalSteps = estimatedSteps;
    this.socket.emit('server_message', {
      type: 'task_start',
      payload: {
        goal,
        totalSteps: estimatedSteps,
      },
    });
  }

  /**
   * 步骤更新
   * @param index 步骤序号（从 0 开始）
   * @param tool 工具名 (desktop.click / desktop.type / ...)
   * @param description 操作描述
   * @param status 状态: running / success / failed
   */
  step(index: number, tool: string, description: string, status: 'running' | 'success' | 'failed' = 'running'): void {
    if (index >= this.totalSteps) {
      this.totalSteps = index + 1;
    }
    this.socket.emit('server_message', {
      type: 'task_step',
      payload: {
        stepIndex: index,
        tool,
        description,
        status,
      },
    });
  }

  /**
   * 标记步骤成功
   */
  stepDone(index: number, tool = '', description = ''): void {
    this.step(index, tool, description, 'success');
  }

  /**
   * 标记步骤失败
   */
  stepFailed(index: number, tool = '', description = '', error?: string): void {
    this.socket.emit('server_message', {
      type: 'task_step',
      payload: {
        stepIndex: index,
        tool,
        description,
        status: 'failed',
        error,
      },
    });
  }

  /**
   * 发送截图缩略图（用于预览面板）
   * @param thumbnail base64 编码的缩略图（建议 640px 宽）
   */
  screenshot(thumbnail: string, width: number, height: number): void {
    this.socket.emit('server_message', {
      type: 'task_screenshot',
      payload: { thumbnail, width, height },
    });
  }

  /**
   * 任务完成
   * @param status 'completed' | 'failed'
   */
  complete(status: 'completed' | 'failed' = 'completed'): void {
    this.taskActive = false;
    this.socket.emit('server_message', {
      type: 'task_complete',
      payload: { status },
    });
  }

  get isActive(): boolean {
    return this.taskActive;
  }
}

/**
 * 便捷函数：在 deciderLoop 中包装每一步操作
 *
 * 用法:
 *   const emitter = new TaskEventEmitter(socket);
 *   emitter.start(userQuery, actions.length);
 *
 *   for (let i = 0; i < actions.length; i++) {
 *     const action = actions[i];
 *     emitter.step(i, action.tool, action.description, 'running');
 *
 *     try {
 *       await executeAction(action);
 *       emitter.stepDone(i, action.tool, action.description);
 *     } catch (err) {
 *       emitter.stepFailed(i, action.tool, action.description, err.message);
 *     }
 *
 *     // 每步后发送截图缩略图
 *     const screenshot = await captureAndResize(640);
 *     emitter.screenshot(screenshot.base64, screenshot.width, screenshot.height);
 *   }
 *
 *   emitter.complete('completed');
 */

/**
 * deciderLoop 集成示例（粘贴到 deciderLoop.ts 的主循环中）
 *
 * ```typescript
 * import { TaskEventEmitter } from './taskEventEmitter';
 *
 * // 在 runDeciderLoop 函数开头:
 * const taskEmitter = new TaskEventEmitter(desktopSocket);
 * taskEmitter.start(userMessage, 0); // 0 = 未知步骤数
 *
 * let stepIndex = 0;
 *
 * // 在每次 decider 决策后、执行操作前:
 * taskEmitter.step(stepIndex, decision.tool, decision.thought || '', 'running');
 *
 * // 执行操作后:
 * if (actionResult.success) {
 *   taskEmitter.stepDone(stepIndex, decision.tool, decision.thought || '');
 * } else {
 *   taskEmitter.stepFailed(stepIndex, decision.tool, decision.thought || '', actionResult.error);
 * }
 *
 * // 截图后（如果有 sharp）:
 * // const thumb = await sharp(screenshotBuffer).resize(640).webp({quality:50}).toBuffer();
 * // taskEmitter.screenshot(thumb.toString('base64'), 640, thumbHeight);
 *
 * stepIndex++;
 *
 * // 循环结束后:
 * taskEmitter.complete(allSuccess ? 'completed' : 'failed');
 * ```
 */
