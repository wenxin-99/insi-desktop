/**
 * Insi Desktop — 自动更新 API
 *
 * Tauri updater 会请求:
 *   GET /api/desktop/update/:target/:arch/:current_version
 *
 * 返回格式 (Tauri v2 updater JSON):
 *   { version, notes, pub_date, url, signature }
 *
 * 部署: 在主 Express app 中注册
 *   import { desktopUpdaterRouter } from './_core/desktopSession/updaterRoutes';
 *   app.use('/api/desktop', desktopUpdaterRouter);
 */

import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';

export const desktopUpdaterRouter = Router();

// 更新清单存放路径（从 GitHub Release 下载后放这里，或直接代理 GitHub）
const MANIFEST_PATH = path.resolve(__dirname, '../../desktop-update-manifest.json');

// GitHub 仓库信息（用于直接代理 GitHub Releases）
const GITHUB_OWNER = 'wenxin-99';
const GITHUB_REPO = 'insi-desktop';

/**
 * GET /api/desktop/update/:target/:arch/:current_version
 *
 * Tauri updater 端点。
 * - 如果有本地 manifest 文件，使用它
 * - 否则代理 GitHub Releases API 获取最新版本
 */
desktopUpdaterRouter.get(
  '/update/:target/:arch/:current_version',
  async (req: Request, res: Response) => {
    const { target, arch, current_version } = req.params;
    const platform = `${target}-${arch}`; // e.g. "windows-x86_64"

    console.log(`[Desktop Updater] Check: platform=${platform}, current=${current_version}`);

    try {
      // 策略1: 本地 manifest 文件
      if (fs.existsSync(MANIFEST_PATH)) {
        const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf-8'));
        return handleManifest(manifest, platform, current_version, res);
      }

      // 策略2: 代理 GitHub Releases
      const response = await fetch(
        `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`,
        {
          headers: {
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'InsiDesktop-Updater',
          },
        }
      );

      if (!response.ok) {
        console.warn(`[Desktop Updater] GitHub API error: ${response.status}`);
        return res.status(204).end(); // 204 = 无更新
      }

      const release = await response.json() as any;
      const latestVersion = release.tag_name?.replace(/^v/, '') || '';

      // 检查是否有更新
      if (!latestVersion || !isNewer(latestVersion, current_version)) {
        return res.status(204).end();
      }

      // 查找该平台的 update-manifest.json
      const manifestAsset = release.assets?.find(
        (a: any) => a.name === 'update-manifest.json'
      );

      if (manifestAsset) {
        // 下载并解析 manifest
        const manifestRes = await fetch(manifestAsset.browser_download_url);
        const manifest = await manifestRes.json() as any;
        return handleManifest(manifest, platform, current_version, res);
      }

      // 无 manifest，尝试直接从 assets 构造
      const platformAsset = findPlatformAsset(release.assets, platform);
      if (!platformAsset) {
        console.warn(`[Desktop Updater] No asset for platform ${platform}`);
        return res.status(204).end();
      }

      // 查找签名文件
      const sigAsset = release.assets?.find(
        (a: any) => a.name === platformAsset.name + '.sig'
      );
      let signature = '';
      if (sigAsset) {
        const sigRes = await fetch(sigAsset.browser_download_url);
        signature = await sigRes.text();
      }

      return res.json({
        version: latestVersion,
        notes: release.body || `Insi Desktop v${latestVersion}`,
        pub_date: release.published_at,
        url: platformAsset.browser_download_url,
        signature,
      });

    } catch (error) {
      console.error('[Desktop Updater] Error:', error);
      return res.status(204).end();
    }
  }
);

/**
 * 处理本地或远程 manifest
 */
function handleManifest(
  manifest: any,
  platform: string,
  currentVersion: string,
  res: Response
) {
  const latestVersion = manifest.version;

  if (!latestVersion || !isNewer(latestVersion, currentVersion)) {
    return res.status(204).end();
  }

  const platformData = manifest.platforms?.[platform];
  if (!platformData) {
    console.warn(`[Desktop Updater] Platform ${platform} not in manifest`);
    return res.status(204).end();
  }

  return res.json({
    version: latestVersion,
    notes: manifest.notes || `Insi Desktop v${latestVersion}`,
    pub_date: manifest.pub_date || new Date().toISOString(),
    url: platformData.url,
    signature: platformData.signature || '',
  });
}

/**
 * 根据平台名查找对应的 release asset
 */
function findPlatformAsset(assets: any[], platform: string): any | null {
  if (!assets?.length) return null;

  const patterns: Record<string, RegExp[]> = {
    'windows-x86_64': [/\.exe$/i, /nsis.*\.exe$/i],
    'darwin-aarch64': [/aarch64.*\.app\.tar\.gz$/i, /arm64.*\.app\.tar\.gz$/i],
    'darwin-x86_64': [/x86_64.*\.app\.tar\.gz$/i, /x64.*\.app\.tar\.gz$/i],
    'linux-x86_64': [/\.AppImage\.tar\.gz$/i, /\.AppImage$/i],
  };

  const matchers = patterns[platform] || [];
  for (const re of matchers) {
    const found = assets.find((a: any) => re.test(a.name));
    if (found) return found;
  }

  return null;
}

/**
 * 语义版本比较: newV > oldV ?
 */
function isNewer(newV: string, oldV: string): boolean {
  const parse = (v: string) => v.split('.').map(Number);
  const [nMajor, nMinor = 0, nPatch = 0] = parse(newV);
  const [oMajor, oMinor = 0, oPatch = 0] = parse(oldV);

  if (nMajor !== oMajor) return nMajor > oMajor;
  if (nMinor !== oMinor) return nMinor > oMinor;
  return nPatch > oPatch;
}
