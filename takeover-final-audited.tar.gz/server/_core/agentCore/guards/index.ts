/**
 * agentCore/guards/index.ts — 守卫系统
 *
 * 从 automation (antiLoopDetector, successDetector) 和
 * research (taskRunner/actionGuards, finishGuards) 提取并泛化。
 *
 * 守卫分为三类：
 *   pre         — 循环每步开始前（取消/暂停/余额/接管）
 *   postDecision — 决策后、执行前（反循环/重复检测）
 *   postAction   — 执行后（成功检测/错误恢复/相同观察检测）
 */
import type {
  LoopContext, AgentDecision, GuardResult, GuardSet,
  PreGuard, PostDecisionGuard, PostActionGuard, AgentType,
} from "../types";
import { toNumericId } from "../emitter";

// ═══════════════════════════════════════════
// 前置守卫
// ═══════════════════════════════════════════

/** 取消检查 */
export const cancelGuard: PreGuard = async (ctx) => {
  if (ctx.aborted) return { intercepted: true, action: "abort", message: "任务已取消" };

  // ★ 统一取消注册表（所有任务类型，原始 taskId 字符串匹配，无 ID 转换问题）
  try {
    const { checkAndConsumeCancelSignal } = await import("../cancelRegistry");
    if (checkAndConsumeCancelSignal(ctx.task.taskId)) {
      ctx.aborted = true;
      return { intercepted: true, action: "abort", message: "任务已取消" };
    }
  } catch {}

  // ★ DB 兜底：每 5 步查一次 agent_tasks 表状态（防止内存信号丢失，如进程重启）
  if (ctx.step > 0 && ctx.step % 5 === 0) {
    try {
      const { getAgentTask } = await import("../db");
      const task = await getAgentTask(ctx.task.taskId);
      if (task && (task.status === "cancelled" || task.status === "failed")) {
        ctx.aborted = true;
        return { intercepted: true, action: "abort", message: "任务已取消（DB 状态）" };
      }
    } catch {}
  }

  // 检查 automation 取消标记（向后兼容旧的 executeTask 路径）
  if (ctx.task.type === "automation") {
    try {
      const { cancelledTaskIds } = await import("../../automation/browserManager");
      const taskIdNum = toNumericId(ctx.task.taskId);
      if (cancelledTaskIds.has(taskIdNum)) {
        cancelledTaskIds.delete(taskIdNum);
        ctx.aborted = true;
        return { intercepted: true, action: "abort", message: "任务已取消" };
      }
    } catch {}
  }

  // 检查 research 取消标记（向后兼容旧的 research 路径）
  if (ctx.task.type === "research" || ctx.task.type === "codeact") {
    try {
      const { isTaskCancelled } = await import("../../research/cancelControl");
      const taskIdNum = toNumericId(ctx.task.taskId);
      if (await isTaskCancelled(taskIdNum)) {
        ctx.aborted = true;
        return { intercepted: true, action: "abort", message: "任务已取消" };
      }
    } catch {}
  }

  return { intercepted: false };
};

/** 暂停检查（仅 automation） */
export const pauseGuard: PreGuard = async (ctx) => {
  if (ctx.task.type !== "automation") return { intercepted: false };

  try {
    const { pausedTaskIds, cancelledTaskIds } = await import("../../automation/browserManager");
    const taskIdNum = toNumericId(ctx.task.taskId);

    if (pausedTaskIds.has(taskIdNum)) {
      while (pausedTaskIds.has(taskIdNum) && !cancelledTaskIds.has(taskIdNum)) {
        await new Promise(r => setTimeout(r, 1000));
      }
      if (cancelledTaskIds.has(taskIdNum)) {
        cancelledTaskIds.delete(taskIdNum);
        ctx.aborted = true;
        return { intercepted: true, action: "abort", message: "暂停后取消" };
      }
      pausedTaskIds.delete(taskIdNum);
    }
  } catch {}

  return { intercepted: false };
};

/** 余额检查（research/codeact 按步扣费） */
export const balanceGuard: PreGuard = async (ctx) => {
  if (ctx.step === 0) return { intercepted: false }; // 第 0 步不扣
  if (ctx.task.config.stepCost <= 0) return { intercepted: false };

  try {
    const { deductStepCost } = await import("../../research/researchPricing");
    const deducted = await deductStepCost(
      ctx.task.userId,
      toNumericId(ctx.task.taskId),
      ctx.step,
      ctx.task.config.stepCost,
    );
    if (!deducted) {
      ctx.aborted = true;
      ctx.abortReason = "余额不足";
      return { intercepted: true, action: "abort", message: "余额不足，正在整理当前进展..." };
    }
  } catch (err: any) {
    console.warn("[BalanceGuard] Deduct failed:", err.message);
  }

  return { intercepted: false };
};

/** 接管检查 */
export const takeoverGuard: PreGuard = async (ctx) => {
  if (!ctx.task.config.takeoverEnabled) return { intercepted: false };

  try {
    const { isInTakeoverMode, consumeTakeoverFeedback } = await import("../../automation/takeoverManager");
    const taskIdNum = toNumericId(ctx.task.taskId);

    const wasTakenOver = isInTakeoverMode(taskIdNum);
    while (isInTakeoverMode(taskIdNum)) {
      await new Promise(r => setTimeout(r, 1000));
    }

    if (wasTakenOver) {
      const feedback = consumeTakeoverFeedback(taskIdNum);
      if (feedback) {
        ctx.history.push({
          thought: "用户手动接管了浏览器进行操作",
          action: "用户反馈",
          observation: `[用户手动操作后的反馈]: ${feedback}\n\n请根据用户反馈继续执行任务。`,
        });
      } else {
        ctx.history.push({
          thought: "用户接管了浏览器",
          action: "系统提示",
          observation: "[系统] 用户刚刚手动操作了浏览器。请重新分析当前页面状态继续执行。",
        });
      }
    }
  } catch {}

  return { intercepted: false };
};

/** ★ P1⑥：中途指令注入（对标 ChatGPT Agent 的任务中追加指令） */
export const instructionGuard: PreGuard = async (ctx) => {
  try {
    const { consumeInstructions } = await import("../../automation/instructionInjector");
    const taskIdNum = toNumericId(ctx.task.taskId);
    const instructions = consumeInstructions(taskIdNum);
    if (instructions) {
      console.log(`[InstructionGuard] Task ${taskIdNum}: injecting user instruction`);
      ctx.history.push({
        thought: "[系统] 用户在任务执行中发来了新的指令",
        action: "用户指令",
        observation: `[用户中途指令]: ${instructions}\n\n请根据用户的新指令调整后续操作。如果与当前操作冲突，以用户的新指令为准。`,
      });
    }
  } catch {}
  return { intercepted: false };
};

/** 连续错误检查 */
export const errorLimitGuard: PreGuard = async (ctx) => {
  if (ctx.consecutiveErrors >= 7) {
    ctx.aborted = true;
    return { intercepted: true, action: "abort", message: "连续错误过多（7次），自动停止" };
  }

  // 已有成功操作但后续出错过多 → 标记为部分完成
  if (ctx.autoSuccessCount > 0 && ctx.consecutiveErrors >= 4) {
    ctx.completed = true;
    return {
      intercepted: true,
      action: "abort",
      message: `任务核心操作已完成（${ctx.autoSuccessCount} 项成功），后续步骤出错，自动结束`,
    };
  }

  return { intercepted: false };
};

// ═══════════════════════════════════════════
// 决策后守卫
// ═══════════════════════════════════════════

/** 反循环检测（泛化版，从 antiLoopDetector.ts 提取） */
export const antiLoopGuard: PostDecisionGuard = async (ctx, decision) => {
  if (!ctx.task.config.antiLoop) return { intercepted: false };

  const actionKey = `${decision.tool}:${JSON.stringify(decision.params)}`;
  const lastActions = ctx.recentActions.slice(-5);

  // 策略1：完全相同操作连续 3 次
  const isExactRepeat = lastActions.length >= 3 &&
    lastActions.slice(-3).every(a => `${a.tool}:${JSON.stringify(a.params)}` === actionKey);

  // 策略2：同一工具连续 5 次（排除 browser.type）
  const isSameToolRepeat = decision.tool !== "browser.type" &&
    lastActions.length >= 5 && lastActions.every(a => a.tool === decision.tool);

  // 策略3：URL 停滞（浏览器场景专用）
  const NON_NAV = new Set(["browser.type", "browser.scroll", "browser.wait", "browser.screenshot", "browser.captcha", "browser.generate_content", "browser.select_option"]);
  const isClickAction = ["browser.click_index", "browser.click_text", "browser.click"].includes(decision.tool);
  const recentClickActions = ctx.recentActions.filter(a => !NON_NAV.has(a.tool));
  const last3Urls = recentClickActions.slice(-3).map(a => a.url);
  const currentUrl = ctx.variables.currentUrl || "";
  const isUrlStagnant = isClickAction && last3Urls.length >= 3 && last3Urls.every(u => u === currentUrl);

  if (!isExactRepeat && !isSameToolRepeat && !isUrlStagnant) {
    return { intercepted: false };
  }

  ctx.totalLoopDetections++;
  const reason = isExactRepeat ? "完全相同操作重复3次" : isSameToolRepeat ? "同一工具连续使用5次" : "URL连续3次操作未变化";
  console.log(`[AntiLoopGuard] Triggered (${reason}), total: ${ctx.totalLoopDetections}`);

  // 累计触发 5 次 → 终止
  if (ctx.totalLoopDetections >= 5) {
    if (ctx.autoSuccessCount > 0) {
      ctx.completed = true;
      return { intercepted: true, action: "abort", message: `任务部分完成（${ctx.autoSuccessCount} 项成功），后续操作反复受阻` };
    }
    ctx.aborted = true;
    return { intercepted: true, action: "abort", message: `任务反复陷入循环（累计 ${ctx.totalLoopDetections} 次），自动终止` };
  }

  // 注入提示到历史
  ctx.history.push({
    thought: `[系统] 检测到循环（${reason}）`,
    action: "反循环提示",
    observation: `[系统提示] 检测到你在重复操作。请换一种策略继续。`,
  });

  return { intercepted: true, action: "skip", message: reason };
};

/** 重复操作检测（research 场景，从 guardDuplicateAction 泛化） */
export const duplicateActionGuard: PostDecisionGuard = async (ctx, decision) => {
  if (ctx.task.type !== "research" && ctx.task.type !== "codeact") return { intercepted: false };

  const currentKey = `${decision.tool}:${JSON.stringify(decision.params).substring(0, 200)}`;
  const lastAction = ctx.recentActions[ctx.recentActions.length - 1];
  const lastKey = lastAction ? `${lastAction.tool}:${JSON.stringify(lastAction.params).substring(0, 200)}` : "";

  if (currentKey === lastKey) {
    const sameCount = (ctx.variables._consecutiveSameAction || 0) + 1;
    ctx.variables._consecutiveSameAction = sameCount;

    if (sameCount >= 3) {
      console.warn(`[DuplicateGuard] Same action ${sameCount} times, forcing finish`);
      ctx.aborted = true;
      return { intercepted: true, action: "abort", message: "重复操作3次，强制结束" };
    }
    return { intercepted: true, action: "skip", message: "重复操作，跳过" };
  } else {
    ctx.variables._consecutiveSameAction = 0;
  }

  return { intercepted: false };
};

/** ★ 空转思考检测：连续 system.think 说明 LLM 无法推进任务（如工具缺失） */
export const thinkLoopGuard: PostDecisionGuard = async (ctx, decision) => {
  if (decision.tool !== "system.think") {
    ctx.variables._consecutiveThinks = 0;
    return { intercepted: false };
  }

  const count = (ctx.variables._consecutiveThinks || 0) + 1;
  ctx.variables._consecutiveThinks = count;

  // 连续 3 次 system.think → 直接终止，避免空烧 token
  if (count >= 3) {
    console.warn(`[ThinkLoopGuard] ${count} consecutive system.think, aborting task ${ctx.task.taskId}`);
    ctx.aborted = true;
    return {
      intercepted: true,
      action: "abort",
      message: `连续 ${count} 次纯思考无实际操作，可能缺少所需工具，任务终止`,
    };
  }

  return { intercepted: false };
};

/** ★ 关键操作确认守卫：在不可逆操作前暂停等待用户确认（对标 Operator Takeover Mode） */
export const confirmationGuard: PostDecisionGuard = async (ctx, decision) => {
  // 仅 automation 类型开启
  if (ctx.task.type !== "automation") return { intercepted: false };
  // 任务配置可禁用确认（如全自动批量场景）
  if (ctx.task.config.skipConfirmation) return { intercepted: false };

  try {
    const { isSensitiveAction, requestConfirmation } = await import("../../automation/confirmationManager");
    const taskIdNum = toNumericId(ctx.task.taskId);
    const currentUrl = ctx.variables.currentUrl || "";

    const check = isSensitiveAction(decision.tool, decision.params, currentUrl);
    if (!check.sensitive) return { intercepted: false };

    console.log(`[ConfirmationGuard] Task ${taskIdNum}: sensitive action detected — ${check.reason}`);

    // 发送确认请求并等待（最长 60 秒）
    const result = await requestConfirmation(
      taskIdNum,
      decision.tool,
      check.reason,
      ctx.variables.lastScreenshot || "",
      60000,
    );

    if (result === "rejected") {
      // 用户拒绝 → 跳过此操作，注入提示让 AI 换个方式
      ctx.history.push({
        thought: `[系统] 用户拒绝了操作: ${check.reason}`,
        action: "用户拒绝",
        observation: `[系统提示] 用户拒绝了此操作（${check.reason}）。请换一种方式继续，或等待用户指示。`,
      });
      return { intercepted: true, action: "skip", message: `用户拒绝: ${check.reason}` };
    }

    // confirmed 或 timeout → 继续执行
    if (result === "timeout") {
      console.log(`[ConfirmationGuard] Task ${taskIdNum}: confirmation timed out, auto-proceeding`);
    }
  } catch (err: any) {
    // 确认系统出错不应阻塞任务
    console.error(`[ConfirmationGuard] Error:`, err.message);
  }

  return { intercepted: false };
};

// ═══════════════════════════════════════════
// 执行后守卫
// ═══════════════════════════════════════════

/** 自动成功检测（automation 场景） */
export const autoSuccessGuard: PostActionGuard = async (ctx, decision, observation) => {
  if (ctx.task.type !== "automation") return { intercepted: false };

  try {
    const { detectAutoSuccess } = await import("../../automation/agentLoop/successDetector");
    const page = ctx.variables.page;
    const taskIdNum = toNumericId(ctx.task.taskId);

    const result = await detectAutoSuccess({
      page,
      taskId: taskIdNum,
      stepNumber: ctx.step,
      action: { tool: decision.tool.replace("browser.", ""), params: decision.params, reasoning: decision.thought },
      contentGenerated: ctx.variables.contentGenerated || false,
      taskCompleted: ctx.completed,
      recentActions: ctx.recentActions.map(a => ({ tool: a.tool.replace("browser.", ""), params: a.params, url: a.url || "" })),
      history: ctx.history.map(h => ({ role: "user", content: h.observation })),
      db: ctx.variables.db,
      automationContents: ctx.variables.automationContents,
      actionStartTime: Date.now(),
    });

    if (result.detected) {
      ctx.autoSuccessCount++;
      // 重置反循环计数
      ctx.totalLoopDetections = Math.max(0, ctx.totalLoopDetections - 3);
      ctx.consecutiveErrors = 0;
    }
  } catch {}

  return { intercepted: false };
};

/** 相同观察检测（research 场景） */
export const identicalObservationGuard: PostActionGuard = async (ctx, _decision, observation) => {
  if (ctx.history.length < 3) return { intercepted: false };

  const lastObs = ctx.history.slice(-3).map(h => h.observation);
  const allSame = lastObs.every(o => o === observation);

  if (allSame) {
    console.warn(`[IdenticalObsGuard] Same observation 3 times, aborting`);
    ctx.aborted = true;
    return { intercepted: true, action: "abort", message: "连续 3 次观察完全相同，终止任务" };
  }

  return { intercepted: false };
};

/** 错误恢复守卫（执行出错后尝试恢复） */
export const errorRecoveryGuard: PostActionGuard = async (ctx, decision, observation) => {
  if (!observation.includes("[错误]") && !observation.includes("[工具执行错误]")) {
    ctx.consecutiveErrors = 0;
    return { intercepted: false };
  }

  ctx.consecutiveErrors++;

  // 浏览器场景：超时后刷新
  if (ctx.task.type === "automation" && ctx.consecutiveErrors >= 2) {
    const page = ctx.variables.page;
    if (page && (observation.includes("Timeout") || observation.includes("timeout"))) {
      try {
        await page.reload({ waitUntil: "domcontentloaded", timeout: 15000 }).catch(() => {});
        await new Promise(r => setTimeout(r, 2000));
        ctx.history.push({
          thought: "[系统] 尝试恢复",
          action: "页面刷新",
          observation: "[系统] 页面已刷新恢复。请重新分析当前状态继续执行。",
        });
      } catch {}
    }
  }

  return { intercepted: false };
};

// ═══════════════════════════════════════════
// 守卫注册表
// ═══════════════════════════════════════════

/**
 * 按任务类型构建守卫集合
 */
export function buildGuards(type: AgentType, config?: { antiLoop?: boolean; takeoverEnabled?: boolean }): GuardSet {
  const pre: PreGuard[] = [cancelGuard, errorLimitGuard];
  const postDecision: PostDecisionGuard[] = [thinkLoopGuard]; // ★ 所有类型都防空转思考
  const postAction: PostActionGuard[] = [errorRecoveryGuard];

  switch (type) {
    case "automation":
      pre.push(pauseGuard);
      if (config?.takeoverEnabled !== false) pre.push(takeoverGuard);
      pre.push(instructionGuard); // ★ P1⑥：中途指令注入
      if (config?.antiLoop !== false) postDecision.push(antiLoopGuard);
      postDecision.push(confirmationGuard); // ★ 关键操作确认
      postAction.push(autoSuccessGuard);
      break;

    case "research":
      pre.push(balanceGuard);
      pre.push(instructionGuard); // ★ 研究任务也支持中途指令
      postDecision.push(duplicateActionGuard);
      postAction.push(identicalObservationGuard);
      break;

    case "codeact":
      pre.push(balanceGuard);
      postDecision.push(duplicateActionGuard);
      postAction.push(identicalObservationGuard);
      break;

    case "general":
      pre.push(balanceGuard);
      if (config?.antiLoop !== false) postDecision.push(antiLoopGuard);
      postDecision.push(duplicateActionGuard);
      postAction.push(identicalObservationGuard);
      break;
  }

  return { pre, postDecision, postAction };
}
