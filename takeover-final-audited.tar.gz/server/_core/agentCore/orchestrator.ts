/**
 * agentCore/orchestrator.ts — 通用 Agent Loop 核心编排器
 *
 * 统一 automation (agentLoopPhase.ts) 和 research (taskRunner.ts) 两套循环，
 * 所有 Agent 类型（automation / research / codeact / general）共用同一套循环骨架。
 *
 * 核心循环结构：
 *   while (step < maxSteps && !completed) {
 *     ① 前置守卫（取消/暂停/余额/接管/错误上限）
 *     ② 获取决策（按 type 分发到不同 Decider）
 *     ③ 决策后守卫（反循环/重复检测）
 *     ④ 执行工具
 *     ⑤ 执行后守卫（成功检测/错误恢复/相同观察检测）
 *     ⑥ 记录历史 & 更新进度
 *   }
 *
 * 差异化通过「策略模式」实现：不同 type 加载不同的 decider + guard 集。
 */
import type {
  AgentTask, AgentResult, AgentConfig, AgentStatus,
  LoopContext, HistoryEntry, AgentDecision, GuardResult,
  SandboxHandle,
} from "./types";
import { buildToolSet, type ToolRegistry } from "./tools/registry";
import { getDecision } from "./decision";
import { buildGuards } from "./guards";
import { createAgentEmitter, toNumericId } from "./emitter";
import { SandboxManager } from "./sandbox/sandboxManager";

// ═══════════════════════════════════════════
// 初始化
// ═══════════════════════════════════════════

function initContext(task: AgentTask): LoopContext {
  const emitter = createAgentEmitter(task.taskId);

  // 创建沙箱句柄（实际容器在需要时才创建）
  const sandbox: SandboxHandle = {
    type: task.config.sandboxMode === "docker" ? "docker" : task.config.sandboxMode === "ssh" ? "ssh" : "none" as any,
    workDir: `/tmp/sandbox-${task.taskId}`,
    alive: false,
  };

  // ★ Fix: 从 task 上下文中提取初始变量（page, sshConfig 等）
  const variables: Record<string, any> = {};
  if (task.automationContext) {
    variables.page = task.automationContext.page;
    variables.account = { siteUrl: task.automationContext.siteUrl, loginUrl: task.automationContext.loginUrl };
    variables.automationTask = task.automationContext;
  }
  if (task.researchContext) {
    variables.sshConfig = task.researchContext.sshConfig;
  }

  return {
    step: 0,
    history: [],
    variables,
    sandbox,
    emitter,
    task,
    consecutiveErrors: 0,
    autoSuccessCount: 0,
    totalLoopDetections: 0,
    completed: false,
    aborted: false,
    recentActions: [],
    searchedQueries: new Set(),
  };
}

async function ensureSandbox(ctx: LoopContext): Promise<void> {
  if (ctx.sandbox.alive) return;

  const sandboxMode = ctx.task.config.sandboxMode;
  if (sandboxMode === "none" || sandboxMode === "browser") {
    // browser 模式不需要 Docker，使用 Playwright page
    ctx.sandbox.alive = true;
    return;
  }

  if (sandboxMode === "docker") {
    try {
      const manager = SandboxManager.getInstance();
      const handle = await manager.create(ctx.task.taskId, {
        image: "insights-sandbox:latest",
        timeout: ctx.task.config.maxSteps * 60_000, // 每步约 1 分钟
        memory: "512m",
        cpu: "0.5",
        network: true,
      });
      Object.assign(ctx.sandbox, handle);
      console.log(`[Orchestrator] Docker sandbox created: ${handle.containerId || "ssh-fallback"}`);
    } catch (err: any) {
      console.warn(`[Orchestrator] Docker sandbox creation failed, using SSH fallback:`, err.message);
      ctx.sandbox.type = "ssh";
      ctx.sandbox.alive = true;
    }
  } else if (sandboxMode === "ssh") {
    ctx.sandbox.alive = true;
  }
}

// ═══════════════════════════════════════════
// 守卫执行器
// ═══════════════════════════════════════════

async function runPreGuards(
  ctx: LoopContext,
  guards: Array<(ctx: LoopContext) => Promise<GuardResult>>,
): Promise<GuardResult> {
  for (const guard of guards) {
    const result = await guard(ctx);
    if (result.intercepted) return result;
  }
  return { intercepted: false };
}

async function runPostDecisionGuards(
  ctx: LoopContext,
  decision: AgentDecision,
  guards: Array<(ctx: LoopContext, d: AgentDecision) => Promise<GuardResult>>,
): Promise<GuardResult> {
  for (const guard of guards) {
    const result = await guard(ctx, decision);
    if (result.intercepted) return result;
  }
  return { intercepted: false };
}

async function runPostActionGuards(
  ctx: LoopContext,
  decision: AgentDecision,
  observation: string,
  guards: Array<(ctx: LoopContext, d: AgentDecision, o: string) => Promise<GuardResult>>,
): Promise<GuardResult> {
  for (const guard of guards) {
    const result = await guard(ctx, decision, observation);
    if (result.intercepted) return result;
  }
  return { intercepted: false };
}

// ═══════════════════════════════════════════
// 步骤持久化
// ═══════════════════════════════════════════

async function persistStep(
  taskId: string,
  step: number,
  type: string,
  content: string,
  toolName?: string,
  toolInput?: string,
  metadata?: Record<string, any>,
): Promise<void> {
  try {
    const { createAgentStep } = await import("./db");
    await createAgentStep({
      taskId, stepNumber: step, type,
      toolName, toolInput,
      observation: content,
      metadata,
    });
  } catch (err: any) {
    console.warn(`[Orchestrator] persistStep failed: ${err.message}`);
  }
}

async function updateTaskStatus(
  taskId: string,
  status: AgentStatus,
  totalSteps: number,
  totalCost: number,
  result?: any,
): Promise<void> {
  try {
    const { updateAgentTaskStatus } = await import("./db");
    await updateAgentTaskStatus(taskId, status, { totalSteps, totalCost, result });
  } catch (err: any) {
    console.warn(`[Orchestrator] updateTaskStatus failed: ${err.message}`);
  }
}

// ═══════════════════════════════════════════
// 核心循环
// ═══════════════════════════════════════════

export async function runAgentLoop(task: AgentTask): Promise<AgentResult> {
  const ctx = initContext(task);
  const toolRegistry = buildToolSet(task.config);
  const guards = buildGuards(task.type, {
    antiLoop: task.config.antiLoop,
    takeoverEnabled: task.config.takeoverEnabled,
  });

  console.log(`[Orchestrator] Starting agent loop: taskId=${task.taskId}, type=${task.type}, maxSteps=${task.config.maxSteps}, tools=${toolRegistry.size}`);

  // ★ 尝试创建 agent_tasks 记录（可能已由 router/queue 创建，忽略重复）
  try {
    const { createAgentTask } = await import("./db");
    await createAgentTask({
      id: task.taskId, userId: task.userId, type: task.type,
      prompt: task.prompt, images: task.images, config: task.config,
    });
  } catch {} // 忽略 duplicate key

  // 更新任务状态为 running
  ctx.emitter.status(task.taskId, "running", "Agent 开始执行");
  await updateTaskStatus(task.taskId, "running", 0, 0);

  // 确保沙箱就绪
  await ensureSandbox(ctx);

  // ★ 启动截图流（automation 类型 + 浏览器沙箱）
  if (task.type === "automation" && task.config.sandboxMode === "browser") {
    try {
      const { startScreenshotStream } = await import("../automation/screenshotStreamer");
      startScreenshotStream(toNumericId(task.taskId), 350);
    } catch {}
  }

  let totalCost = 0;

  try {
    while (ctx.step < task.config.maxSteps && !ctx.completed && !ctx.aborted) {
      const stepStartTime = Date.now();

      // ════════════ ① 前置守卫 ════════════
      const preResult = await runPreGuards(ctx, guards.pre);
      if (preResult.intercepted) {
        if (preResult.action === "abort") {
          ctx.aborted = true;
          ctx.abortReason = preResult.message;
          break;
        }
        continue; // skip
      }

      // ════════════ ② 获取决策 ════════════
      ctx.emitter.thinking(task.taskId, "正在分析并决定下一步操作...", ctx.step);

      let decision: AgentDecision;
      try {
        decision = await getDecision(ctx, toolRegistry);
        ctx.consecutiveErrors = 0; // 决策成功，重置连续错误

        // 决策后再次检查取消（LLM 调用可能耗时较长）
        if (ctx.aborted) break;
      } catch (llmErr: any) {
        console.error(`[Orchestrator] Decision error at step ${ctx.step}:`, llmErr.message);
        await persistStep(task.taskId, ctx.step, "error", `AI 决策失败: ${llmErr.message}`);
        ctx.consecutiveErrors++;
        ctx.step++;
        await new Promise(r => setTimeout(r, 2000));
        continue;
      }

      // 记录思考
      ctx.emitter.thinking(task.taskId, decision.thought, ctx.step);
      await persistStep(task.taskId, ctx.step, "thought", decision.thought, undefined, undefined, {
        durationMs: Date.now() - stepStartTime,
      });

      // ════════════ ③ 决策后守卫 ════════════
      const postDecisionResult = await runPostDecisionGuards(ctx, decision, guards.postDecision);
      if (postDecisionResult.intercepted) {
        if (postDecisionResult.action === "abort") {
          ctx.aborted = true;
          ctx.abortReason = postDecisionResult.message;
          break;
        }
        // 有替代决策？
        if (postDecisionResult.replacementDecision) {
          decision = postDecisionResult.replacementDecision;
        } else {
          ctx.step++;
          continue; // skip
        }
      }

      // 记录 recentActions
      ctx.recentActions.push({
        tool: decision.tool,
        params: decision.params,
        url: ctx.variables.currentUrl || "",
        key: `${decision.tool}:${JSON.stringify(decision.params).substring(0, 200)}`,
      });
      if (ctx.recentActions.length > 20) ctx.recentActions.shift();

      // 将决策记录到历史（先用空 observation，后面填充）
      ctx.history.push({
        thought: decision.thought,
        action: decision.tool,
        params: decision.params,
        observation: "", // 待填充
        timestamp: Date.now(),
      });

      // ════════════ ④ 执行工具 ════════════
      ctx.step++;
      const actionStartTime = Date.now();
      let observation = "";

      try {
        ctx.emitter.observation(task.taskId, `执行: ${decision.tool}`, ctx.step);
        const toolResult = await toolRegistry.execute(decision.tool, decision.params, ctx);
        observation = toolResult.observation;

        if (toolResult.taskCompleted) {
          ctx.completed = true;
        }

        // 保存元数据到变量
        if (toolResult.metadata) {
          // browser 工具用 screenshotBase64，desktop 工具用 screenshot
          const screenshotData = toolResult.metadata.screenshotBase64 || toolResult.metadata.screenshot;
          if (screenshotData) {
            ctx.variables.lastScreenshot = screenshotData;
          }
          if (toolResult.metadata.url) {
            ctx.variables.currentUrl = toolResult.metadata.url;
          }
        }

        await persistStep(
          task.taskId, ctx.step, "action", observation.substring(0, 2000),
          decision.tool, JSON.stringify(decision.params).substring(0, 500),
          { durationMs: Date.now() - actionStartTime, ...toolResult.metadata },
        );
      } catch (actionErr: any) {
        observation = `[工具执行错误] ${decision.tool}: ${actionErr.message}`;
        ctx.consecutiveErrors++;

        await persistStep(
          task.taskId, ctx.step, "error", observation,
          decision.tool, JSON.stringify(decision.params).substring(0, 500),
          { durationMs: Date.now() - actionStartTime, error: true },
        );
      }

      // 填充历史中的 observation
      if (ctx.history.length > 0) {
        ctx.history[ctx.history.length - 1].observation = observation;
      }

      // ════════════ ⑤ 执行后守卫 ════════════
      const postActionResult = await runPostActionGuards(ctx, decision, observation, guards.postAction);
      if (postActionResult.intercepted) {
        if (postActionResult.action === "abort") {
          ctx.aborted = true;
          ctx.abortReason = postActionResult.message;
          break;
        }
      }

      // ════════════ ⑥ 更新进度 ════════════
      const progress = Math.min(95, Math.floor((ctx.step / task.config.maxSteps) * 100));
      ctx.emitter.progress(task.taskId, ctx.step, task.config.maxSteps, decision.thought.substring(0, 100));

      // 步费累计
      if (task.config.stepCost > 0) {
        totalCost += task.config.stepCost;
      }

      // 短暂暂停（避免过快循环）
      const elapsed = Date.now() - stepStartTime;
      if (elapsed < 500) {
        await new Promise(r => setTimeout(r, 500 - elapsed));
      }
    }
  } catch (fatalErr: any) {
    console.error(`[Orchestrator] Fatal error in agent loop:`, fatalErr);
    ctx.aborted = true;
    ctx.abortReason = `致命错误: ${fatalErr.message}`;
  }

  // ════════════ 后处理 ════════════
  return await finalize(ctx, task, totalCost);
}

// ═══════════════════════════════════════════
// 收尾
// ═══════════════════════════════════════════

async function finalize(ctx: LoopContext, task: AgentTask, totalCost: number): Promise<AgentResult> {
  // ★ 停止截图流 + 清理确认状态
  try {
    const { stopScreenshotStream } = await import("../automation/screenshotStreamer");
    const { clearConfirmation } = await import("../automation/confirmationManager");
    const { clearInstructions } = await import("../automation/instructionInjector");
    const tid = toNumericId(task.taskId);
    stopScreenshotStream(tid);
    clearConfirmation(tid);
    clearInstructions(tid);
  } catch {}

  // 确定最终状态
  const effectiveCompleted = ctx.completed || ctx.autoSuccessCount > 0;
  const status: AgentStatus = effectiveCompleted ? "completed"
    : ctx.aborted && ctx.abortReason?.includes("取消") ? "cancelled"
    : "failed";

  // 构建 summary
  let summary = ctx.variables.finalReport || "";
  if (!summary) {
    if (effectiveCompleted) {
      summary = ctx.autoSuccessCount > 0
        ? `任务已完成（自动检测到 ${ctx.autoSuccessCount} 项成功）`
        : "任务已完成";
    } else if (ctx.abortReason) {
      summary = ctx.abortReason;
    } else {
      summary = `任务执行了 ${ctx.step} 步后结束`;
    }
  }

  // research / codeact 的最后迭代没有 finalReport → 生成兜底报告
  if (!ctx.variables.finalReport && (task.type === "research" || task.type === "codeact") && ctx.history.length > 0) {
    try {
      const { generateFallbackReport } = await import("../research/reportGenerator");
      summary = await generateFallbackReport(task.config.llmConfig, task.prompt, ctx.history);
      ctx.variables.finalReport = summary;
    } catch {}
  }

  // 上传报告（research）
  let reportUrl = "";
  if (ctx.variables.finalReport && (task.type === "research" || task.type === "codeact")) {
    try {
      const { uploadReport } = await import("../research/taskRunner/reportFinalization");
      const taskIdNum = toNumericId(task.taskId);
      reportUrl = await uploadReport(taskIdNum, ctx.variables.finalReport);
    } catch {}
  }

  // 发射完成事件
  ctx.emitter.status(task.taskId, status, summary.substring(0, 200));
  ctx.emitter.progress(task.taskId, ctx.step, task.config.maxSteps, "完成");

  // 更新数据库
  const result: AgentResult = {
    taskId: task.taskId,
    status,
    totalSteps: ctx.step,
    totalCost,
    summary: summary.substring(0, 5000),
    reportUrl: reportUrl || undefined,
    reportContent: ctx.variables.finalReport || undefined,
    autoSuccessCount: ctx.autoSuccessCount > 0 ? ctx.autoSuccessCount : undefined,
  };

  await updateTaskStatus(task.taskId, status, ctx.step, totalCost, result);

  // 清理沙箱
  if (ctx.sandbox.alive && ctx.sandbox.type === "docker") {
    try {
      const manager = SandboxManager.getInstance();
      await manager.destroyByTaskId(task.taskId);
    } catch {}
  }

  // ★ 清理取消信号（防止内存泄漏）
  try {
    const { clearCancelSignal } = await import("./cancelRegistry");
    clearCancelSignal(task.taskId);
  } catch {}

  console.log(`[Orchestrator] Task ${task.taskId} finalized: status=${status}, steps=${ctx.step}, cost=${totalCost}🐟`);

  // ★ P0③：任务完成推送通知（SSE + 渠道通知）
  try {
    const { sendNotificationToUser } = await import("../sseNotification");
    const icon = effectiveCompleted ? "✅" : status === "cancelled" ? "🚫" : "❌";
    const title = effectiveCompleted ? "任务已完成" : status === "cancelled" ? "任务已取消" : "任务执行失败";
    sendNotificationToUser(task.userId, {
      type: `agent_${status}`,
      title: `${icon} ${title}`,
      message: `「${task.prompt.substring(0, 40)}...」${summary.substring(0, 100)}`,
      data: { taskId: task.taskId, status, steps: ctx.step },
    });
  } catch {}
  // 渠道通知（WeChat 等）
  try {
    const { notifyUserChannels } = await import("../channels/channelNotifier");
    const icon = effectiveCompleted ? "✅" : "❌";
    await notifyUserChannels(
      task.userId,
      `${icon} Agent 任务${effectiveCompleted ? "完成" : "结束"}`,
      `任务：${task.prompt.substring(0, 50)}\n状态：${status}\n步骤：${ctx.step} 步\n摘要：${summary.substring(0, 150)}`,
    );
  } catch {}

  return result;
}

// ═══════════════════════════════════════════
// 便捷入口（保持与旧代码兼容）
// ═══════════════════════════════════════════

/**
 * 从 automation 入口调用（适配旧接口）
 */
export async function runAutomationAgent(params: {
  taskId: number;
  userId: number;
  instruction: string;
  siteAccountId: number;
  siteUrl: string;
  loginUrl?: string;
  page: any;
}): Promise<AgentResult> {
  const { resolveAutomationModel } = await import("../automation/modelResolver");
  const resolved = await resolveAutomationModel(params.userId);

  const task: AgentTask = {
    taskId: String(params.taskId),
    userId: params.userId,
    type: "automation",
    prompt: params.instruction,
    config: {
      maxSteps: 55,
      stepCost: 0,
      tools: ["browser.*", "system.*"],
      sandboxMode: "browser",
      llmConfig: resolved,
      antiLoop: true,
      takeoverEnabled: true,
    },
    automationContext: {
      siteAccountId: params.siteAccountId,
      siteUrl: params.siteUrl,
      loginUrl: params.loginUrl,
      page: params.page,
      instruction: params.instruction,
    },
  };

  // ★ page 已通过 automationContext.page 传入，
  // initContext() 会自动提取到 ctx.variables.page
  return runAgentLoop(task);
}

/**
 * 从 research 入口调用（适配旧接口）
 */
export async function runResearchAgent(params: {
  taskId: number;
  userId: number;
  prompt: string;
  images?: string[];
  packageId?: number;
  sshConfig?: any;
  sshSource?: string;
  hasSSH: boolean;
  llmConfig: any;
  sandbox: any;
  onProgress: (pct: number, msg: string) => Promise<void>;
}): Promise<AgentResult> {
  // 获取定价
  let maxSteps = 30;
  let stepCost = 0;
  try {
    const { getResearchPricing } = await import("../research/researchPricing");
    const pricing = await getResearchPricing(params.packageId, params.hasSSH);
    maxSteps = pricing.maxSteps;
    stepCost = pricing.stepCost;
  } catch {}

  const task: AgentTask = {
    taskId: String(params.taskId),
    userId: params.userId,
    type: params.hasSSH ? "codeact" : "research",
    prompt: params.prompt,
    images: params.images,
    config: {
      maxSteps,
      stepCost,
      tools: params.hasSSH
        ? ["shell.*", "file.*", "web.*", "system.*"]
        : ["web.*", "system.*"],
      sandboxMode: params.hasSSH ? "ssh" : "none",
      llmConfig: params.llmConfig,
      antiLoop: false,
      takeoverEnabled: true,
    },
    researchContext: {
      sshConfig: params.sshConfig,
      sshSource: params.sshSource,
      hasSSH: params.hasSSH,
      packageId: params.packageId,
    },
  };

  return runAgentLoop(task);
}
