/**
 * agentCore/tools/browser/index.ts — 浏览器工具集
 *
 * 从 automation/agentLoop/toolExecutor.ts 的 14 个 switch case 提取而来，
 * 包装为统一 ToolDefinition 接口。
 *
 * 页面对象通过 ctx.variables.page 获取。
 * 截图/步骤记录通过 ctx.emitter 发射事件，由上层处理持久化。
 */
import type { ToolDefinition, ToolResult, LoopContext } from "../../types";
import { toNumericId } from "../../emitter";

// ═══════════════════════════════════════════
// 辅助函数
// ═══════════════════════════════════════════

function getPage(ctx: LoopContext): any {
  const page = ctx.variables.page;
  if (!page) throw new Error("浏览器页面未初始化（ctx.variables.page 为空）");
  return page;
}

async function captureScreenshot(ctx: LoopContext, label: string): Promise<string | null> {
  try {
    const page = getPage(ctx);
    const { captureAndEmit } = await import("../../../automation/pageAnalyzer");
    const taskId = toNumericId(ctx.task.taskId);
    return await captureAndEmit(page, taskId, label);
  } catch { return null; }
}

async function emitClickAt(page: any, taskId: number, el: any, desc?: string): Promise<void> {
  try {
    const box = await el.boundingBox?.() ?? await el.evaluate?.((e: any) => {
      const r = e.getBoundingClientRect();
      return r.width > 0 ? { x: r.x, y: r.y, width: r.width, height: r.height } : null;
    });
    if (box) {
      const viewport = page.viewportSize?.() || { width: 1280, height: 720 };
      const xPct = Math.round(((box.x + box.width / 2) / viewport.width) * 100);
      const yPct = Math.round(((box.y + box.height / 2) / viewport.height) * 100);
      const { emitCursorMove, emitClickIndicator } = await import("../../../socketManager/emitters");
      // ★ P1④：先移动光标到目标（前端播放移动动画），再显示点击动画
      emitCursorMove(taskId, xPct, yPct);
      // 150ms 后显示点击动画（给光标移动动画时间）
      setTimeout(() => emitClickIndicator(taskId, xPct, yPct, desc), 150);
    }
  } catch {}
}

async function gotoWithRetry(page: any, url: string, options: any, maxRetries = 1): Promise<void> {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      await page.goto(url, options);
      return;
    } catch (err: any) {
      if (attempt < maxRetries && err.message?.includes("Timeout")) {
        await new Promise(r => setTimeout(r, 2000));
      } else throw err;
    }
  }
}

function assertNotCancelled(ctx: LoopContext): void {
  if (ctx.aborted) throw new Error("TASK_CANCELLED");
}

// ═══════════════════════════════════════════
// 工具定义
// ═══════════════════════════════════════════

const browserNavigate: ToolDefinition = {
  id: "browser.navigate",
  category: "browser",
  name: "navigate",
  description: "导航到指定 URL。仅允许导航到任务目标网站域名下的页面。",
  parameters: {
    type: "object",
    properties: {
      url: { type: "string", description: "要导航到的完整 URL" },
    },
    required: ["url"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const url = params.url;
    if (!url || typeof url !== "string") throw new Error("navigate 需要有效的 URL 参数");

    // 域名限制（automation 场景）
    const siteUrl = ctx.task.automationContext?.siteUrl;
    if (siteUrl) {
      try {
        const targetHost = new URL(siteUrl).hostname;
        const navHost = new URL(url).hostname;
        if (!navHost.includes(targetHost) && !targetHost.includes(navHost)) {
          return { observation: `[错误] 禁止导航到 ${navHost}，只允许在 ${targetHost} 下操作` };
        }
      } catch {}
    }

    const { emitBrowserLoading, emitBrowserNavigate: emitNav } = await import("../../../socketManager");
    const taskIdNum = toNumericId(ctx.task.taskId);
    emitBrowserLoading(taskIdNum, url);

    try {
      await gotoWithRetry(page, url, { waitUntil: "domcontentloaded", timeout: 20000 });
    } catch (navErr: any) {
      try { await page.waitForLoadState("domcontentloaded", { timeout: 5000 }).catch(() => {}); } catch {}
      const currentUrl = page.url();
      if (currentUrl !== url && !currentUrl.includes(new URL(url).pathname)) {
        throw new Error(`导航超时: ${navErr.message}`);
      }
    }

    const { waitAfterNavigation } = await import("../../../humanSimulator");
    await waitAfterNavigation();
    const screenshot = await captureScreenshot(ctx, `导航到 ${url}`);
    emitNav(taskIdNum, url);

    return {
      observation: `已导航到 ${page.url()}`,
      metadata: { screenshotBase64: screenshot, url: page.url() },
    };
  },
};

const browserClick: ToolDefinition = {
  id: "browser.click",
  category: "browser",
  name: "click",
  description: "通过 CSS 选择器点击页面元素。如果元素不存在或不可点击，会自动尝试回退策略。",
  parameters: {
    type: "object",
    properties: {
      selector: { type: "string", description: "CSS 选择器" },
    },
    required: ["selector"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const selector = params.selector;
    if (!selector || typeof selector !== "string") throw new Error("click 需要有效的 CSS 选择器");

    assertNotCancelled(ctx);
    const clickEl = await page.$(selector);
    if (!clickEl) throw new Error(`元素不存在: ${selector}，请使用 click_text 或 click_index 代替`);

    const taskIdNum = toNumericId(ctx.task.taskId);
    await emitClickAt(page, taskIdNum, clickEl, `点击 ${selector}`);

    const { humanClick: hClick, humanDelay: hDelay } = await import("../../../humanSimulator");
    try {
      await hClick(page, selector);
    } catch {
      const href = await clickEl.getAttribute("href").catch(() => null);
      if (href && href.startsWith("/")) {
        await gotoWithRetry(page, `${new URL(page.url()).origin}${href}`, { waitUntil: "domcontentloaded", timeout: 15000 });
      } else if (href && href.startsWith("http")) {
        await gotoWithRetry(page, href, { waitUntil: "domcontentloaded", timeout: 15000 });
      } else {
        await page.click(selector, { force: true, timeout: 8000 });
      }
    }
    await hDelay(500, 1500);
    const screenshot = await captureScreenshot(ctx, `点击 ${selector}`);

    return {
      observation: `已点击元素 ${selector}`,
      metadata: { selector, screenshotBase64: screenshot },
    };
  },
};

const browserClickText: ToolDefinition = {
  id: "browser.click_text",
  category: "browser",
  name: "click_text",
  description: "通过可见文本点击页面元素（链接或按钮）。提交类文本（发布/提交/回复）会优先匹配 submit 按钮。",
  parameters: {
    type: "object",
    properties: {
      text: { type: "string", description: "要点击的可见文本" },
    },
    required: ["text"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const text = params.text;
    if (!text || typeof text !== "string") throw new Error("click_text 需要有效的文本参数");

    assertNotCancelled(ctx);
    const isSubmitLikeText = /^(发布|提交|回复|发表|发送|submit|reply|post|send)$/i.test(text.trim()) || /发布回复|发表回复|提交回复/.test(text);

    let textEl: any;
    if (isSubmitLikeText) {
      const submitLocator = page.locator('button[type="submit"], input[type="submit"]').filter({ hasText: text });
      const buttonLocator = page.getByRole("button", { name: text });
      const linkLocator = page.getByRole("link", { name: text });
      const genericLocator = page.locator(`text="${text}"`);
      const submitCount = await submitLocator.count().catch(() => 0);
      if (submitCount > 0) { textEl = submitLocator.first(); }
      else {
        const buttonCount = await buttonLocator.count().catch(() => 0);
        textEl = buttonCount > 0 ? buttonLocator.first() : linkLocator.or(genericLocator).first();
      }
    } else {
      textEl = page.getByRole("link", { name: text }).or(page.getByRole("button", { name: text })).or(page.locator(`text="${text}"`)).first();
    }

    const taskIdNum = toNumericId(ctx.task.taskId);
    await emitClickAt(page, taskIdNum, textEl, `点击 "${text}"`);
    await textEl.scrollIntoViewIfNeeded({ timeout: 8000 });
    assertNotCancelled(ctx);
    const { humanDelay: hDelay } = await import("../../../humanSimulator");
    await hDelay(200, 500);
    await textEl.click({ timeout: 10000 });
    await hDelay(500, 1500);
    const screenshot = await captureScreenshot(ctx, `点击文本 "${text}"`);

    return {
      observation: `已点击文本 "${text}"`,
      metadata: { screenshotBase64: screenshot },
    };
  },
};

const browserClickIndex: ToolDefinition = {
  id: "browser.click_index",
  category: "browser",
  name: "click_index",
  description: "通过页面元素索引号点击（索引来自页面上下文中的 interactiveElements 列表）。",
  parameters: {
    type: "object",
    properties: {
      index: { type: "number", description: "元素索引号" },
    },
    required: ["index"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const idx = params.index;
    if (typeof idx !== "number" || idx < 0) throw new Error("click_index 需要有效的索引号");

    assertNotCancelled(ctx);
    const elements = ctx.variables.interactiveElements || [];
    const targetEl = elements.find((e: any) => e.index === idx);
    if (!targetEl) throw new Error(`索引 ${idx} 不存在于元素列表中`);

    const indexEl = await page.$(targetEl.selector);
    if (!indexEl) throw new Error(`索引 ${idx} 对应的元素不存在: ${targetEl.selector}`);

    const taskIdNum = toNumericId(ctx.task.taskId);
    await emitClickAt(page, taskIdNum, indexEl, `点击 [${idx}] ${targetEl.text}`);

    const urlBeforeClick = page.url();
    const { humanDelay: hDelay } = await import("../../../humanSimulator");
    try {
      await indexEl.scrollIntoViewIfNeeded({ timeout: 3000 });
      await hDelay(200, 500);
      await indexEl.click({ timeout: 5000 });
    } catch {
      if (targetEl.href && targetEl.tag === "a") {
        await gotoWithRetry(page, targetEl.href, { waitUntil: "domcontentloaded", timeout: 15000 });
      } else {
        await indexEl.click({ force: true, timeout: 5000 });
      }
    }
    await hDelay(500, 1500);
    if (targetEl.href && targetEl.tag === "a" && page.url() === urlBeforeClick) {
      await gotoWithRetry(page, targetEl.href, { waitUntil: "domcontentloaded", timeout: 15000 });
      await hDelay(500, 1000);
    }
    const screenshot = await captureScreenshot(ctx, `点击元素 [${idx}] ${targetEl.text}`);

    return {
      observation: `已点击元素 [${idx}]: ${targetEl.text} (${targetEl.selector})`,
      metadata: { selector: targetEl.selector, screenshotBase64: screenshot },
    };
  },
};

const browserType: ToolDefinition = {
  id: "browser.type",
  category: "browser",
  name: "type",
  description: "在指定输入框中输入文本。支持占位符 __USE_GENERATED_CONTENT__ 替换为已生成的内容。",
  parameters: {
    type: "object",
    properties: {
      selector: { type: "string", description: "输入框的 CSS 选择器" },
      text: { type: "string", description: "要输入的文本内容" },
    },
    required: ["selector", "text"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const { selector, text: rawText } = params;
    if (!selector || typeof selector !== "string") throw new Error("type 需要有效的 CSS 选择器");
    if (!rawText || typeof rawText !== "string") throw new Error("type 需要有效的文本内容");

    let text = rawText;
    // 占位符替换
    if (text === "__USE_GENERATED_CONTENT__" && ctx.variables.generatedContent) {
      text = ctx.variables.generatedContent;
    }

    // 自动内容生成拦截（automation 专用）
    const selectorLower = selector.toLowerCase();
    const isContentField = selectorLower.includes("content") || selectorLower.includes("textarea") ||
      selector === "textarea" || /\#(content|editor|body|message|post-body)/.test(selector);
    const isTitleField = selectorLower.includes("title") || selectorLower.includes("subject");
    const isRealContentField = isContentField && !isTitleField;

    if (isRealContentField && !ctx.variables.contentGenerated && ctx.task.type === "automation") {
      try {
        const { generateContent, processContentImages } = await import("../../../automation/contentGenerator");
        const task = ctx.task.automationContext;
        let titleFromHistory = "";
        for (const h of ctx.history) {
          if (h.action.includes("browser.type") && h.params?.selector?.toLowerCase()?.includes("title")) {
            titleFromHistory = h.params.text || "";
          }
        }
        const topic = titleFromHistory || (rawText.length > 20 ? rawText.substring(0, 100) : "技术分享");
        let genContent = await generateContent(topic, "post", undefined, ctx.task.userId);
        if (genContent.includes("{{IMAGE:")) {
          const siteUrl = ctx.task.automationContext?.siteUrl || "";
          genContent = await processContentImages(genContent, page, siteUrl, toNumericId(ctx.task.taskId));
        }
        if (genContent && !genContent.includes("无法生成内容")) {
          text = genContent;
          ctx.variables.contentGenerated = true;
          ctx.variables.generatedContent = genContent;
        }
      } catch (e: any) {
        console.warn("[browser.type] Auto-generate content failed:", e.message);
      }
    } else if (isRealContentField && ctx.variables.contentGenerated && ctx.variables.generatedContent) {
      text = ctx.variables.generatedContent;
    }

    // 检查是否为 select 元素
    const isSelect = await page.evaluate((sel: string) => {
      const el = document.querySelector(sel);
      return el ? el.tagName.toLowerCase() === "select" : false;
    }, selector);

    if (isSelect) {
      await page.selectOption(selector, { label: text });
    } else {
      const { humanType: hType } = await import("../../../humanSimulator");
      await hType(page, selector, text);
    }

    const screenshot = await captureScreenshot(ctx, "输入文字");
    return {
      observation: `已在 ${selector} 输入文字 (${text.length} 字符)`,
      metadata: { selector, inputText: text.substring(0, 200), screenshotBase64: screenshot },
    };
  },
};

const browserScroll: ToolDefinition = {
  id: "browser.scroll",
  category: "browser",
  name: "scroll",
  description: "滚动页面。direction=down 向下滚动，direction=up 向上滚动。",
  parameters: {
    type: "object",
    properties: {
      direction: { type: "string", enum: ["down", "up"], description: "滚动方向" },
      distance: { type: "number", description: "滚动距离（像素），默认 500" },
    },
    required: [],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const direction = params.direction || "down";
    const distance = params.distance || 500;
    const { humanScroll } = await import("../../../humanSimulator");
    await humanScroll(page, direction === "down" ? distance : -distance);
    return { observation: `已滚动页面 ${direction} ${distance}px` };
  },
};

const browserWait: ToolDefinition = {
  id: "browser.wait",
  category: "browser",
  name: "wait",
  description: "等待指定秒数（用于页面加载或动画完成）。",
  parameters: {
    type: "object",
    properties: {
      seconds: { type: "number", description: "等待秒数，默认 2" },
    },
    required: [],
  },
  requiresSandbox: "browser",
  execute: async (params, _ctx) => {
    const seconds = params.seconds || 2;
    await new Promise(r => setTimeout(r, seconds * 1000));
    return { observation: `已等待 ${seconds} 秒` };
  },
};

const browserScreenshot: ToolDefinition = {
  id: "browser.screenshot",
  category: "browser",
  name: "screenshot",
  description: "截取当前页面的截图。",
  parameters: { type: "object", properties: {}, required: [] },
  requiresSandbox: "browser",
  execute: async (_params, ctx) => {
    const screenshot = await captureScreenshot(ctx, "手动截图");
    return {
      observation: "已截取页面截图",
      metadata: { screenshotBase64: screenshot },
    };
  },
};

const browserCaptcha: ToolDefinition = {
  id: "browser.captcha",
  category: "browser",
  name: "captcha",
  description: "识别并填写页面上的图片验证码。",
  parameters: {
    type: "object",
    properties: {
      imageSelector: { type: "string", description: "验证码图片的 CSS 选择器" },
      inputSelector: { type: "string", description: "验证码输入框的 CSS 选择器" },
    },
    required: ["imageSelector", "inputSelector"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const { imageSelector, inputSelector } = params;
    if (!imageSelector || !inputSelector) throw new Error("captcha 需要 imageSelector 和 inputSelector 参数");

    const { handleTextCaptcha } = await import("../../../captchaService");
    const result = await handleTextCaptcha(page, imageSelector, inputSelector);
    const screenshot = await captureScreenshot(ctx, "验证码处理");

    return {
      observation: result ? "验证码识别并填入成功" : "验证码识别失败",
      metadata: { success: result, screenshotBase64: screenshot },
    };
  },
};

const browserGenerateContent: ToolDefinition = {
  id: "browser.generate_content",
  category: "browser",
  name: "generate_content",
  description: "调用 AI 生成帖子或回复内容，并自动填入页面输入框。",
  parameters: {
    type: "object",
    properties: {
      topic: { type: "string", description: "内容主题" },
      type: { type: "string", enum: ["post", "reply"], description: "内容类型" },
    },
    required: ["topic"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const { topic, type: rawType } = params;
    const contentType = rawType === "reply" || rawType === "comment" ? "reply" : "post";

    const { generateContent, processContentImages } = await import("../../../automation/contentGenerator");
    let generatedText = await generateContent(topic, contentType, undefined, ctx.task.userId);

    if (generatedText.includes("{{IMAGE:")) {
      const siteUrl = ctx.task.automationContext?.siteUrl || "";
      generatedText = await processContentImages(generatedText, page, siteUrl, toNumericId(ctx.task.taskId));
    }

    ctx.variables.contentGenerated = true;
    ctx.variables.generatedContent = generatedText;

    // 自动填入
    const contentSelectors = ["#content", "textarea#content", 'textarea[name="content"]', "textarea", "#editor", "#post-body", "#message"];
    let autoFilled = false;
    for (const cSel of contentSelectors) {
      try {
        const el = await page.$(cSel);
        if (el) {
          const isEditable = await page.evaluate((sel: string) => {
            const e = document.querySelector(sel);
            if (!e) return false;
            const tag = e.tagName.toLowerCase();
            return tag === "textarea" || tag === "input" || (e as HTMLElement).isContentEditable;
          }, cSel);
          if (isEditable) {
            await page.fill(cSel, generatedText);
            await page.evaluate((sel: string) => {
              const e = document.querySelector(sel) as HTMLElement;
              if (!e) return;
              e.dispatchEvent(new Event("input", { bubbles: true }));
              e.dispatchEvent(new Event("change", { bubbles: true }));
              e.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: " " }));
            }, cSel);
            autoFilled = true;
            break;
          }
        }
      } catch {}
    }

    return {
      observation: `AI 已生成${contentType === "post" ? "帖子" : "回复"}内容 (${generatedText.length}字)${autoFilled ? "，并已自动填入输入框" : ""}`,
      metadata: { generatedText: generatedText.substring(0, 3000), autoFilled },
    };
  },
};

const browserSubmit: ToolDefinition = {
  id: "browser.submit",
  category: "browser",
  name: "submit",
  description: "提交当前页面的表单。自动查找并点击提交按钮，有多层降级策略。",
  parameters: { type: "object", properties: {}, required: [] },
  requiresSandbox: "browser",
  execute: async (_params, ctx) => {
    const page = getPage(ctx);
    const submitSelectors = [
      'button[type="submit"]', 'input[type="submit"]',
      "button.button.is-primary",
      'button:has-text("提交")', 'button:has-text("发布")',
      'button:has-text("回复")', 'button:has-text("发表")',
    ];
    let submitted = false;
    const urlBefore = page.url();

    for (const sel of submitSelectors) {
      try {
        const btn = await page.$(sel);
        if (btn) {
          try {
            await btn.scrollIntoViewIfNeeded({ timeout: 3000 });
            await btn.click({ timeout: 5000 });
            submitted = true;
            break;
          } catch {
            try {
              await page.evaluate((s: string) => { (document.querySelector(s) as HTMLElement)?.click(); }, sel);
              submitted = true;
              break;
            } catch {}
          }
        }
      } catch {}
    }

    if (!submitted) {
      try {
        await page.evaluate(() => {
          const form = document.querySelector("form") as HTMLFormElement;
          if (form) { form.submit(); return; }
          const btn = document.querySelector('button[type="submit"], button.is-primary') as HTMLElement;
          if (btn) btn.click();
        });
        submitted = true;
      } catch {}
    }

    const { humanDelay: hDelay } = await import("../../../humanSimulator");
    await hDelay(2000, 4000);
    const urlAfter = page.url();
    const urlChanged = urlAfter !== urlBefore;
    const screenshot = await captureScreenshot(ctx, "提交表单");

    return {
      observation: submitted
        ? urlChanged ? `表单已提交，页面跳转到 ${urlAfter}` : "表单已提交（等待页面响应）"
        : "未找到提交按钮",
      taskCompleted: submitted && urlChanged ? undefined : undefined,
      metadata: { submitted, urlChanged, screenshotBase64: screenshot },
    };
  },
};

const browserSelectOption: ToolDefinition = {
  id: "browser.select_option",
  category: "browser",
  name: "select_option",
  description: "选择下拉框中的选项。",
  parameters: {
    type: "object",
    properties: {
      selector: { type: "string", description: "下拉框的 CSS 选择器" },
      value: { type: "string", description: "选项 value 值" },
      label: { type: "string", description: "选项显示文本" },
    },
    required: ["selector"],
  },
  requiresSandbox: "browser",
  execute: async (params, ctx) => {
    const page = getPage(ctx);
    const { selector, value, label } = params;
    if (!selector) throw new Error("select_option 需要有效的 CSS 选择器");

    const selectEl = await page.$(selector);
    if (!selectEl) throw new Error(`下拉框不存在: ${selector}`);

    try {
      if (value) await page.selectOption(selector, { value: String(value) });
      else if (label) await page.selectOption(selector, { label: String(label) });
      else throw new Error("select_option 需要 value 或 label 参数");
    } catch {
      await page.evaluate(({ sel, val, lbl }: any) => {
        const el = document.querySelector(sel) as HTMLSelectElement;
        if (!el) return;
        if (val) el.value = val;
        else if (lbl) {
          const option = Array.from(el.options).find(o => o.text.trim() === lbl);
          if (option) el.value = option.value;
        }
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }, { sel: selector, val: value, lbl: label });
    }

    const screenshot = await captureScreenshot(ctx, `选择选项 ${label || value}`);
    return {
      observation: `已选择下拉框 ${selector}: ${label || value}`,
      metadata: { selector, screenshotBase64: screenshot },
    };
  },
};

// ═══════════════════════════════════════════
// 导出
// ═══════════════════════════════════════════

export const browserTools: ToolDefinition[] = [
  browserNavigate,
  browserClick,
  browserClickText,
  browserClickIndex,
  browserType,
  browserScroll,
  browserWait,
  browserScreenshot,
  browserCaptcha,
  browserGenerateContent,
  browserSubmit,
  browserSelectOption,
];
