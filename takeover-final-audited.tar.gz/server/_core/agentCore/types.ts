/**
 * agentCore/types.ts — 通用 Agent Loop 统一类型定义
 *
 * 合并 automation (agentLoopPhase) 和 research (taskRunner) 两套 Agent 的类型系统，
 * 形成所有 Agent 类型共用的类型基础。
 */
import type { Tool } from "../llm/types";

// ═══════════════════════════════════════════
// 任务 & 配置
// ═══════════════════════════════════════════

export type AgentType = "automation" | "research" | "codeact" | "general" | "desktop";
export type AgentStatus = "pending" | "running" | "paused" | "completed" | "failed" | "cancelled";
export type SandboxMode = "none" | "ssh" | "docker" | "browser" | "desktop";

/** 执行模式：tool_calling = JSON function calling（精确工具调用），codeact = LLM 直出 bash（脚本化） */
export type ExecutionMode = "tool_calling" | "codeact";

export interface LLMConfig {
  provider?: string;
  apiKey: string;
  modelName: string;
  apiEndpoint: string;
  [key: string]: any;
}

export interface AgentConfig {
  maxSteps: number;
  stepCost: number;
  tools: string[];              // 允许使用的工具 ID 列表（如 'browser.click', 'shell.exec'）
  sandboxMode: SandboxMode;
  llmConfig: LLMConfig;
  antiLoop: boolean;
  takeoverEnabled: boolean;
  skipConfirmation?: boolean;   // ★ 跳过关键操作确认（全自动批量场景）
  executionMode?: ExecutionMode; // 默认由 decisionRouter 自动判断
}

export interface AgentTask {
  taskId: string;               // UUID（统一 automation 的 number 和 research 的 number）
  userId: number;
  type: AgentType;
  prompt: string;
  images?: string[];
  config: AgentConfig;
  /** 仅 automation 类型使用 */
  automationContext?: AutomationContext;
  /** 仅 research 类型使用 */
  researchContext?: ResearchContext;
}

/** automation 专有上下文 */
export interface AutomationContext {
  siteAccountId: number;
  siteUrl: string;
  loginUrl?: string;
  page?: any;                   // Playwright Page
  instruction?: string;
}

/** research 专有上下文 */
export interface ResearchContext {
  sshConfig?: any;
  sshSource?: string;
  hasSSH: boolean;
  isSSHMode?: boolean;
  packageId?: number;
}

// ═══════════════════════════════════════════
// 循环上下文（贯穿整个 Agent Loop）
// ═══════════════════════════════════════════

export interface HistoryEntry {
  thought: string;
  action: string;
  params?: any;
  observation: string;
  timestamp?: number;
}

export interface LoopContext {
  /** 当前步骤号 */
  step: number;
  /** Agent 历史记录 */
  history: HistoryEntry[];
  /** 工具间共享状态（如 projectDir, browseVerified 等） */
  variables: Record<string, any>;
  /** 沙箱句柄 */
  sandbox: SandboxHandle;
  /** 事件发射器 */
  emitter: AgentEventEmitter;
  /** 任务引用 */
  task: AgentTask;

  // ── 计数器 ──
  consecutiveErrors: number;
  autoSuccessCount: number;
  totalLoopDetections: number;

  // ── 状态标记 ──
  completed: boolean;
  aborted: boolean;
  abortReason?: string;

  // ── 供守卫用的 recentActions（已从 automation 提取） ──
  recentActions: Array<{ tool: string; params: any; url?: string; key?: string }>;

  // ── 搜索去重集（从 research 提取） ──
  searchedQueries: Set<string>;
}

// ═══════════════════════════════════════════
// 决策
// ═══════════════════════════════════════════

export interface AgentDecision {
  /** 思考过程 */
  thought: string;
  /** 工具 ID（如 'browser.click', 'shell.exec', 'system.done'） */
  tool: string;
  /** 工具参数 */
  params: any;
  /** CodeAct 模式专用：原始 bash 脚本 */
  script?: string;
}

// ═══════════════════════════════════════════
// 工具
// ═══════════════════════════════════════════

export type ToolCategory = "browser" | "shell" | "file" | "web" | "code" | "system" | "desktop";

export interface ToolResult {
  /** 观察文本（将注入 Agent 历史） */
  observation: string;
  /** 是否表示任务完成 */
  taskCompleted?: boolean;
  /** 附加元数据（截图、文件内容等） */
  metadata?: Record<string, any>;
}

export interface ToolDefinition {
  /** 工具唯一 ID（如 'browser.click', 'shell.exec'） */
  id: string;
  category: ToolCategory;
  name: string;
  /** 给 LLM 的描述 */
  description: string;
  /** JSON Schema 格式的参数定义 */
  parameters: Record<string, any>;
  /** 需要的沙箱类型 */
  requiresSandbox?: "browser" | "docker" | "ssh";
  /** 执行函数 */
  execute: (params: any, ctx: LoopContext) => Promise<ToolResult>;
}

// ═══════════════════════════════════════════
// 沙箱
// ═══════════════════════════════════════════

export interface SandboxConfig {
  image: string;
  timeout: number;
  memory: string;
  cpu: string;
  network: boolean;
  volumes?: string[];
  sshConfig?: any;
}

export interface SandboxHandle {
  type: SandboxMode;
  containerId?: string;
  workDir: string;
  /** 沙箱是否存活 */
  alive: boolean;
  /** 类型标记用于区分实际沙箱实现 */
  _impl?: any;
}

export interface ExecResult {
  output: string;
  exitCode: number;
  timedOut: boolean;
  durationMs: number;
}

// ═══════════════════════════════════════════
// 事件
// ═══════════════════════════════════════════

export interface AgentEventEmitter {
  /** Agent 正在思考 */
  thinking: (taskId: string, thought: string, step: number) => void;
  /** Agent 正在搜索 */
  searching: (taskId: string, query: string, step: number) => void;
  /** 工具执行结果 */
  observation: (taskId: string, observation: string, step: number) => void;
  /** 进度更新 */
  progress: (taskId: string, step: number, maxSteps: number, message?: string) => void;
  /** 状态变更 */
  status: (taskId: string, status: AgentStatus, message?: string) => void;
  /** 截图 */
  screenshot: (taskId: string, base64: string) => void;
  /** 代码更新 */
  codeUpdate: (taskId: string, code: string, language: string, filename?: string) => void;
  /** 终端输出 */
  terminal: (taskId: string, command: string, output: string) => void;
  /** 浏览器导航 */
  browserNav: (taskId: string, url: string) => void;
}

// ═══════════════════════════════════════════
// 守卫
// ═══════════════════════════════════════════

export interface GuardResult {
  /** true = 已处理 */
  intercepted: boolean;
  /** skip = 跳过本步继续循环，abort = 退出循环 */
  action?: "skip" | "abort";
  /** 替换的决策 */
  replacementDecision?: AgentDecision;
  /** 附加消息 */
  message?: string;
}

export type PreGuard = (ctx: LoopContext) => Promise<GuardResult>;
export type PostDecisionGuard = (ctx: LoopContext, decision: AgentDecision) => Promise<GuardResult>;
export type PostActionGuard = (ctx: LoopContext, decision: AgentDecision, observation: string) => Promise<GuardResult>;

export interface GuardSet {
  pre: PreGuard[];
  postDecision: PostDecisionGuard[];
  postAction: PostActionGuard[];
}

// ═══════════════════════════════════════════
// 最终结果
// ═══════════════════════════════════════════

export interface AgentResult {
  taskId: string;
  status: AgentStatus;
  totalSteps: number;
  totalCost: number;
  summary: string;
  /** research 专用 */
  reportUrl?: string;
  reportContent?: string;
  /** automation 专用 */
  autoSuccessCount?: number;
}
