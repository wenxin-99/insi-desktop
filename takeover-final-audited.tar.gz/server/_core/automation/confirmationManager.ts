/**
 * confirmationManager.ts — 关键操作确认管理器
 *
 * 在 AI 执行不可逆操作（发布、提交、发送、支付）前暂停，
 * 等待用户通过 Socket 确认或拒绝。
 *
 * 对标 OpenAI Operator 的 "User Confirmations" 和 Manus 的 "Watch Mode"。
 */
import { emitSandboxEvent } from "../socketManager";

// ═══════════════ 状态存储 ═══════════════

type ConfirmStatus = "pending" | "confirmed" | "rejected" | "timeout";

interface PendingConfirmation {
  status: ConfirmStatus;
  action: string;
  description: string;
  createdAt: number;
}

const _pendingConfirmations: Map<number, PendingConfirmation> = new Map();

// 操作关键词匹配（中英文）
const SUBMIT_KEYWORDS = /^(发布|提交|发送|发表|确认|付款|支付|下单|购买|删除|submit|send|post|publish|confirm|pay|checkout|purchase|delete|order|place.?order)$/i;
const SUBMIT_PARTIAL = /(发布|提交回复|发表回复|发送消息|确认订单|确认支付|完成支付|提交订单|点击购买|confirm|submit|place order|complete purchase|send message|post reply)/i;

// 敏感 URL 模式（路径级匹配，避免误匹配 "display"、"border" 等）
const SENSITIVE_URL_PATTERNS = [
  /\/pay(ment)?[\/\?#]?/i, /\/checkout[\/\?#]?/i, /\/order[\/\?#]?/i, /\/purchase[\/\?#]?/i,
  /\/bank(ing)?[\/\?#]?/i, /\/transfer[\/\?#]?/i,
  /mail.*compose/i, /mail.*send/i,
];

// ═══════════════ 判断是否需要确认 ═══════════════

/**
 * 判断一个 AgentDecision 是否属于"不可逆关键操作"
 */
export function isSensitiveAction(
  tool: string,
  params: any,
  currentUrl?: string,
): { sensitive: boolean; reason: string } {
  // 1. click_text 匹配发布/提交类关键词
  if (tool === "browser.click_text") {
    const text = String(params?.text || "").trim();
    if (SUBMIT_KEYWORDS.test(text)) {
      return { sensitive: true, reason: `即将点击「${text}」按钮` };
    }
    if (SUBMIT_PARTIAL.test(text)) {
      return { sensitive: true, reason: `即将点击「${text}」` };
    }
  }

  // 2. click 匹配 submit 按钮选择器
  if (tool === "browser.click") {
    const sel = String(params?.selector || "");
    if (/type=["']?submit/i.test(sel) || /submit/i.test(sel)) {
      return { sensitive: true, reason: `即将点击提交按钮 (${sel.substring(0, 60)})` };
    }
  }

  // 3. click_index 点击的描述包含提交关键词
  if (tool === "browser.click_index") {
    const desc = String(params?.description || params?.text || "");
    if (SUBMIT_PARTIAL.test(desc)) {
      return { sensitive: true, reason: `即将点击「${desc}」` };
    }
  }

  // 4. 在敏感 URL 上进行任何点击操作
  if (currentUrl && (tool === "browser.click" || tool === "browser.click_text" || tool === "browser.click_index")) {
    for (const pattern of SENSITIVE_URL_PATTERNS) {
      if (pattern.test(currentUrl)) {
        return { sensitive: true, reason: `在敏感页面上操作 (${currentUrl.substring(0, 80)})` };
      }
    }
  }

  return { sensitive: false, reason: "" };
}

// ═══════════════ 发起确认请求 ═══════════════

/**
 * 向前端发送确认请求，返回 Promise 等待用户响应
 * 超时 60 秒自动确认（避免无人值守时死锁）
 */
export async function requestConfirmation(
  taskId: number,
  action: string,
  description: string,
  screenshotBase64?: string,
  timeoutMs: number = 60000,
): Promise<"confirmed" | "rejected" | "timeout"> {
  // 记录状态
  _pendingConfirmations.set(taskId, {
    status: "pending",
    action,
    description,
    createdAt: Date.now(),
  });

  // 向前端发送确认请求
  emitSandboxEvent({
    type: "confirmation_required" as any,
    taskId,
    timestamp: Date.now(),
    payload: {
      action,
      description,
      screenshot: screenshotBase64 || "",
      timeoutMs,
    },
  });

  // 轮询等待用户响应
  const pollInterval = 500;
  const maxWait = timeoutMs;
  let waited = 0;

  while (waited < maxWait) {
    await new Promise(r => setTimeout(r, pollInterval));
    waited += pollInterval;

    const pending = _pendingConfirmations.get(taskId);
    if (!pending || pending.status !== "pending") {
      const result = pending?.status || "timeout";
      _pendingConfirmations.delete(taskId);
      return result as "confirmed" | "rejected" | "timeout";
    }
  }

  // 超时 — 默认自动确认（避免死锁，但记录日志）
  console.warn(`[ConfirmationManager] Task ${taskId}: confirmation timed out after ${timeoutMs}ms, auto-confirming`);
  _pendingConfirmations.delete(taskId);
  return "timeout";
}

// ═══════════════ 用户响应 ═══════════════

/**
 * 用户通过 Socket 确认或拒绝
 */
export function resolveConfirmation(taskId: number, confirmed: boolean): void {
  const pending = _pendingConfirmations.get(taskId);
  if (!pending || pending.status !== "pending") {
    console.warn(`[ConfirmationManager] Task ${taskId}: no pending confirmation to resolve`);
    return;
  }
  pending.status = confirmed ? "confirmed" : "rejected";
  console.log(`[ConfirmationManager] Task ${taskId}: user ${confirmed ? "confirmed" : "rejected"} action "${pending.action}"`);
}

/**
 * 检查是否有待处理的确认
 */
export function hasPendingConfirmation(taskId: number): boolean {
  const p = _pendingConfirmations.get(taskId);
  return !!p && p.status === "pending";
}

/**
 * 清理任务的确认状态（任务结束时调用）
 */
export function clearConfirmation(taskId: number): void {
  _pendingConfirmations.delete(taskId);
}
