/**
 * instructionInjector.ts — 任务中途指令注入
 *
 * 对标 ChatGPT Agent 的"中途追加指令"体验：
 * 用户在任务执行中通过聊天框发消息（如"不要这家，换一家"），
 * Agent 在下一步开始前读取并调整行为，无需接管浏览器。
 *
 * 与 takeover 模式的区别：
 * - takeover = 暂停 AI，用户亲自操作浏览器
 * - instruction = 不暂停 AI，注入新指令到 AI 决策上下文
 */

// ═══════════════ 指令队列 ═══════════════

const _pendingInstructions: Map<number, string[]> = new Map();

/**
 * 添加指令到任务队列
 */
export function pushInstruction(taskId: number, instruction: string): void {
  if (!_pendingInstructions.has(taskId)) {
    _pendingInstructions.set(taskId, []);
  }
  _pendingInstructions.get(taskId)!.push(instruction);
  console.log(`[InstructionInjector] Task ${taskId}: queued instruction: "${instruction.substring(0, 80)}"`);
}

/**
 * 消费所有待处理指令（读后清空）
 * 返回合并后的单条指令文本，或 null
 */
export function consumeInstructions(taskId: number): string | null {
  const queue = _pendingInstructions.get(taskId);
  if (!queue || queue.length === 0) return null;

  const merged = queue.join("\n");
  _pendingInstructions.delete(taskId);
  return merged;
}

/**
 * 检查是否有待处理指令
 */
export function hasPendingInstructions(taskId: number): boolean {
  const q = _pendingInstructions.get(taskId);
  return !!q && q.length > 0;
}

/**
 * 清理指令队列（任务结束时调用）
 */
export function clearInstructions(taskId: number): void {
  _pendingInstructions.delete(taskId);
}
