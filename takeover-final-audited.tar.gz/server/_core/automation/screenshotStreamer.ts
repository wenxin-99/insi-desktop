/**
 * screenshotStreamer.ts — 定时截图推送
 *
 * 对标 Operator/Manus 的近实时浏览器画面：
 * 在 AI 执行期间以 300-500ms 间隔持续推送截图，
 * 而非仅在操作后才推送。用户看到的是"视频流"而非"幻灯片"。
 *
 * 策略：
 * - AI 操作期间：300ms 间隔（高频）
 * - 接管模式下：不推送（由 takeover action 回调负责）
 * - 空闲等待时：2000ms 间隔（低频保活）
 */
import { activeTaskPages, takeoverMode } from "./browserManager";
import { emitBrowserScreenshot } from "../socketManager";

// ═══════════════ 活跃流管理 ═══════════════

const _activeStreamers: Map<number, ReturnType<typeof setInterval>> = new Map();
const _lastScreenshotHash: Map<number, string> = new Map();
const _busy: Set<number> = new Set(); // 防止 async 截图重叠

/** 启动截图流 */
export function startScreenshotStream(taskId: number, intervalMs: number = 350): void {
  // 防止重复启动
  if (_activeStreamers.has(taskId)) return;

  console.log(`[ScreenshotStreamer] Task ${taskId}: starting stream (${intervalMs}ms)`);

  const timer = setInterval(async () => {
    // ★ 防并发：上一次截图还没完成就跳过
    if (_busy.has(taskId)) return;
    _busy.add(taskId);

    try {
      // 接管模式下跳过（由用户操作回调负责截图）
      if (takeoverMode.get(taskId)) return;

      const page = activeTaskPages.get(taskId);
      if (!page) {
        // 页面不存在，停止流
        stopScreenshotStream(taskId);
        return;
      }

      // 检查页面是否存活
      let url: string;
      try {
        url = page.url();
      } catch {
        stopScreenshotStream(taskId);
        return;
      }

      // 截图
      const buffer = await page.screenshot({
        type: "jpeg",
        quality: 55, // 稍低质量换取更小体积和更快传输
        timeout: 3000,
      }) as Buffer;

      // 简易去重：比较 buffer 长度 + 前 200 字节 hash
      // 避免页面静止时反复推送完全相同的截图
      const quickHash = `${buffer.length}:${buffer.slice(0, 200).toString("base64").substring(0, 40)}`;
      if (quickHash === _lastScreenshotHash.get(taskId)) return;
      _lastScreenshotHash.set(taskId, quickHash);

      const base64 = buffer.toString("base64");
      emitBrowserScreenshot(taskId, base64, url);
    } catch (err: any) {
      // 截图失败不要 crash 整个 interval
      // 常见原因：页面导航中、target closed
      if (err.message?.includes("closed") || err.message?.includes("destroyed")) {
        stopScreenshotStream(taskId);
      }
    } finally {
      _busy.delete(taskId);
    }
  }, intervalMs);

  _activeStreamers.set(taskId, timer);
}

/** 停止截图流 */
export function stopScreenshotStream(taskId: number): void {
  const timer = _activeStreamers.get(taskId);
  if (timer) {
    clearInterval(timer);
    _activeStreamers.delete(taskId);
    _lastScreenshotHash.delete(taskId);
    _busy.delete(taskId);
    console.log(`[ScreenshotStreamer] Task ${taskId}: stream stopped`);
  }
}

/** 调整截图频率（如进入空闲等待时降频） */
export function adjustStreamInterval(taskId: number, intervalMs: number): void {
  if (!_activeStreamers.has(taskId)) return;
  stopScreenshotStream(taskId);
  startScreenshotStream(taskId, intervalMs);
}

/** 清理所有流（进程关闭时调用） */
export function stopAllStreams(): void {
  for (const [taskId] of _activeStreamers) {
    stopScreenshotStream(taskId);
  }
}
