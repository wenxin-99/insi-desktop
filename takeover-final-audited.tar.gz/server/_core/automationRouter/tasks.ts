/**
 * 自动化路由 - 任务管理与控制
 */
import { Router, Request, Response } from "express";
import { getDb } from "../../db";
import { getRawPool } from "../../db/connection";
import {
  siteAccounts, automationTasks, automationTaskSteps, automationContents,
} from "../../../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";
import {
  executeAutomationTask, pauseAutomationTask, resumeAutomationTask,
  cancelAutomationTask, enableTakeover, disableTakeover,
} from "../automationService";
import { requireAuth } from "./auth";

const router = Router();

// ★ #59/#60 修复：确保 automation 相关表有 taskId 索引
// 首次加载时异步执行，不阻塞路由注册
(async () => {
  try {
    const pool = await getRawPool();
    if (!pool) return;

    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_auto_task_steps_taskid ON automation_task_steps (task_id)',
      'CREATE INDEX IF NOT EXISTS idx_auto_contents_taskid ON automation_contents (task_id)',
      'CREATE INDEX IF NOT EXISTS idx_auto_tasks_userid ON automation_tasks (user_id, created_at)',
    ];
    for (const sql of indexes) {
      try { await pool.execute(sql); } catch {}
    }
    console.log('[AutomationTasks] Indexes ensured');
  } catch (e: any) {
    console.warn('[AutomationTasks] Index ensure failed (non-fatal):', e.message);
  }
})();

/** 获取所有任务 */
router.get("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const db = await getDb();
    const userId = (req as any).userId;
    const tasks = await db.select()
      .from(automationTasks)
      .where(eq(automationTasks.userId, userId))
      .orderBy(desc(automationTasks.createdAt));
    
    res.json({ tasks });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 获取单个任务详情（含步骤） */
router.get("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const db = await getDb();
    const userId = (req as any).userId;
    const taskId = parseInt(req.params.id);
    
    const [task] = await db.select()
      .from(automationTasks)
      .where(and(eq(automationTasks.id, taskId), eq(automationTasks.userId, userId)));
    
    if (!task) {
      return res.status(404).json({ error: "任务不存在" });
    }
    
    // ★ #59/#60 修复：3 个子查询并行执行（原串行 30s+ → 并行 ~5s）
    const [steps, contents, accountArr] = await Promise.all([
      // 获取任务步骤（不含大的 base64 截图）
      db.select({
        id: automationTaskSteps.id,
        stepNumber: automationTaskSteps.stepNumber,
        type: automationTaskSteps.type,
        content: automationTaskSteps.content,
        screenshotUrl: automationTaskSteps.screenshotUrl,
        selector: automationTaskSteps.selector,
        inputText: automationTaskSteps.inputText,
        durationMs: automationTaskSteps.durationMs,
        success: automationTaskSteps.success,
        errorMessage: automationTaskSteps.errorMessage,
        createdAt: automationTaskSteps.createdAt,
      })
      .from(automationTaskSteps)
      .where(eq(automationTaskSteps.taskId, taskId))
      .orderBy(automationTaskSteps.stepNumber),

      // 获取生成的内容
      db.select()
        .from(automationContents)
        .where(eq(automationContents.taskId, taskId)),

      // 获取关联的站点账号信息
      db.select({
        id: siteAccounts.id,
        siteName: siteAccounts.siteName,
        siteUrl: siteAccounts.siteUrl,
        username: siteAccounts.username,
      })
      .from(siteAccounts)
      .where(eq(siteAccounts.id, task.siteAccountId)),
    ]);

    const account = accountArr[0] || null;

    // ★ 获取最后一步的截图（刷新后恢复浏览器预览）
    let lastScreenshot: string | null = null;
    try {
      const lastStepWithScreenshot = await db.select({
        screenshotBase64: automationTaskSteps.screenshotBase64,
      })
      .from(automationTaskSteps)
      .where(eq(automationTaskSteps.taskId, taskId))
      .orderBy(desc(automationTaskSteps.stepNumber))
      .limit(3); // 取最后3步，找有截图的
      for (const s of lastStepWithScreenshot) {
        if (s.screenshotBase64) { lastScreenshot = s.screenshotBase64; break; }
      }
    } catch {}
    
    res.json({ task, steps, contents, account, lastScreenshot });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 获取任务步骤的截图 */
router.get("/:taskId/steps/:stepId/screenshot", requireAuth, async (req: Request, res: Response) => {
  try {
    const db = await getDb();
    const stepId = parseInt(req.params.stepId);
    
    const [step] = await db.select({
      screenshotBase64: automationTaskSteps.screenshotBase64,
    })
    .from(automationTaskSteps)
    .where(eq(automationTaskSteps.id, stepId));
    
    if (!step?.screenshotBase64) {
      return res.status(404).json({ error: "截图不存在" });
    }
    
    res.json({ screenshot: `data:image/jpeg;base64,${step.screenshotBase64}` });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 创建新任务 */
router.post("/", requireAuth, async (req: Request, res: Response) => {
  try {
    const db = await getDb();
    const userId = (req as any).userId;
    const {
      siteAccountId, taskType, name, instruction,
      targetUrls, searchKeywords, contentStyle, modelUsed,
    } = req.body;
    
    if (!siteAccountId || !name || !instruction) {
      return res.status(400).json({ error: "缺少必填字段" });
    }
    
    // 验证站点账号存在
    const [account] = await db.select()
      .from(siteAccounts)
      .where(and(eq(siteAccounts.id, siteAccountId), eq(siteAccounts.userId, userId)));
    
    if (!account) {
      return res.status(404).json({ error: "站点账号不存在" });
    }
    
    const result = await db.insert(automationTasks).values({
      userId,
      siteAccountId,
      taskType: taskType || "custom",
      name,
      instruction,
      targetUrls: targetUrls ? JSON.stringify(targetUrls) : null,
      searchKeywords: searchKeywords ? JSON.stringify(searchKeywords) : null,
      contentStyle: contentStyle || null,
      modelUsed: modelUsed || "gpt-4.1-mini",
    });
    
    const taskId = (result as any)[0]?.insertId;
    res.json({ success: true, taskId });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 启动任务执行 */
router.post("/:id/start", requireAuth, async (req: Request, res: Response) => {
  try {
    const db = await getDb();
    const userId = (req as any).userId;
    const taskId = parseInt(req.params.id);
    
    const [task] = await db.select()
      .from(automationTasks)
      .where(and(eq(automationTasks.id, taskId), eq(automationTasks.userId, userId)));
    
    if (!task) {
      return res.status(404).json({ error: "任务不存在" });
    }
    
    if (task.status === "running") {
      return res.status(400).json({ error: "任务已在运行中" });
    }
    
    // 异步启动任务（不阻塞响应）
    res.json({ success: true, message: "任务已启动" });
    
    executeAutomationTask(taskId).catch(err => {
      console.error(`[AutomationRouter] Task ${taskId} execution error:`, err.message);
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 暂停任务 */
router.post("/:id/pause", requireAuth, async (req: Request, res: Response) => {
  try {
    const taskId = parseInt(req.params.id);
    await pauseAutomationTask(taskId);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 取消任务 */
router.post("/:id/cancel", requireAuth, async (req: Request, res: Response) => {
  try {
    const taskId = parseInt(req.params.id);
    await cancelAutomationTask(taskId);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 恢复暂停的任务 */
router.post("/:id/resume", requireAuth, async (req: Request, res: Response) => {
  try {
    const taskId = parseInt(req.params.id);
    await resumeAutomationTask(taskId);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

/** 删除任务 */
router.delete("/:id", requireAuth, async (req: Request, res: Response) => {
  try {
    const db = await getDb();
    const userId = (req as any).userId;
    const taskId = parseInt(req.params.id);
    
    // 先校验所有权
    const [task] = await db.select({ id: automationTasks.id })
      .from(automationTasks)
      .where(and(eq(automationTasks.id, taskId), eq(automationTasks.userId, userId)));
    if (!task) return res.status(403).json({ error: "无权删除此任务" });
    
    // 通过后再删除关联数据
    await db.delete(automationTaskSteps).where(eq(automationTaskSteps.taskId, taskId));
    await db.delete(automationContents).where(eq(automationContents.taskId, taskId));
    await db.delete(automationTasks)
      .where(and(eq(automationTasks.id, taskId), eq(automationTasks.userId, userId)));
    
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ============ 用户接管模式 ============

router.post("/:id/takeover/enable", requireAuth, async (req: Request, res: Response) => {
  const taskId = parseInt(req.params.id);
  const userId = (req as any).userId;
  try {
    // ★ 安全校验：验证任务归属
    const ownerOk = await verifyTaskOwnership(taskId, userId);
    if (!ownerOk) {
      return res.status(403).json({ success: false, message: "无权操作此任务" });
    }
    const success = await enableTakeover(taskId);
    if (success) {
      res.json({ success: true, message: "接管模式已启用" });
    } else {
      res.json({ success: true, message: "接管模式已启用（无活跃浏览器页面）" });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post("/:id/takeover/disable", requireAuth, async (req: Request, res: Response) => {
  const taskId = parseInt(req.params.id);
  const userId = (req as any).userId;
  try {
    const ownerOk = await verifyTaskOwnership(taskId, userId);
    if (!ownerOk) {
      return res.status(403).json({ success: false, message: "无权操作此任务" });
    }
    await disableTakeover(taskId);
    res.json({ success: true, message: "接管模式已关闭" });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * 验证任务归属：检查 automationTasks 或 researchTasks
 */
export async function verifyTaskOwnership(taskId: number, userId: number): Promise<boolean> {
  try {
    const { getDb } = await import("../../db");
    const db = await getDb();
    if (!db) return false;

    // 先查 automationTasks
    const { automationTasks } = await import("../../../drizzle/schema");
    const { eq, and } = await import("drizzle-orm");
    const [autoTask] = await db.select({ id: automationTasks.id })
      .from(automationTasks)
      .where(and(eq(automationTasks.id, taskId), eq(automationTasks.userId, userId)))
      .limit(1);
    if (autoTask) return true;

    // 再查 researchTasks
    const { researchTasks } = await import("../../../drizzle/schema");
    const [researchTask] = await db.select({ id: researchTasks.id })
      .from(researchTasks)
      .where(and(eq(researchTasks.id, taskId), eq(researchTasks.userId, userId)))
      .limit(1);
    if (researchTask) return true;

    return false;
  } catch {
    return false;
  }
}

export default router;
