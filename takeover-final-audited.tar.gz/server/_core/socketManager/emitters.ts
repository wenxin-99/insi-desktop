import { getIO } from "./index";
import { SandboxEvent } from "./types";
import { bufferEvent } from "./buffer";

/**
 * 向特定任务房间广播沙箱事件
 */
export function emitSandboxEvent(event: SandboxEvent): void {
  // 缓冲事件，以便断线重连的客户端能回放
  bufferEvent(event);
  
  const io = getIO();
  if (!io) {
    console.warn("[SocketIO] Server not initialized, cannot emit event");
    return;
  }
  const room = `task_${event.taskId}`;
  io.to(room).emit("sandbox_event", event);
}

/**
 * 向特定任务广播浏览器导航事件
 */
export function emitBrowserNavigate(taskId: number, url: string): void {
  emitSandboxEvent({
    type: "browser_navigate",
    taskId,
    timestamp: Date.now(),
    payload: { url },
  });
}

/**
 * 向特定任务广播浏览器截图
 */
export function emitBrowserScreenshot(
  taskId: number,
  screenshotBase64: string,
  url: string,
  title?: string
): void {
  emitSandboxEvent({
    type: "browser_screenshot",
    taskId,
    timestamp: Date.now(),
    payload: { screenshot: screenshotBase64, url, title: title || "" },
  });
}

/**
 * 向特定任务广播浏览器加载状态
 */
export function emitBrowserLoading(taskId: number, url: string): void {
  emitSandboxEvent({
    type: "browser_loading",
    taskId,
    timestamp: Date.now(),
    payload: { url },
  });
}

/**
 * 向特定任务广播代码更新
 */
export function emitCodeUpdate(
  taskId: number,
  code: string,
  language: string,
  filename?: string
): void {
  emitSandboxEvent({
    type: "code_update",
    taskId,
    timestamp: Date.now(),
    payload: { code, language, filename: filename || "output" },
  });
}

/**
 * 向特定任务广播终端命令
 */
export function emitTerminalCommand(taskId: number, command: string): void {
  emitSandboxEvent({
    type: "terminal_command",
    taskId,
    timestamp: Date.now(),
    payload: { command },
  });
}

/**
 * 向特定任务广播终端输出
 */
export function emitTerminalOutput(taskId: number, output: string): void {
  emitSandboxEvent({
    type: "terminal_output",
    taskId,
    timestamp: Date.now(),
    payload: { output },
  });
}

/**
 * 清除终端缓冲区（空操作，保持兼容性）
 */
export function clearTerminalBuffer(taskId: number): void {}

/**
 * 向特定任务广播 Agent 思考状态
 */
export function emitAgentThinking(taskId: number, thought: string): void {
  emitSandboxEvent({
    type: "agent_thinking",
    taskId,
    timestamp: Date.now(),
    payload: { thought },
  });
}

/**
 * ★ AI 主动请求用户协同（验证码、登录失败、操作卡住等）
 */
export function emitHelpNeeded(taskId: number, reason: string, category: 'captcha' | 'login' | 'stuck' | 'confirm' | 'other' = 'other'): void {
  emitSandboxEvent({
    type: "help_needed" as any,
    taskId,
    timestamp: Date.now(),
    payload: { reason, category },
  });
}

/**
 * 向特定任务广播 Agent 搜索状态
 */
export function emitAgentSearching(taskId: number, query: string): void {
  emitSandboxEvent({
    type: "agent_searching",
    taskId,
    timestamp: Date.now(),
    payload: { query },
  });
}

/**
 * 向特定任务广播 Agent 步骤完成
 */
export function emitAgentStep(
  taskId: number,
  stepType: string,
  content: string,
  stepNumber: number
): void {
  emitSandboxEvent({
    type: "agent_step",
    taskId,
    timestamp: Date.now(),
    payload: { stepType, content, stepNumber },
  });
}

/**
 * 向特定任务广播任务状态变更
 */
export function emitTaskStatus(
  taskId: number,
  status: string,
  message?: string
): void {
  emitSandboxEvent({
    type: "task_status",
    taskId,
    timestamp: Date.now(),
    payload: { status, message: message || "" },
  });
}

/**
 * 向特定任务广播任务进度
 */
export function emitTaskProgress(
  taskId: number,
  progress: number,
  currentStep: string
): void {
  emitSandboxEvent({
    type: "task_progress",
    taskId,
    timestamp: Date.now(),
    payload: { progress, currentStep },
  });
}

/**
 * 向特定任务广播接管模式状态
 */
export function emitTakeoverStatus(taskId: number, active: boolean, message?: string): void {
  emitSandboxEvent({
    type: "takeover_status" as any,
    taskId,
    timestamp: Date.now(),
    payload: { active, message: message || "" },
  });
}

/**
 * 向特定任务广播点击指示器（在浏览器预览上显示点击动画）
 */
export function emitClickIndicator(taskId: number, x: number, y: number, description?: string): void {
  emitSandboxEvent({
    type: "browser_click_indicator" as any,
    taskId,
    timestamp: Date.now(),
    payload: { x, y, description: description || "" },
  });
}

/**
 * ★ P1④：AI 光标位置广播（在点击前先移动光标到目标位置）
 */
export function emitCursorMove(taskId: number, x: number, y: number): void {
  emitSandboxEvent({
    type: "cursor_move" as any,
    taskId,
    timestamp: Date.now(),
    payload: { x, y },
  });
}

/**
 * ★ P1④：AI 操作预告（在执行前告知前端 AI 即将做什么）
 */
export function emitAgentAction(taskId: number, action: string, description: string): void {
  emitSandboxEvent({
    type: "agent_action_preview" as any,
    taskId,
    timestamp: Date.now(),
    payload: { action, description },
  });
}

/**
 * 向特定任务广播截图状态提示（超时时通知前端显示友好提示）
 */
export function emitScreenshotStatus(taskId: number, status: "timeout" | "recovered", message?: string): void {
  emitSandboxEvent({
    type: "screenshot_status" as any,
    taskId,
    timestamp: Date.now(),
    payload: { status, message: message || "" },
  });
}
