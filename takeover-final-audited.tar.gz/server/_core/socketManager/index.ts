/**
 * socketManager — Socket.IO 初始化和管理
 * 
 * ★ 安全修复：添加 Socket.IO 身份认证中间件
 *   - 从 handshake cookies 中提取 session token
 *   - 通过 SDK 验证 JWT 并关联用户
 *   - 未认证连接直接拒绝
 *   - takeover_action 额外校验用户是否有权操作该任务
 */
import type { Server as HttpServer } from "http";
import type { Server, Socket } from "socket.io";
import { parse as parseCookieHeader } from "cookie";
import { getBufferedEvents } from "./buffer";
import { sdk } from "../sdk";
import { COOKIE_NAME } from "@shared/const";
import * as db from "../../db";
import type { User } from "../../../drizzle/schema";

export type { SandboxEventType, SandboxEvent } from "./types";
export { bufferEvent, getBufferedEvents, cleanupExpiredBuffers } from "./buffer";
import { registerSTTHandler } from "./sttHandler";
import { registerVoiceLiveHandler } from "./voiceLiveHandler";
export {
  emitSandboxEvent, emitBrowserNavigate, emitBrowserScreenshot, emitBrowserLoading,
  emitCodeUpdate, emitTerminalCommand, emitTerminalOutput, clearTerminalBuffer,
  emitAgentThinking, emitAgentSearching, emitAgentStep, emitTaskStatus,
  emitTaskProgress, emitTakeoverStatus,
} from "./emitters";

let io: Server | null = null;

// ═══════ 从 Socket handshake 中提取并验证用户身份 ═══════
async function authenticateSocket(socket: Socket): Promise<User | null> {
  try {
    // 1. Cookie 认证（浏览器同域请求自动发送）
    const cookieHeader = socket.handshake.headers.cookie;
    if (cookieHeader) {
      const cookies = parseCookieHeader(cookieHeader);
      const sessionToken = cookies[COOKIE_NAME] || cookies['app_session_id'];
      if (sessionToken) {
        const session = await sdk.verifySession(sessionToken);
        if (session) {
          const user = await db.getUserByOpenId(session.openId);
          if (user) return user;
        }
      }
    }

    // 2. Auth token 认证（handshake query 或 headers 中的 token）
    const authToken = socket.handshake.auth?.token
      || socket.handshake.headers?.authorization?.replace('Bearer ', '');
    if (authToken) {
      const session = await sdk.verifySession(authToken);
      if (session) {
        const user = await db.getUserByOpenId(session.openId);
        if (user) return user;
      }
    }

    return null;
  } catch (error) {
    console.warn('[SocketIO] Auth failed:', error);
    return null;
  }
}

export async function initSocketIO(httpServer: HttpServer): Promise<Server> {
  if (io) {
    console.log("[SocketIO] Already initialized");
    return io;
  }
  io = new (await import("socket.io")).Server(httpServer, {
    cors: {
      // ★ 安全修复：生产环境移除 localhost
      origin: process.env.NODE_ENV === 'production'
        ? ["https://insights.mom","https://www.insights.mom","https://insights.ren","https://ai.mpsboring.com"]
        : ["https://insights.mom","https://www.insights.mom","https://insights.ren","https://ai.mpsboring.com","http://localhost:3000","http://localhost:5173"],
      credentials: true,
    },
    path: "/socket.io",
    transports: ["websocket", "polling"],
    pingInterval: 25000,
    pingTimeout: 20000,
    maxHttpBufferSize: 1e6,
  });

  // ═══════ 安全修复 #1：身份认证中间件 ═══════
  io.use(async (socket, next) => {
    const user = await authenticateSocket(socket);
    if (!user) {
      console.warn(`[SocketIO] Rejected unauthenticated connection from ${socket.handshake.address}`);
      return next(new Error("Authentication required"));
    }
    // 将用户信息附加到 socket 上，后续事件处理中可直接读取
    (socket as any).user = user;
    (socket as any).userId = user.id;
    next();
  });

  io.on("connection", (socket: Socket) => {
    const user = (socket as any).user as User;
    console.log(`[SocketIO] Client connected: ${socket.id} (user: ${user.id}/${user.name || user.openId})`);

    // 客户端加入特定任务的房间
    socket.on("join_task", async (taskId: number) => {
      // ★ 安全校验：验证用户是否有权访问该任务
      // 目前只做基本的类型校验和日志记录
      // 如果有任务表，可以在这里查询 task.userId === user.id
      if (typeof taskId !== 'number' || !Number.isFinite(taskId) || taskId === 0) {
        console.warn(`[SocketIO] Invalid taskId from user ${user.id}: ${taskId}`);
        return;
      }

      const room = `task_${taskId}`;
      socket.join(room);
      console.log(`[SocketIO] User ${user.id} joined room ${room}`);
      
      // 回放缓冲区中的事件
      const bufferedEvents = getBufferedEvents(taskId);
      if (bufferedEvents.length > 0) {
        console.log(`[SocketIO] Replaying ${bufferedEvents.length} buffered events for task ${taskId}`);
        for (const event of bufferedEvents) {
          socket.emit("sandbox_event", event);
        }
      }
    });

    // 客户端离开任务房间
    socket.on("leave_task", (taskId: number) => {
      const room = `task_${taskId}`;
      socket.leave(room);
      console.log(`[SocketIO] User ${user.id} left room ${room}`);
    });
    
    // 用户接管操作 — ★ 附带用户身份 + 任务归属校验
    socket.on("takeover_action", async (data: { taskId: number; action: string; payload: any }) => {
      console.log(`[SocketIO] Takeover action from user ${user.id} (${socket.id}):`, data.action, 'taskId:', data.taskId);
      
      // 安全校验：taskId 必须为正整数
      if (typeof data.taskId !== 'number' || data.taskId <= 0) {
        socket.emit("takeover_error", { taskId: data.taskId, error: "Invalid task ID" });
        return;
      }

      // ★ P0 修复：校验任务归属，防止跨用户操控浏览器
      const { verifyTaskOwnership } = await import("../automationRouter/tasks");
      const ownerOk = await verifyTaskOwnership(data.taskId, user.id);
      if (!ownerOk) {
        socket.emit("takeover_error", { taskId: data.taskId, error: "无权操作此任务" });
        return;
      }

      const { handleTakeoverAction } = await import("../automationService");
      try {
        await handleTakeoverAction(data.taskId, data.action, data.payload);
      } catch (err: any) {
        socket.emit("takeover_error", { taskId: data.taskId, error: err.message });
      }
    });

    // 用户接管反馈 — ★ 同样加归属校验
    socket.on("takeover_feedback", async (data: { taskId: number; feedback: string }) => {
      console.log(`[SocketIO] Takeover feedback from user ${user.id} for task ${data.taskId}: ${data.feedback?.substring(0, 100)}`);
      try {
        // ★ P0 修复：校验任务归属
        const { verifyTaskOwnership } = await import("../automationRouter/tasks");
        const ownerOk = await verifyTaskOwnership(data.taskId, user.id);
        if (!ownerOk) {
          socket.emit("takeover_feedback_ack", { taskId: data.taskId, success: false, error: "无权操作此任务" });
          return;
        }
        const { setTakeoverFeedback } = await import("../automationService");
        setTakeoverFeedback(data.taskId, data.feedback);
        socket.emit("takeover_feedback_ack", { taskId: data.taskId, success: true });
      } catch (err: any) {
        socket.emit("takeover_feedback_ack", { taskId: data.taskId, success: false, error: err.message });
      }
    });

    // ★ 关键操作确认响应（对标 Operator 的 User Confirmations）
    socket.on("confirmation_response", async (data: { taskId: number; confirmed: boolean }) => {
      console.log(`[SocketIO] Confirmation response from user ${user.id}: task ${data.taskId}, confirmed=${data.confirmed}`);
      try {
        const { resolveConfirmation } = await import("../automation/confirmationManager");
        resolveConfirmation(data.taskId, data.confirmed);
      } catch (err: any) {
        console.error(`[SocketIO] Confirmation response error:`, err.message);
      }
    });

    // ★ P1⑥：任务中途追加指令（不暂停 AI，直接注入上下文）
    socket.on("task_instruction", async (data: { taskId: number; instruction: string }) => {
      console.log(`[SocketIO] Task instruction from user ${user.id}: task ${data.taskId}, "${data.instruction?.substring(0, 80)}"`);
      if (!data.instruction?.trim()) return;
      try {
        const { verifyTaskOwnership } = await import("../automationRouter/tasks");
        const ownerOk = await verifyTaskOwnership(data.taskId, user.id);
        if (!ownerOk) {
          socket.emit("task_instruction_ack", { taskId: data.taskId, success: false, error: "无权操作此任务" });
          return;
        }
        const { pushInstruction } = await import("../automation/instructionInjector");
        pushInstruction(data.taskId, data.instruction.trim());
        socket.emit("task_instruction_ack", { taskId: data.taskId, success: true });
      } catch (err: any) {
        socket.emit("task_instruction_ack", { taskId: data.taskId, success: false, error: err.message });
      }
    });

    // ★ 实时语音识别 handler
    registerSTTHandler(socket);

    // ★ Gemini Live 实时语音对话 handler
    registerVoiceLiveHandler(socket);

    socket.on("disconnect", (reason) => {
      console.log(`[SocketIO] User ${user.id} disconnected: ${socket.id} (${reason})`);
    });
  });
  // 初始化桌面控制命名空间
  try {
    const { initDesktopNamespace } = await import("../desktopSession");
    initDesktopNamespace(io);
  } catch (e: any) {
    console.warn("[SocketIO] Desktop namespace init failed:", e.message);
  }

  console.log("[SocketIO] Server initialized with authentication + event buffering");
  return io;
}

/**
 * 获取 Socket.io 服务器实例
 */
export function getIO(): Server | null {
  return io;
}
