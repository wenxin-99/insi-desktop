/**
 * Cron 引擎 — 任务调度与执行
 *
 * Phase 3.4 升级（automation 分支）：
 *   - 每次触发创建新的 automationTask（而不是重置旧任务状态）
 *   - 执行完成后生成报告
 *   - 推送通知给用户
 *
 * ★ Phase 2: Agent 定时调度融合
 *   - agent_schedules 触发走 triggerScheduledAgent → 创建子 agent_task → 入队
 *   - 旧 scheduled_tasks 触发继续走 executeTask（向后兼容）
 *   - 通过 _agentScheduleIds Set 区分两种 ID
 */
import { getDb } from "../../db";
import { scheduledTasks, scheduledTaskLogs } from "../../../drizzle/schema";
import { eq, sql as sqlFn } from "drizzle-orm";
import { getNextRunTime } from "./cronParser";
import { logger } from '../../_core/logger';
const log = logger.child('CronScheduler');

/** 活跃的定时任务 Map: taskId → { timer, nextRun } */
export const activeJobs = new Map<number, { taskId: number; timer: ReturnType<typeof setTimeout>; nextRun: Date }>();

/** ★ Phase 2: 标记哪些 ID 是 agent_schedules（vs 旧 scheduled_tasks） */
const _agentScheduleIds = new Set<number>();

// ═══════════════════════════════════════════
// ★ v5: DB 级跨进程执行锁（PM2 cluster 场景）
//
// 原理：schedule_execution_locks 表 + UNIQUE(schedule_source, schedule_id, execution_key)
//       INSERT IGNORE 原子竞争——只有 affectedRows=1 的进程继续执行
//       execution_key = 分钟级时间戳（同一分钟内多次触发只放行一个）
// ═══════════════════════════════════════════

let _lockTableReady = false;

async function ensureLockTable(): Promise<void> {
  if (_lockTableReady) return;
  const { getRawPool } = await import('../../db/connection');
  const pool = await getRawPool();
  if (!pool) return;
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS schedule_execution_locks (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        schedule_source VARCHAR(20) NOT NULL COMMENT 'agent_schedule | scheduled_task',
        schedule_id INT NOT NULL,
        execution_key VARCHAR(20) NOT NULL COMMENT '分钟级时间戳 YYYYMMDDHHmm',
        claimed_by VARCHAR(40) DEFAULT NULL COMMENT 'PM2 instance id',
        created_at DATETIME DEFAULT NOW(),
        UNIQUE KEY uq_exec_lock (schedule_source, schedule_id, execution_key)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    // 清理 7 天前的锁记录
    await pool.execute(
      `DELETE FROM schedule_execution_locks WHERE created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)`
    ).catch(() => {});
  } catch (e: any) {
    if (!e.message?.includes('already exists')) {
      log.warn(`Lock table creation failed: ${e.message}`);
    }
  }
  _lockTableReady = true;
}

/** 获取 PM2 实例 ID（用于调试日志） */
const _pm2InstanceId = process.env.NODE_APP_INSTANCE || process.env.pm_id || '0';

/**
 * ★ v5: 原子抢占执行权
 * @returns true = 本进程抢到了，可以执行；false = 其他进程已抢到
 */
async function tryClaimExecution(source: 'agent_schedule' | 'scheduled_task', scheduleId: number): Promise<boolean> {
  await ensureLockTable();
  const { getRawPool } = await import('../../db/connection');
  const pool = await getRawPool();
  if (!pool) return true; // DB 不可用时放行（降级为无锁）

  // execution_key = 当前分钟（同一分钟只允许一个进程执行）
  const now = new Date();
  const key = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;

  try {
    const [result]: any = await pool.execute(
      `INSERT IGNORE INTO schedule_execution_locks (schedule_source, schedule_id, execution_key, claimed_by)
       VALUES (?, ?, ?, ?)`,
      [source, scheduleId, key, `pm2-${_pm2InstanceId}`]
    );
    if (result?.affectedRows > 0) {
      log.info(`[ExecLock] Claimed ${source}#${scheduleId} @${key} (pm2-${_pm2InstanceId})`);
      return true;
    } else {
      log.info(`[ExecLock] Skipped ${source}#${scheduleId} @${key} — already claimed by another instance`);
      return false;
    }
  } catch (e: any) {
    if (e.message?.includes('Duplicate')) return false;
    log.warn(`[ExecLock] tryClaimExecution failed: ${e.message}, allowing execution`);
    return true; // 异常时放行
  }
}

export async function executeTask(taskId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const [task] = await db.select().from(scheduledTasks).where(eq(scheduledTasks.id, taskId)).limit(1);
  if (!task || task.status !== "active") return;

  log.info(` Executing task #${taskId}: ${task.name}`);
  const startTime = Date.now();

  // 创建执行日志
  const [logResult] = await db.insert(scheduledTaskLogs).values({
    taskId,
    status: "running",
    startedAt: new Date(),
    retryCount: 0,
  }) as any;
  const logId = logResult.insertId;

  let status: "success" | "failed" | "timeout" = "failed";
  let httpStatusCode: number | null = null;
  let responseBody: string | null = null;
  let errorMessage: string | null = null;

  try {
    if (task.taskType === "webhook") {
      // Webhook 类型：发送 HTTP 请求
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), (task.timeoutSeconds || 30) * 1000);

      try {
        const headers: Record<string, string> = { "Content-Type": "application/json" };
        if (task.webhookHeaders) {
          try { Object.assign(headers, JSON.parse(task.webhookHeaders)); } catch {}
        }

        const fetchOptions: RequestInit = {
          method: task.webhookMethod || "POST",
          headers,
          signal: controller.signal,
        };

        if (task.webhookMethod !== "GET" && task.webhookBody) {
          fetchOptions.body = task.webhookBody;
        }

        const response = await fetch(task.webhookUrl!, fetchOptions);
        clearTimeout(timeout);

        httpStatusCode = response.status;
        responseBody = await response.text().catch(() => "");
        if (responseBody && responseBody.length > 5000) {
          responseBody = responseBody.substring(0, 5000) + "...(truncated)";
        }

        status = response.ok ? "success" : "failed";
        if (!response.ok) {
          errorMessage = `HTTP ${response.status}: ${responseBody?.substring(0, 500)}`;
        }
      } catch (err: any) {
        clearTimeout(timeout);
        if (err.name === "AbortError") {
          status = "timeout";
          errorMessage = `Request timeout after ${task.timeoutSeconds}s`;
        } else {
          throw err;
        }
      }
    } else if (task.taskType === "automation") {
      // ★ Phase 3.4: 自动化任务 — 创建新任务而不是重置旧任务
      if (task.automationTaskId) {
        const { automationTasks } = await import("../../drizzle/schema");
        const [templateTask] = await db.select().from(automationTasks).where(eq(automationTasks.id, task.automationTaskId)).limit(1);

        if (templateTask) {
          // ★ 创建新的 automationTask（复制模板任务的配置）
          const [newTaskResult] = await db.insert(automationTasks).values({
            userId: templateTask.userId,
            siteAccountId: templateTask.siteAccountId,
            conversationId: templateTask.conversationId || null,
            taskType: templateTask.taskType || 'browse_and_post',
            name: `[定时] ${task.name} (${new Date().toLocaleDateString('zh-CN')})`,
            instruction: templateTask.instruction,
            targetUrls: templateTask.targetUrls,
            searchKeywords: (templateTask as any).searchKeywords || null,
            contentStyle: (templateTask as any).contentStyle || null,
            modelUsed: 'qwen-plus',
          }) as any;
          const newTaskId = newTaskResult.insertId;

          log.info(` Created new automation task #${newTaskId} from template #${task.automationTaskId}`);

          // 执行新任务
          try {
            const { executeAutomationTask } = await import("../_core/automationService");

            // 同步等待执行完成（定时任务不需要异步fire-and-forget）
            await executeAutomationTask(newTaskId);

            // ★ 生成执行报告
            let reportMarkdown = '';
            try {
              const { generateSingleTaskReport, formatReportAsMarkdown } = await import("../_core/automation/reportGenerator");
              const report = await generateSingleTaskReport(newTaskId);
              reportMarkdown = formatReportAsMarkdown(report);
            } catch (reportErr: any) {
              log.warn(` Report generation failed: ${reportErr.message}`);
            }

            // ★ 推送通知（使用 emitSandboxEvent 发送到前端）
            try {
              const { emitSandboxEvent } = await import("../_core/socketManager");
              emitSandboxEvent({
                type: 'task_status' as any,
                taskId: newTaskId,
                timestamp: Date.now(),
                payload: {
                  status: 'scheduled_complete',
                  title: `定时任务完成: ${task.name}`,
                  message: `自动化任务 #${newTaskId} 已执行完成`,
                  scheduledTaskId: taskId,
                  report: reportMarkdown.substring(0, 500),
                },
              });
            } catch { /* notification is best-effort */ }

            status = "success";
            responseBody = `New automation task #${newTaskId} created and completed. ${reportMarkdown.substring(0, 200)}`;
          } catch (execErr: any) {
            // 执行失败仍然算"已触发"（任务状态由 automationTask 自身管理）
            log.error(` Automation task #${newTaskId} execution error:`, execErr.message);

            // 推送失败通知
            try {
              const { emitSandboxEvent } = await import("../_core/socketManager");
              emitSandboxEvent({
                type: 'task_status' as any,
                taskId: newTaskId,
                timestamp: Date.now(),
                payload: {
                  status: 'scheduled_failed',
                  title: `定时任务失败: ${task.name}`,
                  message: execErr.message?.substring(0, 200),
                  scheduledTaskId: taskId,
                },
              });
            } catch {}

            status = "failed";
            errorMessage = `Task #${newTaskId} execution failed: ${execErr.message}`;
          }
        } else {
          status = "failed";
          errorMessage = `Template automation task #${task.automationTaskId} not found`;
        }
      } else {
        status = "failed";
        errorMessage = "No automation task ID configured";
      }
    } else if (task.taskType === "script") {
      status = "success";
      responseBody = "Script execution not yet implemented";
    } else if (task.taskType === "research") {
      // 深度研究类型
      try {
        const researchPrompt = task.description || task.name || "请总结今日最新内容";

        const { getResearchPricing } = await import("../../_core/research/researchPricing");
        const pricing = await getResearchPricing(undefined, false);
        const baseCost = pricing.baseCost;

        const { deductFishCoins, createResearchTask, updateResearchTaskBullmqJobId, refundFishCoins, updateResearchTaskStatus } = await import("../../db");
        const deducted = await deductFishCoins(task.userId, baseCost, `定时研究任务（底价${baseCost}🐟）: ${researchPrompt.substring(0, 50)}...`);

        if (!deducted) {
          status = "failed";
          errorMessage = "用户🐟币余额不足，定时研究任务未执行";
          log.warn(` Research task #${taskId} skipped: insufficient balance for user ${task.userId}`);
        } else {
          const researchTaskId = await createResearchTask({
            userId: task.userId,
            prompt: researchPrompt,
            cost: baseCost.toFixed(2),
          });

          try {
            const { addResearchJobWithFallback } = await import("../../_core/agentQueue");
            const { jobId, mode } = await addResearchJobWithFallback({
              taskId: researchTaskId,
              userId: task.userId,
              prompt: researchPrompt,
            });
            await updateResearchTaskBullmqJobId(researchTaskId, jobId);
            status = "success";
            responseBody = `Research task #${researchTaskId} created (job: ${jobId}, mode: ${mode})`;
            log.info(` Research task #${researchTaskId} launched from scheduled task #${taskId}`);
          } catch (queueErr: any) {
            await refundFishCoins(task.userId, baseCost, `定时研究任务入队失败退款（任务#${researchTaskId}）`);
            await updateResearchTaskStatus(researchTaskId, "failed", {
              errorMessage: "入队失败: " + queueErr.message,
            });
            status = "failed";
            errorMessage = `Research queue failed: ${queueErr.message}`;
          }
        }
      } catch (err: any) {
        status = "failed";
        errorMessage = `Research task error: ${err.message}`;
      }
    }
  } catch (err: any) {
    status = "failed";
    errorMessage = err.message || String(err);
    log.error(` Task #${taskId} failed:`, err);
  }

  const durationMs = Date.now() - startTime;

  // 更新执行日志
  await db.update(scheduledTaskLogs).set({
    status,
    finishedAt: new Date(),
    durationMs,
    httpStatusCode,
    responseBody,
    errorMessage,
  }).where(eq(scheduledTaskLogs.id, logId));

  // 更新任务统计
  const updateData: any = {
    lastRunAt: new Date(),
    lastRunStatus: status,
    totalRuns: sqlFn`${scheduledTasks.totalRuns} + 1`,
  };
  if (status === "success") {
    updateData.successRuns = sqlFn`${scheduledTasks.successRuns} + 1`;
  } else {
    updateData.failedRuns = sqlFn`${scheduledTasks.failedRuns} + 1`;
  }

  try {
    const nextRun = getNextRunTime(task.cronExpression);
    updateData.nextRunAt = nextRun;
  } catch {}

  await db.update(scheduledTasks).set(updateData).where(eq(scheduledTasks.id, taskId));

  // 重新调度
  scheduleNextRun(taskId, task.cronExpression);

  log.info(` Task #${taskId} completed: ${status} (${durationMs}ms)`);
}

/**
 * 调度下一次执行
 * ★ Phase 2: 根据 ID 类型分发到不同执行函数
 */
export function scheduleNextRun(taskId: number, cronExpression: string): void {
  const existing = activeJobs.get(taskId);
  if (existing?.timer) {
    clearTimeout(existing.timer);
  }

  try {
    const nextRun = getNextRunTime(cronExpression);
    const delay = nextRun.getTime() - Date.now();

    if (delay <= 0) {
      _dispatchExecution(taskId);
      return;
    }

    const maxDelay = 24 * 60 * 60 * 1000;
    const actualDelay = Math.min(delay, maxDelay);

    const timer = setTimeout(() => {
      if (delay > maxDelay) {
        scheduleNextRun(taskId, cronExpression);
      } else {
        _dispatchExecution(taskId);
      }
    }, actualDelay);

    activeJobs.set(taskId, { taskId, timer, nextRun });
    const source = _agentScheduleIds.has(taskId) ? "AgentSchedule" : "ScheduledTask";
    log.info(`[${source}] #${taskId} scheduled for ${nextRun.toISOString()} (in ${Math.round(delay / 1000)}s)`);
  } catch (err) {
    log.error(` Failed to schedule task #${taskId}:`, err);
  }
}

/**
 * ★ v5: 分发执行——跨进程原子去重
 *
 * PM2 cluster 模式下两个进程各自设 setTimeout，同一秒都会触发。
 * 用 DB INSERT IGNORE + UNIQUE 约束做原子竞争，只有一个进程能继续执行。
 */
const _runningSchedules = new Set<number>();

function _dispatchExecution(taskId: number): void {
  // 内存级并发锁（同一进程内防重入）
  if (_runningSchedules.has(taskId)) {
    log.warn(`[Dedup] #${taskId} already running in this process, skipping`);
    return;
  }

  const source: 'agent_schedule' | 'scheduled_task' = _agentScheduleIds.has(taskId) ? 'agent_schedule' : 'scheduled_task';

  _runningSchedules.add(taskId);

  // ★ DB 级跨进程锁（PM2 多实例原子竞争）
  tryClaimExecution(source, taskId).then(claimed => {
    if (!claimed) {
      _runningSchedules.delete(taskId);
      return; // 其他 PM2 实例已抢到，本进程跳过
    }

    const handler = _agentScheduleIds.has(taskId)
      ? triggerScheduledAgent(taskId)
      : executeTask(taskId);

    handler.catch(err => {
      log.error(` Execute/Trigger #${taskId} failed:`, err.message);
    }).finally(() => {
      _runningSchedules.delete(taskId);
    });
  }).catch(err => {
    log.error(`[ExecLock] Claim check failed for #${taskId}: ${err.message}`);
    _runningSchedules.delete(taskId);
  });
}

/**
 * 停止任务调度
 */
export function unscheduleTask(taskId: number): void {
  const job = activeJobs.get(taskId);
  if (job?.timer) {
    clearTimeout(job.timer);
  }
  activeJobs.delete(taskId);
  _agentScheduleIds.delete(taskId);
}

// ═══════════════════════════════════════════
// ★ Phase 2: Agent Schedule 新管道
// ═══════════════════════════════════════════

/**
 * 注册一个 agent_schedule 到调度器
 * 对外接口——agent router 的 createScheduled/toggleSchedule 调用此函数
 */
export function scheduleAgentTask(scheduleId: number, cronExpression: string): void {
  _agentScheduleIds.add(scheduleId);
  scheduleNextRun(scheduleId, cronExpression);
}

/**
 * ★ 立即触发一个 agent schedule（公开接口，供 router 的 runScheduleNow 调用）
 *
 * 手动触发不走 DB 锁（用户主动点击应该始终执行），
 * 但保留内存级并发锁防止快速连击。
 */
export async function triggerScheduledAgentNow(scheduleId: number): Promise<void> {
  if (_runningSchedules.has(scheduleId)) {
    log.info(` Schedule #${scheduleId} already running, skipping manual trigger`);
    return;
  }

  _agentScheduleIds.add(scheduleId);
  _runningSchedules.add(scheduleId);

  try {
    await triggerScheduledAgent(scheduleId);
  } finally {
    _runningSchedules.delete(scheduleId);
  }
}

/**
 * Agent Schedule 触发时的执行函数
 * 1. 从 agent_schedules 读取配置
 * 2. 从 template agent_task 继承参数
 * 3. 创建 child agent_task
 * 4. 入队走标准 agent 管道
 * 5. 更新统计并重新调度
 */
async function triggerScheduledAgent(scheduleId: number): Promise<void> {
  log.info(` Triggering schedule #${scheduleId}`);

  const { getAgentSchedule, recordScheduleRun } = await import("../../_core/agentCore/scheduleDb");
  const { createAgentTask, getAgentTask } = await import("../../_core/agentCore/db");

  const schedule = await getAgentSchedule(scheduleId);
  if (!schedule || schedule.status !== "active") {
    log.warn(` Schedule #${scheduleId} not active, skipping`);
    return;
  }

  const template = await getAgentTask(schedule.templateTaskId);
  if (!template) {
    log.error(` Template task ${schedule.templateTaskId} not found`);
    await recordScheduleRun(scheduleId, false);
    scheduleNextRun(scheduleId, schedule.cronExpression);
    return;
  }

  // ★ Webhook 类型：直接执行 HTTP，不走 agent queue
  if (schedule.webhookUrl) {
    await _executeWebhookForSchedule(scheduleId, schedule, template);
    return;
  }

  // ★ 技能类任务：通过 skillEngine 执行（读取用户参数，解析模板）
  const config = typeof template.config === "string" ? JSON.parse(template.config) : (template.config || {});
  if (config?._skillExec || /^\[技能\]/i.test(template.prompt)) {
    await _executeSkillForSchedule(scheduleId, schedule, template, config);
    return;
  }

  // ★ 智能任务路由：LLM 分类器决定执行路径
  // 注意：config.taskType 可能是创建时粗略设置的（如 scheduleCreateHandler 设为 "research"），
  // 但实际上"搜索新闻并总结"应该走快速路径。所以 _classifiedType（LLM 精确分类）优先于 taskType。
  const cachedType = config?._classifiedType;
  const cachedPromptHash = config?._classifiedPromptHash;
  const currentPromptHash = _simpleHash(template.prompt || "");
  let taskType = "";

  if (cachedType && cachedPromptHash === currentPromptHash) {
    // ★ prompt 未变 + 已有 LLM 分类缓存 → 直接使用
    taskType = cachedType;
    log.info(` Using cached classification: ${taskType} (prompt unchanged)`);
  } else {
    // ★ 首次或 prompt 有变更 → LLM 重新分类
    taskType = await _classifyScheduleTask(template.prompt, config);
    config.taskType = taskType;
    config._classifiedType = taskType;
    config._classifiedPromptHash = currentPromptHash;
    log.info(` Task classified as: ${taskType} (prompt: "${template.prompt.substring(0, 40)}...")`);

    // ★ 回写缓存到数据库，下次执行不再分类
    try {
      const { getRawPool } = await import("../../db/connection");
      const pool = await getRawPool();
      if (pool) {
        await pool.execute(
          `UPDATE agent_tasks SET config = ? WHERE id = ?`,
          [JSON.stringify(config), template.id],
        );
      }
    } catch {}
  }

  const FAST_PATH_TYPES = ["weather", "reminder", "search_summarize", "news", "greeting", "companion_greeting"];
  if (FAST_PATH_TYPES.includes(taskType)) {
    await _executeLLMDirectForSchedule(scheduleId, schedule, template, config);
    return;
  }

  // ★ Phase 5: 加载用户记忆，增强任务 prompt
  let enhancedPrompt = template.prompt;
  try {
    const { getActiveMemories } = await import("../../db/memory");
    const memories = await getActiveMemories(template.userId);
    if (memories.length > 0) {
      const memoryHint = _buildMemoryHint(memories, config);
      if (memoryHint) {
        enhancedPrompt = `${template.prompt}\n\n${memoryHint}`;
        log.info(` Injected ${memories.length} memories into prompt for schedule #${scheduleId}`);
      }
    }
  } catch (e: any) {
    log.warn(` Failed to load user memories: ${e.message}`);
  }

  // ★ Agent 类型：创建子任务 → 入队
  const { v4: uuid } = await import("uuid");
  const childId = uuid();

  // ★ P2⑨：定时任务默认跳过确认（无人值守场景）
  // 除非用户在模板 config 中显式设置 skipConfirmation: false
  if (config.skipConfirmation === undefined) {
    config.skipConfirmation = true;
    log.info(` Schedule #${scheduleId}: auto-set skipConfirmation=true (unattended mode)`);
  }

  try {
    await createAgentTask({
      id: childId,
      userId: template.userId,
      type: template.type as any,
      prompt: enhancedPrompt,
      config,
      scheduleId: schedule.id,
      parentTaskId: template.id,
      isTemplate: false,
    });

    const { enqueueAgentTask } = await import("../../_core/agentCore/queue");
    await enqueueAgentTask({
      taskId: childId,
      userId: template.userId,
      type: template.type as any,
      prompt: enhancedPrompt,
      images: typeof template.images === "string" ? JSON.parse(template.images) : template.images || undefined,
      config,
    });

    log.info(` Created child task ${childId} from template ${template.id}`);

    // ★ 通知前端（SSE）
    try {
      const { sendNotificationToUser } = await import("../../_core/sseNotification");
      sendNotificationToUser(template.userId, {
        type: "schedule_triggered",
        title: "定时任务已触发",
        message: `「${template.prompt.substring(0, 30)}...」已自动执行`,
        data: { taskId: childId, scheduleId, templateTaskId: template.id },
      });
    } catch {}

    // ★ Phase 5: 优先推送到来源渠道（_channelOrigin），回退到所有渠道
    try {
      await _notifyChannelOriginOrAll(template.userId, config, "定时任务已触发", [
        `任务: ${template.prompt.substring(0, 50)}`,
        `子任务 ID: ${childId.substring(0, 8)}`,
        `执行中...完成后会再次通知`,
      ].join("\n"));
    } catch (e: any) {
      log.warn(` Channel notify failed: ${e.message}`);
    }

    // 统计
    let nextRunAt: Date | undefined;
    try { nextRunAt = getNextRunTime(schedule.cronExpression); } catch {}
    await recordScheduleRun(scheduleId, true, nextRunAt);

  } catch (err: any) {
    log.error(` Failed to create/enqueue child for schedule #${scheduleId}:`, err.message);

    // ★ Phase 5: 失败也通知来源渠道
    try {
      await _notifyChannelOriginOrAll(template.userId, config, "定时任务触发失败", [
        `任务: ${template.prompt.substring(0, 50)}`,
        `错误: ${err.message.substring(0, 100)}`,
      ].join("\n"));
    } catch {}

    let nextRunAt: Date | undefined;
    try { nextRunAt = getNextRunTime(schedule.cronExpression); } catch {}
    await recordScheduleRun(scheduleId, false, nextRunAt);
  }

  // 重新调度
  scheduleNextRun(scheduleId, schedule.cronExpression);
}

/**
 * ★ 天气/提醒类快速路径：直接 LLM + Web Search
 *
 * 不走 Agent 编排（29 个工具的 orchestrator loop），
 * 而是直接调用 LLM 完成任务，支持 web_search 获取实时数据。
 * 适合天气查询、简单提醒等不需要复杂工具链的任务。
 */
async function _executeLLMDirectForSchedule(
  scheduleId: number,
  schedule: any,
  template: any,
  config: any,
): Promise<void> {
  const { recordScheduleRun } = await import("../../_core/agentCore/scheduleDb");
  const { createAgentTask, updateAgentTaskStatus } = await import("../../_core/agentCore/db");
  const { v4: uuid } = await import("uuid");
  let success = false;
  let output = "";
  const taskType = config?.taskType || "general";

  // ★ 创建子任务记录（让执行历史可见）
  const childId = uuid();
  try {
    await createAgentTask({
      id: childId,
      userId: template.userId,
      type: template.type as any,
      prompt: template.prompt,
      config: { ...config, _executionMode: "llm_direct" },
      scheduleId: schedule.id,
      parentTaskId: template.id,
      isTemplate: false,
    });
    await updateAgentTaskStatus(childId, "running");
  } catch (e: any) {
    log.warn(` Failed to create child task: ${e.message}`);
  }

  // ★ 快速路径扣费（固定费用，比 Agent 编排便宜）
  const FAST_PATH_COST: Record<string, number> = {
    weather: 1, reminder: 0.5, greeting: 0.5,
    search_summarize: 2, news: 2,
    companion_greeting: 0,
  };
  const flatCost = FAST_PATH_COST[taskType] ?? 1;

  try {
    try {
      const { deductFishCoins } = await import("../../db");
      await deductFishCoins(template.userId, flatCost, `schedule-${scheduleId}-${childId.substring(0, 8)}`);
      log.info(` Deducted ${flatCost}🐟 for ${taskType} task`);
    } catch (e: any) {
      log.warn(` Fee deduction failed: ${e.message}`);
    }

    // ★ 伴侣问候专用路径（不走通用 LLM，走 companionScheduleBridge 专用逻辑）
    if (taskType === "companion_greeting") {
      try {
        const { executeCompanionGreeting } = await import("../../companionScheduleBridge");
        output = await executeCompanionGreeting(template.userId, config);
        success = true;
        log.info(` Schedule #${scheduleId} companion greeting completed: ${output.substring(0, 80)}`);

        // SSE 通知
        try {
          const { sendNotificationToUser } = await import("../../_core/sseNotification");
          sendNotificationToUser(template.userId, {
            type: "schedule_triggered",
            title: `💕 ${config._companionName || "TA"} 的问候`,
            message: output.substring(0, 200),
            data: { scheduleId, templateTaskId: template.id, taskId: childId },
          });
        } catch {}
      } catch (err: any) {
        log.error(` Companion greeting failed: ${err.message}`);
        output = err.message;
      }

      // 更新子任务状态
      try {
        if (success) {
          await updateAgentTaskStatus(childId, "completed", {
            result: output.substring(0, 5000),
            totalSteps: 1,
            totalCost: "0",
          });
        } else {
          await updateAgentTaskStatus(childId, "failed", {
            errorMsg: output.substring(0, 500),
          });
        }
      } catch (e: any) {
        log.warn(` Child task update failed: ${e.message}`);
      }

      // 统计 + 重新调度
      let nextRunAt: Date | undefined;
      try { nextRunAt = getNextRunTime(schedule.cronExpression); } catch {}
      await recordScheduleRun(scheduleId, success, nextRunAt);
      scheduleNextRun(scheduleId, schedule.cronExpression);
      return; // ★ 短路返回，不走通用 LLM 路径
    }

    // 1. 加载用户记忆增强 prompt
    let memoryContext = "";
    try {
      const { getActiveMemories } = await import("../../db/memory");
      const memories = await getActiveMemories(template.userId);
      if (memories.length > 0) {
        memoryContext = _buildMemoryHint(memories, config);
      }
    } catch {}

    const enhancedPrompt = memoryContext
      ? `${template.prompt}\n\n${memoryContext}`
      : template.prompt;

    // 2. 构建系统指令
    const now = new Date().toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" });
    let systemPrompt = "";
    if (taskType === "weather") {
      systemPrompt = `你是一个天气播报助手。当前北京时间：${now}。\n请根据用户提供的城市信息查询天气，用简洁友好的格式输出天气预报。\n如果有 web_search 工具可用，请使用它获取最新天气数据。\n如果没有搜索工具，请根据你的知识给出当前季节该城市的一般天气情况，并说明这是估算值。`;
    } else if (taskType === "reminder") {
      systemPrompt = `你是一个提醒助手。当前北京时间：${now}。\n请用简洁友好的方式发送提醒。如果记忆中有用户的称呼，用名字称呼他/她。`;
    } else if (taskType === "search_summarize") {
      systemPrompt = `你是一个信息搜索与总结助手。当前北京时间：${now}。\n请根据搜索结果，用清晰的结构化格式总结最新信息。\n要求：\n1. 按重要程度排序\n2. 每条信息标注来源和日期\n3. 末尾给出简要综述\n4. 输出控制在 800 字以内`;
    } else if (taskType === "news") {
      systemPrompt = `你是一个新闻简报助手。当前北京时间：${now}。\n请根据搜索结果，整理一份精炼的新闻简报。\n要求：\n1. 挑选最重要的 5-8 条新闻\n2. 每条用一句话概括，附上来源\n3. 使用 emoji 增加可读性\n4. 末尾用 2-3 句话做今日总评`;
    } else if (taskType === "greeting") {
      systemPrompt = `你是一个温暖的每日问候助手。当前北京时间：${now}。\n请根据当前日期、节气、天气等信息，生成一段温暖的问候语。简洁有力，带有正能量。`;
    } else {
      systemPrompt = `你是一个定时任务执行助手。当前北京时间：${now}。\n请根据任务描述完成相应工作，输出简洁的结果。`;
    }

    // 3. 尝试带 web_search 的 LLM 调用
    const { invokeLLM } = await import("../../_core/llm");

    // ★ 读取定时任务使用的套餐 → 解析 chat 槽位模型
    // 优先级：config._schedulePackageId（用户选择）> system_config > 默认 qwen-plus
    let scheduleModel = "qwen-plus";
    let scheduleApiEndpoint: string | undefined;
    let scheduleApiKey: string | undefined;

    const packageId = config?._schedulePackageId;
    if (packageId && packageId > 0) {
      try {
        const { getSlotModel } = await import("../../modelPackage/slotResolver");
        const slotModel = await getSlotModel(packageId, "chat");
        if (slotModel) {
          scheduleModel = (slotModel as any).apiModel || (slotModel as any).name || "qwen-plus";
          scheduleApiEndpoint = (slotModel as any).apiEndpoint || undefined;
          scheduleApiKey = (slotModel as any).apiKey || undefined;
          log.info(` Using package #${packageId} chat slot: ${scheduleModel}`);
        }
      } catch (e: any) {
        log.warn(` Package slot resolve failed: ${e.message}, falling back to qwen-plus`);
      }
    } else if (!packageId) {
      // 无套餐配置时，读 system_config 兜底
      try {
        const { getSystemConfig } = await import("../../db");
        const cfg = await getSystemConfig("schedule_llm_model");
        if (cfg?.configValue) scheduleModel = cfg.configValue;
      } catch {}
    }

    // 读取 web search API key
    let hasWebSearch = false;
    const tavilyKey = process.env.TAVILY_API_KEY;
    if (tavilyKey && (taskType === "weather" || taskType === "search_summarize" || taskType === "news")) {
      hasWebSearch = true;
    }

    let response: any;

    if (hasWebSearch) {
      try {
        let searchQuery = "";

        if (taskType === "weather") {
          // 天气：提取城市名
          let city = config?.params?.city || "";
          if (!city) {
            const p = template.prompt || "";
            const m1 = p.match(/([\u4e00-\u9fa5]{2,4}市(?:[\u4e00-\u9fa5]{1,4}(?:区|新区|县))?)/);
            if (m1) city = m1[1];
            else {
              const m2 = p.match(/([\u4e00-\u9fa5]{2,6}(?:区|县|新区))/);
              if (m2) city = m2[1];
              else {
                const m3 = p.match(/([\u4e00-\u9fa5]{2,4})(?:的)?天气/);
                if (m3) city = m3[1];
              }
            }
            city = city.replace(/^(?:查询|推送|播报|获取|发送|每天|每日|定时)+/g, "").trim();
          }
          const today = new Date().toLocaleDateString("zh-CN", { timeZone: "Asia/Shanghai", month: "long", day: "numeric" });
          searchQuery = city ? `${city}${today}天气预报` : `${today}天气预报`;
          log.info(` Weather search: city="${city}", query="${searchQuery}"`);
        } else {
          // search_summarize / news：从 prompt 提取关键词作搜索词
          const p = template.prompt || "";
          searchQuery = p
            .replace(/每天|每日|每周|上午|下午|晚上|\d+[点时:：]\d*/g, "")
            .replace(/搜索|汇报|查找|查询|推送|播报|并总结|并汇总/g, "")
            .replace(/请|帮我|帮忙|最新的?/g, "")
            .trim()
            .substring(0, 50);
          const today = new Date().toLocaleDateString("zh-CN", { timeZone: "Asia/Shanghai", month: "long", day: "numeric" });
          searchQuery = `${searchQuery} ${today}`;
          log.info(` Search query: "${searchQuery}" (type=${taskType})`);
        }

        const { tavilySearch } = await import("../../_core/research/webSearch");
        const searchResult = await tavilySearch(searchQuery);

        const searchContext = searchResult
          ? `\n\n以下是搜索到的最新信息：\n${searchResult.substring(0, 2000)}`
          : "";

        response = await invokeLLM({
          suppressReasoning: true,
          model: scheduleModel,
          apiEndpoint: scheduleApiEndpoint,
          apiKey: scheduleApiKey,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: enhancedPrompt + searchContext },
          ],
          maxTokens: 1000,
          temperature: 0.7,
        });
      } catch (searchErr: any) {
        log.warn(` Web search failed, falling back: ${searchErr.message}`);
        // 搜索失败，回退到纯 LLM，注入搜索失败提示
        const fallbackNotice = taskType === "weather"
          ? "\n\n⚠️ 注意：实时天气数据获取失败，以下内容基于一般气候规律推测，仅供参考。"
          : "\n\n⚠️ 注意：实时搜索失败，以下内容基于已有知识生成，可能不包含最新信息。";
        response = await invokeLLM({
          suppressReasoning: true,
          model: scheduleModel,
          apiEndpoint: scheduleApiEndpoint,
          apiKey: scheduleApiKey,
          messages: [
            { role: "system", content: systemPrompt + "\n\n搜索功能暂时不可用，请明确告知用户这不是实时数据。" },
            { role: "user", content: enhancedPrompt },
          ],
          maxTokens: 1000,
          temperature: 0.7,
        });
        // 给输出追加降级标记
        const rawFallback = response?.choices?.[0]?.message?.content || "";
        if (rawFallback && !rawFallback.includes("⚠️")) {
          response.choices[0].message.content = rawFallback + fallbackNotice;
        }
      }
    } else {
      // 无搜索能力，直接 LLM
      response = await invokeLLM({
        suppressReasoning: true,
        model: scheduleModel,
        apiEndpoint: scheduleApiEndpoint,
        apiKey: scheduleApiKey,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: enhancedPrompt },
        ],
        maxTokens: 1000,
        temperature: 0.7,
      });
    }

    output = response?.choices?.[0]?.message?.content || "任务执行完成（无输出）";
    success = true;

    log.info(` Schedule #${scheduleId} (${taskType}) completed, output ${output.length} chars`);

    // 4. 推送结果到渠道
    try {
      await _notifyChannelOriginOrAll(template.userId, config, "", output);
    } catch (e: any) {
      log.warn(` Channel notify failed: ${e.message}`);
    }

    // 5. SSE 通知
    try {
      const { sendNotificationToUser } = await import("../../_core/sseNotification");
      sendNotificationToUser(template.userId, {
        type: "schedule_triggered",
        title: taskType === "weather" ? "天气播报" : taskType === "search_summarize" || taskType === "news" ? "信息简报" : taskType === "greeting" ? "每日问候" : "定时提醒",
        message: output.substring(0, 200),
        data: { scheduleId, templateTaskId: template.id, taskId: childId },
      });
    } catch {}

  } catch (err: any) {
    log.error(` Schedule #${scheduleId} failed:`, err.message);
    output = err.message;

    try {
      await _notifyChannelOriginOrAll(template.userId, config, "定时任务执行失败", [
        `❌ ${template.prompt.substring(0, 50)}`,
        `错误: ${err.message.substring(0, 150)}`,
      ].join("\n"));
    } catch {}
  }

  // 6. ★ 更新子任务状态（让执行历史可见）
  try {
    if (success) {
      await updateAgentTaskStatus(childId, "completed", {
        result: output.substring(0, 5000),
        totalSteps: 1,
        totalCost: String(flatCost),
      });
    } else {
      await updateAgentTaskStatus(childId, "failed", {
        errorMsg: output.substring(0, 500),
      });
    }
  } catch (e: any) {
    log.warn(` Child task update failed: ${e.message}`);
  }

  // 7. 统计 + 重新调度
  let nextRunAt: Date | undefined;
  try { nextRunAt = getNextRunTime(schedule.cronExpression); } catch {}
  await recordScheduleRun(scheduleId, success, nextRunAt);
  scheduleNextRun(scheduleId, schedule.cronExpression);
}

/**
 * Webhook 类型的定时调度执行（不走 agent queue）
 */
async function _executeWebhookForSchedule(
  scheduleId: number,
  schedule: any,
  template: any,
): Promise<void> {
  const { recordScheduleRun } = await import("../../_core/agentCore/scheduleDb");
  let success = false;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), (schedule.timeoutSeconds || 30) * 1000);

    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (schedule.webhookHeaders) {
      try { Object.assign(headers, JSON.parse(schedule.webhookHeaders)); } catch {}
    }

    const fetchOptions: RequestInit = {
      method: schedule.webhookMethod || "POST",
      headers,
      signal: controller.signal,
    };
    if (schedule.webhookMethod !== "GET" && schedule.webhookBody) {
      fetchOptions.body = schedule.webhookBody;
    }

    const response = await fetch(schedule.webhookUrl, fetchOptions);
    clearTimeout(timeout);
    success = response.ok;

    if (!success) {
      const body = await response.text().catch(() => "");
      log.warn(` #${scheduleId} HTTP ${response.status}: ${body.substring(0, 200)}`);
    } else {
      log.info(` #${scheduleId} success (HTTP ${response.status})`);
    }
  } catch (err: any) {
    log.error(` #${scheduleId} failed:`, err.message);
  }

  let nextRunAt: Date | undefined;
  try { nextRunAt = getNextRunTime(schedule.cronExpression); } catch {}
  await recordScheduleRun(scheduleId, success, nextRunAt);
  scheduleNextRun(scheduleId, schedule.cronExpression);
}

/**
 * ★ v5: 启动时加载所有活跃的 agent_schedules + 初始化 DB 锁表
 */
export async function initAgentSchedules(): Promise<void> {
  try {
    // ★ v5: 确保 DB 锁表存在
    await ensureLockTable();

    const { listActiveSchedules } = await import("../../_core/agentCore/scheduleDb");
    const schedules = await listActiveSchedules();
    log.info(` Loading ${schedules.length} active agent schedules... (pm2-${_pm2InstanceId})`);

    let skipped = 0;
    for (const s of schedules) {
      // ★ v5: ID 冲突检测 — 如果 activeJobs 中已有同 ID 但不是 agent_schedule
      const existing = activeJobs.get(s.id);
      if (existing && !_agentScheduleIds.has(s.id)) {
        log.warn(`[ID Conflict] agent_schedule #${s.id} conflicts with scheduled_task #${s.id}, skipping agent_schedule`);
        skipped++;
        continue;
      }

      _agentScheduleIds.add(s.id);
      scheduleNextRun(s.id, s.cronExpression);
    }

    if (skipped > 0) {
      log.warn(` ${skipped} agent_schedules skipped due to ID conflict with scheduled_tasks`);
    }
    log.info(` Initialized ${schedules.length - skipped} schedules (pm2-${_pm2InstanceId})`);
  } catch (err: any) {
    log.warn(` Init failed: ${err.message}`);
  }
}

// ═══════════════════════════════════════════
// ★ 技能类定时任务执行
// ═══════════════════════════════════════════

/**
 * 技能类定时任务：读取 user_skills 参数，通过 skillEngine 执行
 * 这样 {city} 等模板变量会被正确替换为用户设置的值
 */
async function _executeSkillForSchedule(
  scheduleId: number,
  schedule: any,
  template: any,
  config: any,
): Promise<void> {
  const { recordScheduleRun } = await import("../../_core/agentCore/scheduleDb");
  let success = false;
  let output = "";

  try {
    // 1. 提取 skill 元信息
    const userSkillId = config?.userSkillId || config?._skillExec?.userSkillId;
    const skillId = config?.skillId || config?._skillExec?.skillId;

    if (!userSkillId && !skillId) {
      // 没有 skill 元信息，可能是迁移时丢失了，fallback 到搜索
      log.warn(` Schedule #${scheduleId} missing skill metadata, falling back to search`);

      // ★ Phase 5: 加载用户记忆增强 prompt
      let memoryContext = "";
      try {
        const { getActiveMemories } = await import("../../db/memory");
        const memories = await getActiveMemories(template.userId);
        if (memories.length > 0) {
          memoryContext = _buildMemoryHint(memories, config);
        }
      } catch {}

      const enhancedPrompt = memoryContext
        ? `${template.prompt}\n\n${memoryContext}`
        : template.prompt;

      // 用 prompt 直接搜索，至少比空跑好
      const { invokeLLM } = await import("../../_core/llm");
      const response = await invokeLLM({
        suppressReasoning: true,
        model: "qwen-plus",
        messages: [
          { role: "system", content: "你是一个定时任务执行助手。请根据任务描述完成相应工作。" },
          { role: "user", content: enhancedPrompt },
        ],
        maxTokens: 2000,
        temperature: 0.7,
      });
      output = response?.choices?.[0]?.message?.content || "执行完成（无 skill 元信息）";
      success = true;
    } else {
      // 2. 加载用户技能配置（含参数）
      const { getUserSkillById, getSkillById } = await import("../../db/skill");
      let userParams: Record<string, any> = {};
      let skillConfig: any = null;

      if (userSkillId) {
        const result = await getUserSkillById(userSkillId);
        if (result) {
          userParams = typeof result.userSkill.params === "string"
            ? JSON.parse(result.userSkill.params)
            : result.userSkill.params || {};
          skillConfig = typeof result.skill.config === "string"
            ? JSON.parse(result.skill.config)
            : result.skill.config;
        }
      }

      if (!skillConfig && skillId) {
        const skill = await getSkillById(skillId);
        if (skill) {
          skillConfig = typeof skill.config === "string" ? JSON.parse(skill.config) : skill.config;
        }
      }

      if (!skillConfig) {
        throw new Error(`Skill config not found (userSkillId=${userSkillId}, skillId=${skillId})`);
      }

      log.info(` Executing skill "${skillConfig.name}" with params:`, JSON.stringify(userParams));

      // 3. 通过 skillEngine 执行（自动解析模板 {city} → 用户实际值）
      const { executeSkill } = await import("../../_core/skills/skillEngine");
      const result = await executeSkill({
        config: skillConfig,
        params: userParams,
        userId: template.userId,
        userSkillId: userSkillId || 0,
        skillId: skillId || 0,
        triggerType: "cron",
      });

      success = result.success;
      output = result.output || result.error || "";

      if (!success) {
        log.warn(` Skill execution failed: ${result.error}`);
      }
    }

    // 4. 推送结果到渠道（优先来源渠道）
    try {
      const emoji = success ? "✅" : "❌";
      const title = success ? "定时任务执行完成" : "定时任务执行失败";
      await _notifyChannelOriginOrAll(template.userId, config, title, [
        `${emoji} ${template.prompt.substring(0, 50)}`,
        "",
        output.substring(0, 500),
      ].join("\n"));
    } catch (e: any) {
      log.warn(` Channel notify failed: ${e.message}`);
    }

    // 5. SSE 通知
    try {
      const { sendNotificationToUser } = await import("../../_core/sseNotification");
      sendNotificationToUser(template.userId, {
        type: "schedule_triggered",
        title: success ? "技能定时任务完成" : "技能定时任务失败",
        message: output.substring(0, 200),
        data: { scheduleId, templateTaskId: template.id },
      });
    } catch {}

  } catch (err: any) {
    log.error(` Schedule #${scheduleId} failed:`, err.message);
    output = err.message;

    try {
      await _notifyChannelOriginOrAll(template.userId, config, "定时技能执行失败", [
        `❌ ${template.prompt.substring(0, 50)}`,
        `错误: ${err.message.substring(0, 150)}`,
      ].join("\n"));
    } catch {}
  }

  // 6. 统计 + 重新调度
  let nextRunAt: Date | undefined;
  try { nextRunAt = getNextRunTime(schedule.cronExpression); } catch {}
  await recordScheduleRun(scheduleId, success, nextRunAt);
  scheduleNextRun(scheduleId, schedule.cronExpression);
}

// ═══════════════════════════════════════════
// ★ Phase 5: 记忆注入 + 渠道定向推送
// ═══════════════════════════════════════════

/**
 * 从用户记忆构建上下文提示，注入到定时任务 prompt 中
 * 根据任务类型（天气/提醒/通用）选择性注入相关记忆
 */
/** 简单字符串哈希（用于比较 prompt 是否变更，不需要加密安全性） */
function _simpleHash(str: string): string {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = ((h << 5) - h + str.charCodeAt(i)) | 0;
  }
  return h.toString(36);
}

/**
 * ★ 轻量 LLM 意图分类器 — 判断定时任务应走哪条执行路径
 *
 * 分类结果：
 *   weather          → 天气查询（LLM 直连 + 搜索）
 *   reminder         → 提醒通知（LLM 直连）
 *   search_summarize → 搜索 + 总结（LLM 直连 + 搜索）
 *   news             → 新闻简报（LLM 直连 + 搜索）
 *   greeting         → 问候/日报（LLM 直连）
 *   research         → 深度调研（Agent 编排）
 *   automation       → 浏览器自动化（Agent 编排）
 *   code             → 代码/SSH 操作（Agent 编排）
 *   general          → 通用（Agent 编排）
 *
 * 成本：~100 token，DeepSeek V3.2 约 0.001 元/次
 */
async function _classifyScheduleTask(prompt: string, config: any): Promise<string> {
  // 先做正则快速判断（零成本，覆盖明确场景）
  const p = prompt.toLowerCase();
  if (/天气|气温|weather/i.test(p)) return "weather";
  if (/^提醒|提醒我|reminder/i.test(p) && p.length < 50) return "reminder";
  if (config?._companionGreeting) return "companion_greeting";

  // LLM 分类
  try {
    const { invokeLLM } = await import("../../_core/llm");

    // 用最便宜的模型
    let classifyModel = "deepseek-v3.2";
    let classifyEndpoint: string | undefined;
    let classifyKey: string | undefined;

    // 尝试从用户套餐读取（复用配置好的 API key）
    const packageId = config?._schedulePackageId;
    if (packageId && packageId > 0) {
      try {
        const { getSlotModel } = await import("../../modelPackage/slotResolver");
        const slotModel = await getSlotModel(packageId, "chat");
        if (slotModel) {
          classifyModel = (slotModel as any).apiModel || "deepseek-v3.2";
          classifyEndpoint = (slotModel as any).apiEndpoint || undefined;
          classifyKey = (slotModel as any).apiKey || undefined;
        }
      } catch {}
    }

    const response = await invokeLLM({
      suppressReasoning: true,
      model: classifyModel,
      apiEndpoint: classifyEndpoint,
      apiKey: classifyKey,
      messages: [{
        role: "user",
        content: `判断以下定时任务的类型，只返回一个英文单词，不要解释。

类型选项：
- weather: 天气查询、气温、天气预报
- reminder: 简单提醒、打卡、通知
- news: 新闻、资讯、行业动态、简报
- search_summarize: 需要搜索后总结的信息查询
- greeting: 早安问候、每日一句、鼓励
- research: 需要深度调研、多轮搜索、生成长报告
- automation: 需要操作网页、登录、发帖、填表
- code: 需要 SSH 连接服务器、执行代码、部署
- general: 其他无法归类的任务

任务描述：${prompt.substring(0, 200)}

类型：`,
      }],
      maxTokens: 20,
      temperature: 0,
    });

    const raw = (response?.choices?.[0]?.message?.content || "").trim().toLowerCase();
    // 提取第一个匹配的类型词
    const validTypes = ["weather", "reminder", "news", "search_summarize", "greeting", "research", "automation", "code", "general"];
    const matched = validTypes.find(t => raw.includes(t));
    return matched || "general";

  } catch (err: any) {
    log.warn(` LLM classification failed: ${err.message}, falling back to regex`);
    // LLM 失败时回退到正则
    if (/搜索|汇报|查找|总结|新闻|动态|资讯|简报/i.test(p)) return "search_summarize";
    if (/ssh|服务器|代码|部署|shell/i.test(p)) return "code";
    if (/登录|发帖|浏览器|自动化|注册/i.test(p)) return "automation";
    return "general";
  }
}

function _buildMemoryHint(
  memories: Array<{ content: string; category: string }>,
  config: Record<string, any>,
): string {
  if (!memories || memories.length === 0) return "";

  const taskType = config?.taskType || "general";
  const parts: string[] = [];

  // 提取记忆中的关键信息
  const locationMems = memories.filter(m =>
    /城市|位置|所在|住在|地址|关注.*(?:市|区|县)|location/.test(m.content),
  );
  const nameMems = memories.filter(m =>
    /姓名|名字|叫做|我叫|用户的名字/.test(m.content),
  );
  const techMems = memories.filter(m =>
    m.category === "tech" || /编程|语言|框架|数据库|服务器/.test(m.content),
  );
  const preferenceMems = memories.filter(m =>
    m.category === "preference" || /偏好|喜欢|习惯|风格/.test(m.content),
  );

  switch (taskType) {
    case "weather":
      // 天气任务：注入位置信息
      if (locationMems.length > 0) {
        parts.push(`用户位置信息：${locationMems.map(m => m.content).join("；")}`);
      }
      if (nameMems.length > 0) {
        parts.push(`用户称呼：${nameMems.map(m => m.content).join("；")}`);
      }
      break;

    case "reminder":
      // 提醒任务：注入姓名（称呼用户名字）
      if (nameMems.length > 0) {
        parts.push(`用户称呼：${nameMems.map(m => m.content).join("；")}`);
      }
      break;

    case "research":
      // 研究任务：注入技术偏好
      if (techMems.length > 0) {
        parts.push(`用户技术背景：${techMems.slice(0, 5).map(m => m.content).join("；")}`);
      }
      if (preferenceMems.length > 0) {
        parts.push(`用户偏好：${preferenceMems.slice(0, 3).map(m => m.content).join("；")}`);
      }
      break;

    default:
      // 通用任务：注入核心记忆（限制数量避免 prompt 过长）
      const coreMems = [...nameMems, ...locationMems, ...preferenceMems].slice(0, 5);
      if (coreMems.length > 0) {
        parts.push(`用户信息：${coreMems.map(m => m.content).join("；")}`);
      }
      break;
  }

  if (parts.length === 0) return "";
  return `[用户记忆上下文]\n${parts.join("\n")}`;
}

/**
 * 推送通知到渠道：优先推送到创建任务时的来源渠道（_channelOrigin），
 * 如果没有来源渠道则推送到用户绑定的所有渠道。
 */
async function _notifyChannelOriginOrAll(
  userId: number,
  config: Record<string, any>,
  title: string,
  body: string,
): Promise<void> {
  const origin = config?._channelOrigin;

  if (origin?.channel && origin?.channelChatId) {
    // 定向推送到来源渠道
    try {
      const { responseRouter } = await import("../../_core/channels/responseRouter");
      const channelConfig = await _getChannelAppConfig(origin.channel);
      if (channelConfig) {
        const text = title ? `📋 ${title}\n\n${body}` : body;
        await responseRouter.push(origin.channel, origin.channelChatId, text, channelConfig);
        log.info(` Pushed to origin channel: ${origin.channel}/${origin.channelChatId}`);
        return;
      }
    } catch (e: any) {
      log.warn(` Origin channel push failed, falling back to all: ${e.message}`);
    }
  }

  // 回退：推送到所有绑定渠道
  const { notifyUserChannels } = await import("../../_core/channels/channelNotifier");
  await notifyUserChannels(userId, title, body);
}

/**
 * 获取渠道应用配置（与 gateway.ts 逻辑一致，优先环境变量）
 */
async function _getChannelAppConfig(channel: string): Promise<Record<string, any> | null> {
  if (channel === "telegram" && process.env.TELEGRAM_BOT_TOKEN) {
    return { botToken: process.env.TELEGRAM_BOT_TOKEN };
  }
  if (channel === "feishu" && process.env.FEISHU_APP_ID && process.env.FEISHU_APP_SECRET) {
    return {
      appId: process.env.FEISHU_APP_ID,
      appSecret: process.env.FEISHU_APP_SECRET,
    };
  }
  if (channel === "wechat_work" && process.env.WECHAT_WORK_CORP_ID && process.env.WECHAT_WORK_CORP_SECRET) {
    return {
      corpId: process.env.WECHAT_WORK_CORP_ID,
      corpSecret: process.env.WECHAT_WORK_CORP_SECRET,
      agentId: process.env.WECHAT_WORK_AGENT_ID || "",
    };
  }
  return null;
}