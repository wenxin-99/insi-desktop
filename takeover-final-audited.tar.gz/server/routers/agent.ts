/**
 * routers/agent.ts — Agent 任务 tRPC 路由
 *
 * 提供：
 *   agent.list       — 分页列表
 *   agent.get        — 单个任务详情
 *   agent.getSteps   — 任务步骤时间线
 *   agent.cancel     — 取消任务
 *   agent.pause      — 暂停任务
 *   agent.resume     — 恢复任务
 *   agent.stats      — 统计面板（admin）
 *   agent.create     — 创建通用 Agent 任务
 *
 * 注册方式：在 routers.ts 的 appRouter 中添加:
 *   import { agentRouter } from "./routers/agent";
 *   agent: agentRouter,
 */
import { z } from "zod";
import { router, protectedProcedure, adminProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";

export const agentRouter = router({
  /** 分页列表 — ★ Phase 1: 新增 scheduled 筛选 */
  list: protectedProcedure
    .input(z.object({
      type: z.enum(["automation", "research", "codeact", "general"]).optional(),
      status: z.enum(["pending", "running", "paused", "completed", "failed", "cancelled"]).optional(),
      /** true=只看定时模板, false=只看一次性, undefined=排除子任务 */
      scheduled: z.boolean().optional(),
      limit: z.number().min(1).max(100).default(20),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ ctx, input }) => {
      const { listAgentTasks, countAgentTasks } = await import("../_core/agentCore/db");
      const opts = input || {};
      const [tasks, total] = await Promise.all([
        listAgentTasks(ctx.user.id, opts),
        countAgentTasks(ctx.user.id, opts),
      ]);
      return { tasks, total, limit: opts.limit || 20, offset: opts.offset || 0 };
    }),

  /** 单个任务详情 */
  get: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .query(async ({ ctx, input }) => {
      const { getAgentTask } = await import("../_core/agentCore/db");
      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND", message: "任务不存在" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "无权访问" });
      }
      return task;
    }),

  /** 任务步骤时间线 */
  getSteps: protectedProcedure
    .input(z.object({ taskId: z.string(), limit: z.number().max(500).default(200) }))
    .query(async ({ ctx, input }) => {
      const { getAgentTask, getAgentSteps } = await import("../_core/agentCore/db");
      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND", message: "任务不存在" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      const steps = await getAgentSteps(input.taskId, input.limit);
      return { steps };
    }),

  /** 取消任务 */
  cancel: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask, updateAgentTaskStatus } = await import("../_core/agentCore/db");
      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      if (task.status !== "running" && task.status !== "paused" && task.status !== "pending") {
        throw new TRPCError({ code: "BAD_REQUEST", message: `无法取消 ${task.status} 状态的任务` });
      }

      // 设置取消标记（编排器循环内的 cancelGuard 会检测到）
      // ★ 统一取消注册表（字符串 taskId，无转换问题）
      try {
        const { signalCancel } = await import("../_core/agentCore/cancelRegistry");
        signalCancel(input.taskId);
      } catch {}
      // ★ 向后兼容旧路径（使用 toNumericId 而非 parseInt，修复 UUID 转换 bug）
      try {
        const { toNumericId } = await import("../_core/agentCore/emitter");
        const numId = toNumericId(input.taskId);
        const { cancelledTaskIds } = await import("../_core/automation/browserManager");
        cancelledTaskIds.add(numId);
      } catch {}
      try {
        const { toNumericId } = await import("../_core/agentCore/emitter");
        const numId = toNumericId(input.taskId);
        const { cancelResearchTask } = await import("../_core/research/cancelControl");
        cancelResearchTask(numId);
      } catch {}

      await updateAgentTaskStatus(input.taskId, "cancelled");
      return { success: true };
    }),

  /** 暂停任务（仅 automation） */
  pause: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask, updateAgentTaskStatus } = await import("../_core/agentCore/db");
      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (task.status !== "running") throw new TRPCError({ code: "BAD_REQUEST", message: "只能暂停运行中的任务" });

      try {
        const { pausedTaskIds } = await import("../_core/automation/browserManager");
        pausedTaskIds.add(parseInt(input.taskId) || 0);
      } catch {}

      await updateAgentTaskStatus(input.taskId, "paused");
      return { success: true };
    }),

  /** 恢复任务 */
  resume: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask, updateAgentTaskStatus } = await import("../_core/agentCore/db");
      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      if (task.status !== "paused") throw new TRPCError({ code: "BAD_REQUEST", message: "只能恢复暂停的任务" });

      try {
        const { pausedTaskIds } = await import("../_core/automation/browserManager");
        pausedTaskIds.delete(parseInt(input.taskId) || 0);
      } catch {}

      await updateAgentTaskStatus(input.taskId, "running");
      return { success: true };
    }),

  /** 创建通用 Agent 任务（general 类型） */
  create: protectedProcedure
    .input(z.object({
      prompt: z.string().min(1).max(10000),
      type: z.enum(["automation", "research", "codeact", "general"]).default("general"),
      images: z.array(z.string()).optional(),
      tools: z.array(z.string()).optional(),
      sandboxMode: z.enum(["none", "ssh", "docker", "browser"]).default("none"),
    }))
    .mutation(async ({ ctx, input }) => {
      const { v4: uuid } = await import("uuid");
      const { createAgentTask } = await import("../_core/agentCore/db");

      const taskId = uuid();
      await createAgentTask({
        id: taskId,
        userId: ctx.user.id,
        type: input.type,
        prompt: input.prompt,
        images: input.images,
        config: {
          maxSteps: input.type === "automation" ? 55 : 30,
          stepCost: 0,
          tools: input.tools || [],
          sandboxMode: input.sandboxMode,
          antiLoop: true,
          takeoverEnabled: input.type === "automation",
        },
      });

      // 入队执行
      try {
        const { enqueueAgentTask } = await import("../_core/agentCore/queue");
        await enqueueAgentTask({
          taskId, userId: ctx.user.id, type: input.type, prompt: input.prompt, images: input.images,
          config: { maxSteps: input.type === "automation" ? 55 : 30, tools: input.tools || [], sandboxMode: input.sandboxMode },
        });
      } catch (err: any) {
        console.warn(`[AgentRouter] Queue failed, direct execution:`, err.message);
        // 降级直接执行（后台异步）
        (async () => {
          try {
            const { runAgentLoop } = await import("../_core/agentCore/orchestrator");
            await runAgentLoop({
              taskId,
              userId: ctx.user.id,
              type: input.type,
              prompt: input.prompt,
              images: input.images,
              config: {
                maxSteps: 30,
                stepCost: 0,
                tools: input.tools || [],
                sandboxMode: input.sandboxMode,
                llmConfig: {} as any, // 由 orchestrator 内部解析
                antiLoop: true,
                takeoverEnabled: false,
              },
            });
          } catch (e: any) {
            console.error(`[AgentRouter] Direct execution failed:`, e.message);
          }
        })();
      }

      return { taskId };
    }),

  /** Admin: 统计面板 */
  stats: adminProcedure.query(async () => {
    try {
      const { getDb } = await import("../db");
      const db = await getDb();
      // ★ 同时聚合 agent_tasks 和 automation_tasks 两张表
      const [result] = await db.execute(`
        SELECT
          SUM(total) as total,
          SUM(completed) as completed,
          SUM(failed) as failed,
          SUM(running) as running,
          SUM(cancelled) as cancelled,
          CASE WHEN SUM(total) > 0 THEN SUM(totalSteps) / SUM(total) ELSE 0 END as avgSteps,
          CASE WHEN SUM(total) > 0 THEN SUM(totalCost) / SUM(total) ELSE 0 END as avgCost
        FROM (
          SELECT
            COUNT(*) as total,
            SUM(status = 'completed') as completed,
            SUM(status = 'failed') as failed,
            SUM(status = 'running') as running,
            SUM(status = 'cancelled') as cancelled,
            SUM(total_steps) as totalSteps,
            SUM(total_cost) as totalCost
          FROM agent_tasks
          WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
          UNION ALL
          SELECT
            COUNT(*) as total,
            SUM(status = 'completed') as completed,
            SUM(status = 'failed') as failed,
            SUM(status = 'running') as running,
            SUM(status = 'cancelled') as cancelled,
            SUM(completedActions) as totalSteps,
            0 as totalCost
          FROM automation_tasks
          WHERE createdAt > DATE_SUB(NOW(), INTERVAL 7 DAY)
        ) combined
      `);
      const row = (result as any)?.[0] || {};
      // ★ mysql2 返回 BigInt/Decimal，统一转 Number 防止前端 React #300
      const n = (v: any) => (v == null ? 0 : Number(v));
      return {
        total: n(row.total), completed: n(row.completed), failed: n(row.failed),
        running: n(row.running), cancelled: n(row.cancelled),
        avgSteps: Math.round(n(row.avgSteps)), avgCost: Number(n(row.avgCost).toFixed(2)),
      };
    } catch {
      return { total: 0, completed: 0, failed: 0, running: 0, cancelled: 0, avgSteps: 0, avgCost: 0 };
    }
  }),

  // ═══════════════════════════════════════════
  // P1: 队列管理
  // ═══════════════════════════════════════════

  /** 队列状态 */
  queueStats: adminProcedure.query(async () => {
    // Agent Core BullMQ 队列
    let agentQueue = { waiting: 0, active: 0, completed: 0, failed: 0, delayed: 0, workerConcurrency: 3 };
    try {
      const { getQueueStats } = await import("../_core/agentCore/queue");
      agentQueue = await getQueueStats();
    } catch {}
    // ★ 老自动化任务实时状态
    let autoWaiting = 0, autoRunning = 0, autoCompleted = 0, autoFailed = 0;
    try {
      const { getDb } = await import("../db");
      const db = await getDb();
      const [rows] = await db.execute(`
        SELECT status, COUNT(*) as cnt FROM automation_tasks
        WHERE createdAt > DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY status
      `);
      for (const r of rows as any[]) {
        const c = Number(r.cnt) || 0;
        if (r.status === 'pending') autoWaiting += c;
        else if (r.status === 'running') autoRunning += c;
        else if (r.status === 'completed') autoCompleted += c;
        else if (r.status === 'failed') autoFailed += c;
      }
    } catch {}
    return {
      waiting: agentQueue.waiting + autoWaiting,
      active: agentQueue.active + autoRunning,
      completed: agentQueue.completed + autoCompleted,
      failed: agentQueue.failed + autoFailed,
      delayed: agentQueue.delayed,
      workerConcurrency: agentQueue.workerConcurrency,
    };
  }),

  // ═══════════════════════════════════════════
  // P1: 多 Agent 并行
  // ═══════════════════════════════════════════

  /** 创建多 Agent 编排任务 */
  createMulti: protectedProcedure
    .input(z.object({
      tasks: z.array(z.object({
        prompt: z.string().min(1),
        type: z.enum(["automation", "research", "codeact", "general"]).default("general"),
        config: z.any().optional(),
      })).min(2).max(10),
      strategy: z.enum(["parallel", "sequential", "dag"]).default("parallel"),
      dependencies: z.record(z.array(z.string())).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { createMultiAgentPlan, runMultiAgent } = await import("../_core/agentCore/multiAgent");
      const { createAgentTask } = await import("../_core/agentCore/db");

      const plan = createMultiAgentPlan({
        userId: ctx.user.id,
        tasks: input.tasks,
        strategy: input.strategy,
        dependencies: input.dependencies,
      });

      // 在 DB 中创建每个子任务
      for (const task of plan.tasks) {
        await createAgentTask({
          id: task.taskId,
          userId: ctx.user.id,
          type: task.type,
          prompt: task.prompt,
          config: task.config,
        });
      }

      // 后台异步执行
      (async () => {
        try {
          const result = await runMultiAgent(plan);
          console.log(`[AgentRouter:Multi] Plan ${plan.planId} completed: ${result.summary.substring(0, 100)}`);
        } catch (err: any) {
          console.error(`[AgentRouter:Multi] Plan ${plan.planId} failed:`, err.message);
        }
      })();

      return {
        planId: plan.planId,
        taskIds: plan.tasks.map(t => t.taskId),
        strategy: plan.strategy,
      };
    }),

  /** 重试失败的任务 */
  retry: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask, updateAgentTaskStatus } = await import("../_core/agentCore/db");
      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      if (task.status !== "failed" && task.status !== "cancelled") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "只能重试失败或取消的任务" });
      }

      // 重置状态并重新入队
      await updateAgentTaskStatus(input.taskId, "pending", { totalSteps: 0, errorMsg: null });

      const { enqueueAgentTask } = await import("../_core/agentCore/queue");
      const config = typeof task.config === "string" ? JSON.parse(task.config) : task.config;
      await enqueueAgentTask({
        taskId: task.id,
        userId: task.userId,
        type: task.type as any,
        prompt: task.prompt,
        images: typeof task.images === "string" ? JSON.parse(task.images) : task.images || undefined,
        config,
      });

      return { success: true };
    }),

  // ═══════════════════════════════════════════
  // Phase 1: 定时调度管理
  // ═══════════════════════════════════════════

  /** 创建定时任务（模板 + 调度） */
  createScheduled: protectedProcedure
    .input(z.object({
      prompt: z.string().min(1).max(10000),
      type: z.enum(["automation", "research", "codeact", "general"]).default("automation"),
      cronExpression: z.string().min(5),
      timezone: z.string().default("Asia/Shanghai"),
      config: z.any().optional(),
      // Webhook 配置
      webhookUrl: z.string().optional(),
      webhookMethod: z.string().optional(),
      webhookHeaders: z.string().optional(),
      webhookBody: z.string().optional(),
      maxRetries: z.number().default(3),
      timeoutSeconds: z.number().default(30),
    }))
    .mutation(async ({ ctx, input }) => {
      const { v4: uuid } = await import("uuid");
      const { createAgentTask } = await import("../_core/agentCore/db");
      const { createAgentSchedule } = await import("../_core/agentCore/scheduleDb");
      const { parseCronExpression, getNextRunTime, scheduleAgentTask } = await import("../api/cronEngine");

      // 验证 cron
      try { parseCronExpression(input.cronExpression); } catch (e: any) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `无效的 cron 表达式: ${e.message}` });
      }

      const templateId = uuid();
      let nextRunAt: Date | undefined;
      try { nextRunAt = getNextRunTime(input.cronExpression); } catch {}

      // 1. 创建模板任务
      await createAgentTask({
        id: templateId,
        userId: ctx.user.id,
        type: input.type,
        prompt: input.prompt,
        config: input.config,
        isTemplate: true,
      });

      // 2. 创建调度记录
      const scheduleId = await createAgentSchedule({
        templateTaskId: templateId,
        cronExpression: input.cronExpression,
        timezone: input.timezone,
        webhookUrl: input.webhookUrl,
        webhookMethod: input.webhookMethod,
        webhookHeaders: input.webhookHeaders,
        webhookBody: input.webhookBody,
        maxRetries: input.maxRetries,
        timeoutSeconds: input.timeoutSeconds,
        nextRunAt,
      });

      // 3. 回写 schedule_id 到模板任务
      try {
        const { getDb } = await import("../db");
        const { agentTasks } = await import("../../drizzle/agentSchema");
        const { eq } = await import("drizzle-orm");
        const db = await getDb();
        await db.update(agentTasks)
          .set({ scheduleId })
          .where(eq(agentTasks.id, templateId));
      } catch {}

      // 4. 设置模板状态为 active（表示调度运行中）
      const { updateAgentTaskStatus } = await import("../_core/agentCore/db");
      await updateAgentTaskStatus(templateId, "running");

      // 5. 启动调度
      try { scheduleAgentTask(scheduleId, input.cronExpression); } catch (e: any) {
        console.warn(`[AgentRouter] Schedule arm failed: ${e.message}`);
      }

      return { taskId: templateId, scheduleId, nextRunAt: nextRunAt?.toISOString() };
    }),

  /** 暂停/恢复定时调度 */
  toggleSchedule: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask, updateAgentTaskStatus } = await import("../_core/agentCore/db");
      const { getScheduleByTemplateId, updateAgentSchedule } = await import("../_core/agentCore/scheduleDb");

      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

      const schedule = await getScheduleByTemplateId(input.taskId);
      if (!schedule) {
        // 调度记录已删除（比如先点了删除再点暂停）
        return { status: task.status === "cancelled" ? "cancelled" : "paused" };
      }

      const newStatus = schedule.status === "active" ? "paused" : "active";

      if (newStatus === "paused") {
        const { unscheduleTask } = await import("../api/cronEngine");
        unscheduleTask(schedule.id);
        await updateAgentSchedule(schedule.id, { status: "paused" });
      } else {
        const { scheduleAgentTask, getNextRunTime } = await import("../api/cronEngine");
        scheduleAgentTask(schedule.id, schedule.cronExpression);
        try {
          const nextRunAt = getNextRunTime(schedule.cronExpression);
          await updateAgentSchedule(schedule.id, { status: newStatus, nextRunAt });
        } catch {
          await updateAgentSchedule(schedule.id, { status: newStatus });
        }
      }

      // 同步模板任务状态
      await updateAgentTaskStatus(input.taskId, newStatus === "active" ? "running" : "paused");

      return { status: newStatus };
    }),

  /** 立即执行一次定时任务 */
  runScheduleNow: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask } = await import("../_core/agentCore/db");
      const { getScheduleByTemplateId } = await import("../_core/agentCore/scheduleDb");

      const template = await getAgentTask(input.taskId);
      if (!template) throw new TRPCError({ code: "NOT_FOUND" });
      if (template.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

      const schedule = await getScheduleByTemplateId(input.taskId);
      if (!schedule) throw new TRPCError({ code: "BAD_REQUEST", message: "定时调度已被删除，无法执行" });

      // ★ 异步触发 triggerScheduledAgent（包含天气/提醒快速路径）
      const { triggerScheduledAgentNow } = await import("../api/cronEngine/cronScheduler");
      triggerScheduledAgentNow(schedule.id).catch(err => {
        console.warn(`[AgentRouter:Schedule] Manual trigger failed: ${err.message}`);
      });

      return { triggered: true, scheduleId: schedule.id };
    }),

  /** 获取定时任务的执行历史 */
  getScheduleRuns: protectedProcedure
    .input(z.object({
      taskId: z.string(),
      limit: z.number().max(100).default(20),
      offset: z.number().default(0),
    }))
    .query(async ({ ctx, input }) => {
      const { getAgentTask } = await import("../_core/agentCore/db");
      const { listScheduleRuns, countScheduleRuns, getScheduleByTemplateId } = await import("../_core/agentCore/scheduleDb");

      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

      const schedule = await getScheduleByTemplateId(input.taskId);
      const [runs, total] = await Promise.all([
        listScheduleRuns(input.taskId, { limit: input.limit, offset: input.offset }),
        countScheduleRuns(input.taskId),
      ]);

      return { runs, total, schedule };
    }),

  /** ★ 删除一次性任务（仅 failed/cancelled/completed 可删） */
  deleteTask: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask } = await import("../_core/agentCore/db");
      const { getRawPool } = await import("../db/connection");

      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND", message: "任务不存在" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

      if (task.status === "running" || task.status === "pending") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "运行中或排队中的任务无法删除，请先取消" });
      }

      const pool = await getRawPool();
      if (!pool) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      // 如果是模板任务，同时清理 schedule 和子任务
      if ((task as any).isTemplate === 1) {
        try {
          const { getScheduleByTemplateId, deleteAgentSchedule } = await import("../_core/agentCore/scheduleDb");
          const { unscheduleTask } = await import("../api/cronEngine");
          const schedule = await getScheduleByTemplateId(input.taskId);
          if (schedule) {
            unscheduleTask(schedule.id);
            await deleteAgentSchedule(schedule.id);
          }
          // 删除所有子任务
          await pool.execute(`DELETE FROM agent_tasks WHERE parent_task_id = ?`, [input.taskId]);
        } catch {}
      }

      // 删除步骤记录（表名可能是 agent_steps 或不存在，静默处理）
      for (const tbl of ["agent_steps", "agent_task_steps"]) {
        try { await pool.execute(`DELETE FROM ${tbl} WHERE task_id = ?`, [input.taskId]); } catch {}
      }

      // 删除任务
      const [result]: any = await pool.execute(
        `DELETE FROM agent_tasks WHERE id = ? AND user_id = ?`,
        [input.taskId, ctx.user.id],
      );

      if (result?.affectedRows === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "删除失败，任务不存在或无权限" });
      }

      console.log(`[AgentRouter] Deleted task ${input.taskId} for user #${ctx.user.id}`);
      return { success: true };
    }),

  /** 删除定时调度（保留模板任务记录） */
  deleteSchedule: protectedProcedure
    .input(z.object({ taskId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask, updateAgentTaskStatus } = await import("../_core/agentCore/db");
      const { getScheduleByTemplateId, deleteAgentSchedule } = await import("../_core/agentCore/scheduleDb");

      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

      const schedule = await getScheduleByTemplateId(input.taskId);
      if (schedule) {
        const { unscheduleTask } = await import("../api/cronEngine");
        unscheduleTask(schedule.id);
        await deleteAgentSchedule(schedule.id);
      }

      // 标记模板任务为 cancelled
      await updateAgentTaskStatus(input.taskId, "cancelled");

      return { success: true };
    }),

  /** ★ 更新定时任务配置（套餐选择等） */
  updateScheduleConfig: protectedProcedure
    .input(z.object({
      taskId: z.string(),
      schedulePackageId: z.number().optional(),
      skipConfirmation: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { getAgentTask } = await import("../_core/agentCore/db");
      const { getRawPool } = await import("../db/connection");

      const task = await getAgentTask(input.taskId);
      if (!task) throw new TRPCError({ code: "NOT_FOUND" });
      if (task.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

      const config = typeof task.config === "string" ? JSON.parse(task.config) : (task.config || {});
      if (input.schedulePackageId !== undefined) {
        config._schedulePackageId = input.schedulePackageId;
        // 清除旧的 _scheduleModel 避免冲突
        delete config._scheduleModel;
      }
      // ★ P2⑨：定时任务确认控制
      if (input.skipConfirmation !== undefined) {
        config.skipConfirmation = input.skipConfirmation;
      }

      const pool = await getRawPool();
      if (!pool) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await pool.execute(
        `UPDATE agent_tasks SET config = ? WHERE id = ?`,
        [JSON.stringify(config), input.taskId],
      );

      return { success: true, config };
    }),

  /** ★ P0③：查询当前用户正在运行的任务（前端刷新页面后自动重连） */
  activeRunning: protectedProcedure
    .query(async ({ ctx }) => {
      const { listAgentTasks } = await import("../_core/agentCore/db");
      const running = await listAgentTasks(ctx.user.id, { status: "running", limit: 5 });
      const pending = await listAgentTasks(ctx.user.id, { status: "pending", limit: 3 });
      return [...running, ...pending].map(t => ({
        taskId: String(t.id),
        type: t.type,
        status: t.status,
        prompt: t.prompt?.substring(0, 80) || "",
        createdAt: t.createdAt,
      }));
    }),
});
