/**
 * routers/playbook.ts — Playbook tRPC 路由
 *
 * ★ v3: 全面逻辑审计修复 + AI 自动审批流
 *
 * 修复清单:
 *   [#1] update: 非管理员不可直接改 status（防绕过审批）
 *   [#2] update: pending_review 状态下改内容自动重置为 draft
 *   [#3] detail: 非 published 且非作者/管理员 → 403
 *   [#4] fork: 仅可 fork 已发布或官方模板
 *   [#5] rate: 不可给自己或未发布的评分
 *   [#6] runs: 仅作者/管理员可查看
 *   [#7] delete: db 层已级联清理 runs+ratings
 *   [#8] setCron: 仅 published 可设定时任务
 *   [#9] submitForReview: 集成 AI 自动审核
 */
import { z } from "zod";
import { v4 as uuid } from "uuid";
import { router, protectedProcedure, adminProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { workflowEndpoints } from '../workflowEndpoints';
/** 解析 JSON 字段的通用 helper */
function parseJsonFields(p: any) {
  return {
    ...p,
    steps: typeof p.steps === "string" ? JSON.parse(p.steps) : p.steps,
    parameters: typeof p.parameters === "string" ? JSON.parse(p.parameters) : p.parameters,
    tags: typeof p.tags === "string" ? JSON.parse(p.tags) : p.tags,
    defaultConfig: typeof p.defaultConfig === "string" ? JSON.parse(p.defaultConfig || "{}") : p.defaultConfig,
    rating: p.ratingCount > 0 ? (p.ratingSum / p.ratingCount).toFixed(1) : null,
  };
}

/** 强制安全序列化——剥离 Date/BigInt/Decimal 等非 JSON 原始类型 */
function safeReturn<T>(data: T): T {
  try { return JSON.parse(JSON.stringify(data)); } catch { return data; }
}

export const playbookRouter = router({

  // ═══════════ 市场浏览 ═══════════

  /** ★ 统一市场 — 同时返回 Playbook + Skill，归一化结构 */
  marketUnified: protectedProcedure
    .input(z.object({
      category: z.string().optional(),
      search: z.string().optional(),
      sortBy: z.enum(["popular", "rating", "newest"]).default("popular"),
      sourceType: z.enum(["all", "playbook", "skill"]).default("all"),
      limit: z.number().max(50).default(24),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const opts = input || {};
      const items: any[] = [];
      let totalPlaybooks = 0;
      let totalSkills = 0;

      // 分类映射: skill category → unified
      const skillCategoryMap: Record<string, string> = {
        information: "research", automation: "general", data: "data",
        development: "code", life: "general", content: "content",
        education: "general", business: "general",
      };

      // ── 查询 Playbooks ──
      if (opts.sourceType !== "skill") {
        try {
          const { listMarketPlaybooks } = await import("../_core/agentCore/playbook");
          const pbCategory = opts.category && !["information", "automation", "development", "life", "education", "business"].includes(opts.category)
            ? opts.category : undefined;
          const result = await listMarketPlaybooks({
            category: pbCategory,
            search: opts.search,
            sortBy: opts.sortBy,
            limit: opts.limit,
            offset: opts.offset,
          });
          totalPlaybooks = Number(result.total) || 0;
          console.log(`[Unified:Market] Found ${result.items.length} playbooks (total=${totalPlaybooks})`);
          for (const p of result.items) {
            const parsed = parseJsonFields(p);
            items.push({
              id: `pb-${p.id}`,
              sourceType: "playbook" as const,
              sourceId: p.id,
              title: parsed.title,
              description: parsed.description || "",
              category: parsed.category,
              icon: parsed.icon,
              tags: parsed.tags || [],
              isOfficial: p.isOfficial,
              runCount: p.runCount,
              installCount: p.forkCount,
              rating: parsed.rating,
              ratingCount: p.ratingCount,
              price: parseFloat(p.price as any) || 0,
              status: p.status,
              steps: parsed.steps,
              parameters: parsed.parameters,
              pipelineType: null,
              triggers: null,
              userId: p.userId,
              createdAt: p.createdAt ? String(p.createdAt) : null,
            });
          }
        } catch (e) { console.warn("[Unified] Playbook query failed:", e); }
      }

      // ── 查询 Skills ──
      if (opts.sourceType !== "playbook") {
        try {
          const allSkills = await import("../db");
          // 映射 skill 分类到 playbook 分类
          const skillCategory = opts.category
            ? Object.entries(skillCategoryMap).find(([, v]) => v === opts.category)?.[0] || opts.category
            : undefined;
          const result = await allSkills.getAllPublishedSkills({
            category: skillCategory,
            search: opts.search,
            page: 1,
            pageSize: opts.limit || 24,
          });
          totalSkills = Number(result.total) || 0;
          console.log(`[Unified:Market] Found ${result.skills.length} skills (total=${totalSkills})`);
          for (const s of result.skills) {
            const config = typeof s.config === "string" ? JSON.parse(s.config) : s.config;
            const tags = typeof s.tags === "string" ? JSON.parse(s.tags || "[]") : s.tags || [];
            items.push({
              id: `sk-${s.id}`,
              sourceType: "skill" as const,
              sourceId: s.id,
              title: s.name,
              description: s.description || config?.description || "",
              category: skillCategoryMap[s.category || ""] || s.category || "general",
              icon: s.icon || config?.icon || "🔧",
              tags,
              isOfficial: s.isOfficial,
              runCount: s.installCount || 0,
              installCount: s.installCount || 0,
              rating: s.rating ? String(s.rating) : null,
              ratingCount: 0,
              price: config?.estimatedCost || 0,
              status: s.status,
              steps: null,
              parameters: null,
              pipelineType: config?.pipeline?.type || null,
              triggers: config?.triggers || null,
              userId: s.authorId,
              createdAt: s.createdAt ? String(s.createdAt) : null,
            });
          }
        } catch (e) { console.warn("[Unified] Skill query failed:", e); }
      }

      // 排序
      if (opts.sortBy === "newest") {
        items.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      } else if (opts.sortBy === "rating") {
        items.sort((a, b) => parseFloat(b.rating || "0") - parseFloat(a.rating || "0"));
      } else {
        items.sort((a, b) => (b.runCount || 0) - (a.runCount || 0));
      }

      return safeReturn({
        items: items.slice(0, opts.limit || 24),
        totalPlaybooks,
        totalSkills,
        total: totalPlaybooks + totalSkills,
      });
    }),

  /** ★ 统一"我的" — Playbook + 已安装 Skill */
  mineUnified: protectedProcedure.query(async ({ ctx }) => {
    const userId = ctx.user.id;
    const items: any[] = [];

    // 我的 Playbook
    try {
      const { listUserPlaybooks } = await import("../_core/agentCore/playbook");
      const pbs = await listUserPlaybooks(userId);
      for (const p of pbs) {
        const parsed = parseJsonFields(p);
        items.push({
          id: `pb-${p.id}`,
          sourceType: "playbook" as const,
          sourceId: p.id,
          title: parsed.title,
          description: parsed.description || "",
          category: parsed.category,
          icon: parsed.icon,
          tags: parsed.tags || [],
          isOfficial: p.isOfficial,
          runCount: p.runCount,
          installCount: p.forkCount,
          rating: parsed.rating,
          ratingCount: p.ratingCount,
          price: parseFloat(p.price as any) || 0,
          status: p.status,
          pipelineType: null,
          triggers: null,
          isInstalled: false,
          userSkillId: null,
          isActive: true,
        });
      }
    } catch {}

    // 已安装的 Skill
    try {
      const dbMod = await import("../db");
      const installed = await dbMod.getUserInstalledSkills(userId);
      for (const { userSkill, skill } of installed) {
        const config = typeof skill.config === "string" ? JSON.parse(skill.config) : skill.config;
        const tags = typeof skill.tags === "string" ? JSON.parse(skill.tags || "[]") : skill.tags || [];
        items.push({
          id: `sk-${skill.id}`,
          sourceType: "skill" as const,
          sourceId: skill.id,
          title: skill.name,
          description: skill.description || config?.description || "",
          category: config?.category || skill.category || "general",
          icon: skill.icon || config?.icon || "🔧",
          tags,
          isOfficial: skill.isOfficial,
          runCount: userSkill.runCount || 0,
          installCount: skill.installCount || 0,
          rating: null,
          ratingCount: 0,
          price: config?.estimatedCost || 0,
          status: skill.status || "published",
          pipelineType: config?.pipeline?.type || null,
          triggers: config?.triggers || null,
          isInstalled: true,
          userSkillId: userSkill.id,
          isActive: userSkill.isActive,
        });
      }
    } catch {}

    return safeReturn(items);
  }),

  /** [#3] 单个详情 — 非 published 需要是作者或管理员 */
  detail: protectedProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ ctx, input }) => {
      const { getPlaybookById, getPlaybookRatings, listPlaybookRuns } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.id);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND", message: "Playbook 不存在" });

      // 访问控制：未发布 → 仅作者或管理员
      if (pb.status !== "published" && !pb.isOfficial) {
        if (pb.userId !== ctx.user.id && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "无权查看未发布的 Playbook" });
        }
      }

      const [ratings, recentRuns] = await Promise.all([
        getPlaybookRatings(input.id),
        listPlaybookRuns(input.id, 10),
      ]);

      return safeReturn({
        ...parseJsonFields(pb),
        ratings,
        recentRuns,
        isOwner: pb.userId === ctx.user.id,
        isAdmin: ctx.user.role === "admin",
      });
    }),

  categories: protectedProcedure.query(async () => {
    const { PLAYBOOK_CATEGORIES } = await import("../_core/agentCore/playbook/types");
    return PLAYBOOK_CATEGORIES;
  }),

  // ═══════════ 我的 Playbook ═══════════

  create: protectedProcedure
    .input(z.object({
      title: z.string().min(1).max(200),
      description: z.string().optional(),
      category: z.string().default("general"),
      icon: z.string().default("🤖"),
      steps: z.array(z.any()).min(1),
      parameters: z.array(z.any()),
      defaultConfig: z.any().optional(),
      tags: z.array(z.string()).optional(),
      isPublic: z.boolean().default(false),
      price: z.number().min(0).default(0),
    }))
    .mutation(async ({ ctx, input }) => {
      const { createPlaybook } = await import("../_core/agentCore/playbook");
      const id = uuid();
      await createPlaybook({ id, userId: ctx.user.id, ...input });
      return { id };
    }),

  /** [#1][#2] 更新 — 非管理员不能改 status；pending_review 下改内容自动重置 draft */
  update: protectedProcedure
    .input(z.object({
      id: z.string(),
      title: z.string().optional(),
      description: z.string().optional(),
      category: z.string().optional(),
      icon: z.string().optional(),
      steps: z.array(z.any()).optional(),
      parameters: z.array(z.any()).optional(),
      defaultConfig: z.any().optional(),
      tags: z.array(z.string()).optional(),
      isPublic: z.boolean().optional(),
      price: z.number().optional(),
      status: z.enum(["draft", "pending_review", "published", "rejected", "archived"]).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { getPlaybookById, updatePlaybook } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.id);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });

      const { id, ...data } = input;

      // [#1] 非管理员不能直接设 status
      if (data.status && ctx.user.role !== "admin") {
        delete (data as any).status;
      }

      // [#2] pending_review 状态下改内容 → 自动重置为 draft
      const contentFields = ["title", "description", "steps", "parameters", "defaultConfig", "icon", "category"];
      const isContentChange = contentFields.some(f => (data as any)[f] !== undefined);
      if (pb.status === "pending_review" && isContentChange && ctx.user.role !== "admin") {
        (data as any).status = "draft";
        (data as any).reviewNote = "用户在审核中修改了内容，已重置为草稿";
      }

      await updatePlaybook(id, data);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getPlaybookById, deletePlaybook } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.id);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      await deletePlaybook(input.id); // [#7] 已级联清理 runs+ratings
      return { success: true };
    }),

  // ═══════════ ★ 审批流 + AI 自动审核 ═══════════

  /** [#9] 提交审核 — 触发 AI 自动审核，可能直接通过/驳回 */
  submitForReview: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const {
        getPlaybookById, submitForReview, approvePlaybook, rejectPlaybook,
        updatePlaybook, reviewPlaybook,
      } = await import("../_core/agentCore/playbook");

      const pb = await getPlaybookById(input.id);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.userId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "只能提交自己的 Playbook" });
      if (!["draft", "rejected"].includes(pb.status)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `当前状态 ${pb.status} 不可提交审核` });
      }

      const steps = typeof pb.steps === "string" ? JSON.parse(pb.steps) : pb.steps;
      const parameters = typeof pb.parameters === "string" ? JSON.parse(pb.parameters) : pb.parameters;

      if (!Array.isArray(steps) || steps.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Playbook 至少需要一个步骤" });
      }
      if (!pb.title || pb.title.length < 2) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "标题至少需要 2 个字符" });
      }

      // 先设为 pending_review
      await submitForReview(input.id);

      // AI 自动审核（异步容错，失败不阻断）
      let aiReview: any = null;
      try {
        aiReview = await reviewPlaybook(
          input.id, pb.title, pb.description || "", pb.category, steps, parameters,
        );
      } catch (err: any) {
        console.warn("[Playbook:SubmitReview] AI review failed:", err.message);
      }

      if (aiReview) {
        const reviewNote = JSON.stringify({
          ai: true,
          score: aiReview.score,
          safetyScore: aiReview.safetyScore,
          qualityScore: aiReview.qualityScore,
          policyScore: aiReview.policyScore,
          decision: aiReview.decision,
          summary: aiReview.summary,
          issues: aiReview.issues,
        });

        if (aiReview.decision === "auto_approve") {
          await approvePlaybook(input.id, `[AI 自动通过] ${aiReview.summary}`);
          // 保存详细 AI 审核数据到 reviewNote
          await updatePlaybook(input.id, { reviewNote });
          return {
            success: true,
            status: "published" as const,
            aiReview: {
              decision: aiReview.decision,
              score: aiReview.score,
              summary: aiReview.summary,
              issues: aiReview.issues,
            },
          };
        }

        if (aiReview.decision === "auto_reject") {
          await rejectPlaybook(input.id, `[AI 自动驳回] ${aiReview.summary}`);
          await updatePlaybook(input.id, { reviewNote });
          return {
            success: true,
            status: "rejected" as const,
            aiReview: {
              decision: aiReview.decision,
              score: aiReview.score,
              summary: aiReview.summary,
              issues: aiReview.issues,
            },
          };
        }

        // manual_review — 保留 pending_review，存 AI 预审结果供管理员参考
        await updatePlaybook(input.id, { reviewNote });
        return {
          success: true,
          status: "pending_review" as const,
          aiReview: {
            decision: aiReview.decision,
            score: aiReview.score,
            summary: aiReview.summary,
            issues: aiReview.issues,
          },
        };
      }

      // AI 审核不可用，正常进入人工审核
      return { success: true, status: "pending_review" as const, aiReview: null };
    }),

  /** 管理员：待审列表（含 AI 预审结果） */
  pendingList: adminProcedure.query(async () => {
    const { listPendingPlaybooks } = await import("../_core/agentCore/playbook");
    const pbs = await listPendingPlaybooks();
    return safeReturn(pbs.map(p => {
      const parsed = parseJsonFields(p);
      let aiReview = null;
      try {
        if (p.reviewNote) {
          const note = JSON.parse(p.reviewNote);
          if (note.ai) aiReview = note;
        }
      } catch {}
      return { ...parsed, aiReview };
    }));
  }),

  approve: adminProcedure
    .input(z.object({ id: z.string(), note: z.string().optional() }))
    .mutation(async ({ input }) => {
      const { getPlaybookById, approvePlaybook } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.id);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.status !== "pending_review") {
        throw new TRPCError({ code: "BAD_REQUEST", message: `当前状态 ${pb.status} 不可审核` });
      }
      await approvePlaybook(input.id, input.note);
      return { success: true, status: "published" };
    }),

  reject: adminProcedure
    .input(z.object({ id: z.string(), note: z.string().min(1, "请填写驳回原因") }))
    .mutation(async ({ input }) => {
      const { getPlaybookById, rejectPlaybook } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.id);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.status !== "pending_review") {
        throw new TRPCError({ code: "BAD_REQUEST", message: `当前状态 ${pb.status} 不可驳回` });
      }
      await rejectPlaybook(input.id, input.note);
      return { success: true, status: "rejected" };
    }),

  // ═══════════ 费用预估 ═══════════

  estimate: protectedProcedure
    .input(z.object({ id: z.string(), params: z.record(z.any()).optional() }))
    .query(async ({ input }) => {
      const { getPlaybookById, estimatePlaybookCost } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.id);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      const steps = typeof pb.steps === "string" ? JSON.parse(pb.steps) : pb.steps;
      const defaultConfig = typeof pb.defaultConfig === "string" ? JSON.parse(pb.defaultConfig || "{}") : pb.defaultConfig;
      return estimatePlaybookCost(steps, defaultConfig, pb.price as any);
    }),

  estimateInline: protectedProcedure
    .input(z.any())
    .mutation(async ({ input }) => {
      try {
        const { estimatePlaybookCost } = await import("../_core/agentCore/playbook");
        const data = input || {};
        return estimatePlaybookCost(data.steps || [], data.defaultConfig, data.price);
      } catch (e: any) {
        return { playbookPrice: 0, estimatedAgentCost: 0, totalEstimate: 0, breakdown: [] };
      }
    }),

  // ═══════════ 预览 / 试运行 ═══════════

  preview: protectedProcedure
    .input(z.any())
    .mutation(async ({ input }) => {
      try {
        const data = input || {};
        const { buildPromptFromSteps, validateParams, estimatePlaybookCost, inferAgentType } = await import("../_core/agentCore/playbook");

        let steps: any[], parameters: any[], title: string, description: string | undefined, defaultConfig: any, price = 0;

        if (data.playbookId) {
          const { getPlaybookById } = await import("../_core/agentCore/playbook");
          const pb = await getPlaybookById(data.playbookId);
          if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
          steps = typeof pb.steps === "string" ? JSON.parse(pb.steps) : pb.steps;
          parameters = typeof pb.parameters === "string" ? JSON.parse(pb.parameters) : pb.parameters;
          title = pb.title;
          description = pb.description || undefined;
          defaultConfig = typeof pb.defaultConfig === "string" ? JSON.parse(pb.defaultConfig || "{}") : pb.defaultConfig;
          price = parseFloat(pb.price as any) || 0;
        } else {
          steps = data.steps || [];
          parameters = data.parameters || [];
          title = data.title || "未命名 Playbook";
          description = data.description;
          defaultConfig = data.defaultConfig;
        }

        const userParams = data.params || {};
        const validation = validateParams(parameters, userParams);
        const fullParams: Record<string, any> = {};
        for (const p of parameters) {
          fullParams[p.key] = userParams[p.key] !== undefined && userParams[p.key] !== ""
            ? userParams[p.key] : p.default || `[${p.label}]`;
        }

        return {
          prompt: buildPromptFromSteps(steps, fullParams, title, description),
          agentType: inferAgentType(steps, defaultConfig),
          toolIds: [...new Set(steps.map((s: any) => s.toolId))],
          costEstimate: estimatePlaybookCost(steps, defaultConfig, price),
          validation,
          stepsCount: steps.length,
          paramsCount: parameters.length,
        };
      } catch (e: any) {
        if (e instanceof TRPCError) throw e;
        console.error("[Playbook:Preview]", e.message);
        return {
          prompt: `预览生成失败: ${e.message}`,
          agentType: "general",
          toolIds: [],
          costEstimate: { playbookPrice: 0, estimatedAgentCost: 0, totalEstimate: 0, breakdown: [] },
          validation: { valid: false, errors: [e.message] },
          stepsCount: 0,
          paramsCount: 0,
        };
      }
    }),

  // ═══════════ [#4] Fork — 仅已发布 / 官方 ═══════════

  fork: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const { getPlaybookById, createPlaybook, incrementForkCount } = await import("../_core/agentCore/playbook");
      const source = await getPlaybookById(input.id);
      if (!source) throw new TRPCError({ code: "NOT_FOUND" });

      // 仅可 fork 已发布或官方 或自己的
      if (source.status !== "published" && !source.isOfficial && source.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "只能 Fork 已发布的 Playbook" });
      }

      const newId = uuid();
      await createPlaybook({
        id: newId,
        userId: ctx.user.id,
        title: `${source.title} (Fork)`,
        description: source.description || undefined,
        category: source.category,
        icon: source.icon,
        steps: typeof source.steps === "string" ? JSON.parse(source.steps) : source.steps,
        parameters: typeof source.parameters === "string" ? JSON.parse(source.parameters) : source.parameters,
        defaultConfig: typeof source.defaultConfig === "string" ? JSON.parse(source.defaultConfig || "{}") : source.defaultConfig,
        tags: typeof source.tags === "string" ? JSON.parse(source.tags || "[]") : source.tags || [],
        forkedFrom: input.id,
      });

      await incrementForkCount(input.id);
      return { id: newId };
    }),

  // ═══════════ [#5] 评分 — 不能给自己/未发布评分 ═══════════

  rate: protectedProcedure
    .input(z.object({
      playbookId: z.string(),
      score: z.number().min(1).max(5),
      comment: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { getPlaybookById, ratePlaybook } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.playbookId);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.userId === ctx.user.id) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "不能给自己的 Playbook 评分" });
      }
      if (pb.status !== "published" && !pb.isOfficial) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "只能给已发布的 Playbook 评分" });
      }
      await ratePlaybook(input.playbookId, ctx.user.id, input.score, input.comment);
      return { success: true };
    }),

  // ═══════════ 执行 ═══════════

  run: protectedProcedure
    .input(z.object({
      playbookId: z.string(),
      params: z.record(z.any()),
    }))
    .mutation(async ({ ctx, input }) => {
      const { getPlaybookById } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.playbookId);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });

      // 未发布且不是自己的 → 不能运行
      if (pb.status !== "published" && !pb.isOfficial && pb.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Playbook 未发布" });
      }

      const price = parseFloat(pb.price as any) || 0;
      if (price > 0 && pb.userId !== ctx.user.id) {
        try {
          const { deductFishCoins } = await import("../db");
          const deducted = await deductFishCoins(ctx.user.id, price, `运行 Playbook: ${pb.title}`);
          if (!deducted) throw new TRPCError({ code: "BAD_REQUEST", message: `余额不足，需要 ${price} 🐟` });
        } catch (err: any) {
          if (err instanceof TRPCError) throw err;
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: err.message });
        }
      }

      const { runPlaybook } = await import("../_core/agentCore/playbook");
      return await runPlaybook({ playbookId: input.playbookId, userId: ctx.user.id, params: input.params });
    }),

  /** [#6] 执行历史 — 仅作者/管理员 */
  runs: protectedProcedure
    .input(z.object({ playbookId: z.string(), limit: z.number().max(100).default(20) }))
    .query(async ({ ctx, input }) => {
      const { getPlaybookById, listPlaybookRuns } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.playbookId);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "只有作者或管理员可查看执行历史" });
      }
      return listPlaybookRuns(input.playbookId, input.limit);
    }),

  // ═══════════ [#8] Cron — 仅 published 可设 ═══════════

  setCron: protectedProcedure
    .input(z.object({
      playbookId: z.string(),
      cronExpression: z.string().optional(),
      cronEnabled: z.boolean(),
      cronParams: z.record(z.any()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const { getPlaybookById, updatePlaybook } = await import("../_core/agentCore/playbook");
      const pb = await getPlaybookById(input.playbookId);
      if (!pb) throw new TRPCError({ code: "NOT_FOUND" });
      if (pb.userId !== ctx.user.id && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
      if (pb.status !== "published" && !pb.isOfficial && input.cronEnabled) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "只有已发布的 Playbook 可以启用定时任务" });
      }
      await updatePlaybook(input.playbookId, {
        cronExpression: input.cronExpression,
        cronEnabled: input.cronEnabled,
        cronParams: input.cronParams,
      });
      return { success: true };
    }),

  // ★ Phase 2: 可视化工作流接口
  ...workflowEndpoints,
});
